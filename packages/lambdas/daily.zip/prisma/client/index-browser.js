
Object.defineProperty(exports, "__esModule", { value: true });

const {
  Decimal,
  objectEnumValues,
  makeStrictEnum,
  Public,
} = require('./runtime/index-browser')


const Prisma = {}

exports.Prisma = Prisma

/**
 * Prisma Client JS version: 4.16.1
 * Query Engine version: b20ead4d3ab9e78ac112966e242ded703f4a052c
 */
Prisma.prismaVersion = {
  client: "4.16.1",
  engine: "b20ead4d3ab9e78ac112966e242ded703f4a052c"
}

Prisma.PrismaClientKnownRequestError = () => {
  throw new Error(`PrismaClientKnownRequestError is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)};
Prisma.PrismaClientUnknownRequestError = () => {
  throw new Error(`PrismaClientUnknownRequestError is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.PrismaClientRustPanicError = () => {
  throw new Error(`PrismaClientRustPanicError is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.PrismaClientInitializationError = () => {
  throw new Error(`PrismaClientInitializationError is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.PrismaClientValidationError = () => {
  throw new Error(`PrismaClientValidationError is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.NotFoundError = () => {
  throw new Error(`NotFoundError is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.Decimal = Decimal

/**
 * Re-export of sql-template-tag
 */
Prisma.sql = () => {
  throw new Error(`sqltag is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.empty = () => {
  throw new Error(`empty is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.join = () => {
  throw new Error(`join is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.raw = () => {
  throw new Error(`raw is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.validator = Public.validator

/**
* Extensions
*/
Prisma.getExtensionContext = () => {
  throw new Error(`Extensions.getExtensionContext is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}
Prisma.defineExtension = () => {
  throw new Error(`Extensions.defineExtension is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
)}

/**
 * Shorthand utilities for JSON filtering
 */
Prisma.DbNull = objectEnumValues.instances.DbNull
Prisma.JsonNull = objectEnumValues.instances.JsonNull
Prisma.AnyNull = objectEnumValues.instances.AnyNull

Prisma.NullTypes = {
  DbNull: objectEnumValues.classes.DbNull,
  JsonNull: objectEnumValues.classes.JsonNull,
  AnyNull: objectEnumValues.classes.AnyNull
}

/**
 * Enums
 */

exports.Prisma.TransactionIsolationLevel = makeStrictEnum({
  ReadUncommitted: 'ReadUncommitted',
  ReadCommitted: 'ReadCommitted',
  RepeatableRead: 'RepeatableRead',
  Serializable: 'Serializable'
});

exports.Prisma.MigrationsScalarFieldEnum = {
  id: 'id',
  name: 'name',
  hash: 'hash',
  executed_at: 'executed_at'
};

exports.Prisma.TosApprovalScalarFieldEnum = {
  id: 'id',
  address: 'address',
  signature: 'signature',
  message: 'message',
  chain_id: 'chain_id',
  doc_version: 'doc_version',
  sign_date: 'sign_date'
};

exports.Prisma.VaultScalarFieldEnum = {
  vault_id: 'vault_id',
  type: 'type',
  owner_address: 'owner_address',
  chain_id: 'chain_id',
  protocol: 'protocol'
};

exports.Prisma.UserScalarFieldEnum = {
  address: 'address',
  timestamp: 'timestamp',
  user_that_referred_address: 'user_that_referred_address',
  accepted: 'accepted'
};

exports.Prisma.WeeklyClaimScalarFieldEnum = {
  id: 'id',
  timestamp: 'timestamp',
  week_number: 'week_number',
  user_address: 'user_address',
  proof: 'proof',
  amount: 'amount'
};

exports.Prisma.MerkleTreeScalarFieldEnum = {
  week_number: 'week_number',
  start_block: 'start_block',
  end_block: 'end_block',
  timestamp: 'timestamp',
  tree_root: 'tree_root',
  snapshot: 'snapshot'
};

exports.Prisma.WalletRiskScalarFieldEnum = {
  address: 'address',
  last_check: 'last_check',
  is_risky: 'is_risky'
};

exports.Prisma.CollateralTypeScalarFieldEnum = {
  collateral_name: 'collateral_name',
  token: 'token',
  next_price: 'next_price',
  current_price: 'current_price',
  liquidation_ratio: 'liquidation_ratio',
  liquidation_penalty: 'liquidation_penalty',
  rate: 'rate',
  market_price: 'market_price'
};

exports.Prisma.DiscoverScalarFieldEnum = {
  protocol_id: 'protocol_id',
  position_id: 'position_id',
  collateral_type: 'collateral_type',
  vault_debt: 'vault_debt',
  vault_normalized_debt: 'vault_normalized_debt',
  vault_collateral: 'vault_collateral',
  yield_30d: 'yield_30d',
  status: 'status',
  last_action: 'last_action',
  pnl_all: 'pnl_all',
  pnl_1d: 'pnl_1d',
  pnl_7d: 'pnl_7d',
  pnl_30d: 'pnl_30d',
  pnl_365d: 'pnl_365d',
  pnl_ytd: 'pnl_ytd',
  net_profit_all: 'net_profit_all',
  net_profit_1d: 'net_profit_1d',
  net_profit_7d: 'net_profit_7d',
  net_profit_30d: 'net_profit_30d',
  net_profit_365d: 'net_profit_365d',
  net_profit_ytd: 'net_profit_ytd',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.HighestRiskPositionsScalarFieldEnum = {
  protocol_id: 'protocol_id',
  position_id: 'position_id',
  collateral_type: 'collateral_type',
  token: 'token',
  collateral_ratio: 'collateral_ratio',
  collateral_value: 'collateral_value',
  liquidation_proximity: 'liquidation_proximity',
  liquidation_price: 'liquidation_price',
  liquidation_value: 'liquidation_value',
  next_price: 'next_price',
  status: 'status',
  type: 'type'
};

exports.Prisma.HighestMultiplyPnlScalarFieldEnum = {
  protocol_id: 'protocol_id',
  position_id: 'position_id',
  collateral_type: 'collateral_type',
  token: 'token',
  collateral_value: 'collateral_value',
  vault_multiple: 'vault_multiple',
  pnl_all: 'pnl_all',
  pnl_1d: 'pnl_1d',
  pnl_7d: 'pnl_7d',
  pnl_30d: 'pnl_30d',
  pnl_365d: 'pnl_365d',
  pnl_ytd: 'pnl_ytd',
  net_profit_all: 'net_profit_all',
  net_profit_1d: 'net_profit_1d',
  net_profit_7d: 'net_profit_7d',
  net_profit_30d: 'net_profit_30d',
  net_profit_365d: 'net_profit_365d',
  net_profit_ytd: 'net_profit_ytd',
  last_action: 'last_action',
  type: 'type'
};

exports.Prisma.MostYieldEarnedScalarFieldEnum = {
  protocol_id: 'protocol_id',
  position_id: 'position_id',
  collateral_type: 'collateral_type',
  token: 'token',
  collateral_value: 'collateral_value',
  net_value: 'net_value',
  pnl_all: 'pnl_all',
  pnl_1d: 'pnl_1d',
  pnl_7d: 'pnl_7d',
  pnl_30d: 'pnl_30d',
  pnl_365d: 'pnl_365d',
  pnl_ytd: 'pnl_ytd',
  yield_30d: 'yield_30d',
  last_action: 'last_action',
  type: 'type'
};

exports.Prisma.LargestDebtScalarFieldEnum = {
  protocol_id: 'protocol_id',
  position_id: 'position_id',
  collateral_type: 'collateral_type',
  token: 'token',
  collateral_value: 'collateral_value',
  liquidation_proximity: 'liquidation_proximity',
  vault_debt: 'vault_debt',
  coll_ratio: 'coll_ratio',
  last_action: 'last_action',
  type: 'type'
};

exports.Prisma.UsersWhoFollowVaultsScalarFieldEnum = {
  user_address: 'user_address',
  vault_id: 'vault_id',
  vault_chain_id: 'vault_chain_id',
  protocol: 'protocol'
};

exports.Prisma.ProductHubItemsScalarFieldEnum = {
  id: 'id',
  label: 'label',
  network: 'network',
  primaryToken: 'primaryToken',
  primaryTokenGroup: 'primaryTokenGroup',
  product: 'product',
  protocol: 'protocol',
  secondaryToken: 'secondaryToken',
  secondaryTokenGroup: 'secondaryTokenGroup',
  weeklyNetApy: 'weeklyNetApy',
  depositToken: 'depositToken',
  earnStrategy: 'earnStrategy',
  fee: 'fee',
  liquidity: 'liquidity',
  managementType: 'managementType',
  maxLtv: 'maxLtv',
  maxMultiply: 'maxMultiply',
  multiplyStrategy: 'multiplyStrategy',
  multiplyStrategyType: 'multiplyStrategyType',
  reverseTokens: 'reverseTokens',
  updatedAt: 'updatedAt'
};

exports.Prisma.AjnaRewardsWeeklyClaimScalarFieldEnum = {
  id: 'id',
  timestamp: 'timestamp',
  chain_id: 'chain_id',
  user_address: 'user_address',
  amount: 'amount',
  week_number: 'week_number',
  proof: 'proof'
};

exports.Prisma.AjnaRewardsDailyClaimScalarFieldEnum = {
  id: 'id',
  timestamp: 'timestamp',
  chain_id: 'chain_id',
  user_address: 'user_address',
  amount: 'amount',
  week_number: 'week_number',
  day_number: 'day_number'
};

exports.Prisma.AjnaRewardsMerkleTreeScalarFieldEnum = {
  id: 'id',
  timestamp: 'timestamp',
  chain_id: 'chain_id',
  week_number: 'week_number',
  tree_root: 'tree_root',
  tx_processed: 'tx_processed'
};

exports.Prisma.SortOrder = {
  asc: 'asc',
  desc: 'desc'
};

exports.Prisma.JsonNullValueInput = {
  JsonNull: Prisma.JsonNull
};

exports.Prisma.QueryMode = {
  default: 'default',
  insensitive: 'insensitive'
};

exports.Prisma.NullsOrder = {
  first: 'first',
  last: 'last'
};

exports.Prisma.JsonNullValueFilter = {
  DbNull: Prisma.DbNull,
  JsonNull: Prisma.JsonNull,
  AnyNull: Prisma.AnyNull
};
exports.VaultType = {
  borrow: 'borrow',
  multiply: 'multiply'
};

exports.Protocol = {
  maker: 'maker',
  aavev2: 'aavev2',
  aavev3: 'aavev3',
  ajna: 'ajna'
};

exports.NetworkNames = {
  ethereum: 'ethereum',
  arbitrum: 'arbitrum',
  polygon: 'polygon',
  optimism: 'optimism'
};

exports.ProductHubManagementSimple = {
  active: 'active',
  passive: 'passive'
};

exports.ProductHubStrategy = {
  long: 'long',
  short: 'short'
};

exports.Product = {
  borrow: 'borrow',
  multiply: 'multiply',
  earn: 'earn'
};

exports.Prisma.ModelName = {
  migrations: 'migrations',
  TosApproval: 'TosApproval',
  Vault: 'Vault',
  User: 'User',
  WeeklyClaim: 'WeeklyClaim',
  MerkleTree: 'MerkleTree',
  WalletRisk: 'WalletRisk',
  CollateralType: 'CollateralType',
  Discover: 'Discover',
  HighestRiskPositions: 'HighestRiskPositions',
  HighestMultiplyPnl: 'HighestMultiplyPnl',
  MostYieldEarned: 'MostYieldEarned',
  LargestDebt: 'LargestDebt',
  UsersWhoFollowVaults: 'UsersWhoFollowVaults',
  ProductHubItems: 'ProductHubItems',
  AjnaRewardsWeeklyClaim: 'AjnaRewardsWeeklyClaim',
  AjnaRewardsDailyClaim: 'AjnaRewardsDailyClaim',
  AjnaRewardsMerkleTree: 'AjnaRewardsMerkleTree'
};

/**
 * Create the Client
 */
class PrismaClient {
  constructor() {
    throw new Error(
      `PrismaClient is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`,
    )
  }
}
exports.PrismaClient = PrismaClient

Object.assign(exports, Prisma)
