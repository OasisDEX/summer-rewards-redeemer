
/**
 * Client
**/

import * as runtime from './runtime/library';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions

export type PrismaPromise<T> = $Public.PrismaPromise<T>


export type migrationsPayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {}
  scalars: $Extensions.GetResult<{
    id: number
    name: string
    hash: string
    executed_at: Date | null
  }, ExtArgs["result"]["migrations"]>
  composites: {}
}

/**
 * Model migrations
 * 
 */
export type migrations = runtime.Types.DefaultSelection<migrationsPayload>
export type TosApprovalPayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {}
  scalars: $Extensions.GetResult<{
    id: number
    address: string
    signature: string
    message: string
    chain_id: number
    doc_version: string
    sign_date: Date
  }, ExtArgs["result"]["tosApproval"]>
  composites: {}
}

/**
 * Model TosApproval
 * 
 */
export type TosApproval = runtime.Types.DefaultSelection<TosApprovalPayload>
export type VaultPayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {}
  scalars: $Extensions.GetResult<{
    vault_id: number
    type: VaultType
    owner_address: string
    chain_id: number | null
    protocol: string
  }, ExtArgs["result"]["vault"]>
  composites: {}
}

/**
 * Model Vault
 * 
 */
export type Vault = runtime.Types.DefaultSelection<VaultPayload>
export type UserPayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {
    user_that_referred: UserPayload<ExtArgs> | null
    referred_users: UserPayload<ExtArgs>[]
    weekly_claims: WeeklyClaimPayload<ExtArgs>[]
  }
  scalars: $Extensions.GetResult<{
    address: string
    timestamp: Date
    user_that_referred_address: string | null
    accepted: boolean
  }, ExtArgs["result"]["user"]>
  composites: {}
}

/**
 * Model User
 * 
 */
export type User = runtime.Types.DefaultSelection<UserPayload>
export type WeeklyClaimPayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {
    claimant: UserPayload<ExtArgs>
  }
  scalars: $Extensions.GetResult<{
    id: number
    timestamp: Date | null
    week_number: number
    user_address: string
    proof: string[]
    amount: string
  }, ExtArgs["result"]["weeklyClaim"]>
  composites: {}
}

/**
 * Model WeeklyClaim
 * 
 */
export type WeeklyClaim = runtime.Types.DefaultSelection<WeeklyClaimPayload>
export type MerkleTreePayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {}
  scalars: $Extensions.GetResult<{
    week_number: number
    start_block: number | null
    end_block: number | null
    timestamp: Date | null
    tree_root: string
    snapshot: string | null
  }, ExtArgs["result"]["merkleTree"]>
  composites: {}
}

/**
 * Model MerkleTree
 * 
 */
export type MerkleTree = runtime.Types.DefaultSelection<MerkleTreePayload>
export type WalletRiskPayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {}
  scalars: $Extensions.GetResult<{
    address: string
    last_check: Date
    is_risky: boolean
  }, ExtArgs["result"]["walletRisk"]>
  composites: {}
}

/**
 * Model WalletRisk
 * 
 */
export type WalletRisk = runtime.Types.DefaultSelection<WalletRiskPayload>
export type CollateralTypePayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {}
  scalars: $Extensions.GetResult<{
    collateral_name: string
    token: string
    next_price: Prisma.Decimal
    current_price: Prisma.Decimal
    liquidation_ratio: Prisma.Decimal
    liquidation_penalty: Prisma.Decimal
    rate: Prisma.Decimal | null
    market_price: Prisma.Decimal | null
  }, ExtArgs["result"]["collateralType"]>
  composites: {}
}

/**
 * Model CollateralType
 * 
 */
export type CollateralType = runtime.Types.DefaultSelection<CollateralTypePayload>
export type DiscoverPayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {}
  scalars: $Extensions.GetResult<{
    protocol_id: string
    position_id: string
    collateral_type: string
    vault_debt: Prisma.Decimal
    vault_normalized_debt: Prisma.Decimal | null
    vault_collateral: Prisma.Decimal
    yield_30d: Prisma.Decimal
    status: Prisma.JsonValue
    last_action: Prisma.JsonValue
    pnl_all: Prisma.Decimal
    pnl_1d: Prisma.Decimal
    pnl_7d: Prisma.Decimal
    pnl_30d: Prisma.Decimal
    pnl_365d: Prisma.Decimal
    pnl_ytd: Prisma.Decimal
    net_profit_all: Prisma.Decimal
    net_profit_1d: Prisma.Decimal
    net_profit_7d: Prisma.Decimal
    net_profit_30d: Prisma.Decimal
    net_profit_365d: Prisma.Decimal
    net_profit_ytd: Prisma.Decimal
    createdAt: Date
    updatedAt: Date
  }, ExtArgs["result"]["discover"]>
  composites: {}
}

/**
 * Model Discover
 * 
 */
export type Discover = runtime.Types.DefaultSelection<DiscoverPayload>
export type HighestRiskPositionsPayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {}
  scalars: $Extensions.GetResult<{
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_ratio: Prisma.Decimal
    collateral_value: Prisma.Decimal
    liquidation_proximity: Prisma.Decimal
    liquidation_price: Prisma.Decimal
    liquidation_value: Prisma.Decimal
    next_price: Prisma.Decimal
    status: Prisma.JsonValue
    type: VaultType | null
  }, ExtArgs["result"]["highestRiskPositions"]>
  composites: {}
}

/**
 * Model HighestRiskPositions
 * 
 */
export type HighestRiskPositions = runtime.Types.DefaultSelection<HighestRiskPositionsPayload>
export type HighestMultiplyPnlPayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {}
  scalars: $Extensions.GetResult<{
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_value: Prisma.Decimal
    vault_multiple: Prisma.Decimal
    pnl_all: Prisma.Decimal
    pnl_1d: Prisma.Decimal
    pnl_7d: Prisma.Decimal
    pnl_30d: Prisma.Decimal
    pnl_365d: Prisma.Decimal
    pnl_ytd: Prisma.Decimal
    net_profit_all: Prisma.Decimal
    net_profit_1d: Prisma.Decimal
    net_profit_7d: Prisma.Decimal
    net_profit_30d: Prisma.Decimal
    net_profit_365d: Prisma.Decimal
    net_profit_ytd: Prisma.Decimal
    last_action: Prisma.JsonValue
    type: VaultType | null
  }, ExtArgs["result"]["highestMultiplyPnl"]>
  composites: {}
}

/**
 * Model HighestMultiplyPnl
 * 
 */
export type HighestMultiplyPnl = runtime.Types.DefaultSelection<HighestMultiplyPnlPayload>
export type MostYieldEarnedPayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {}
  scalars: $Extensions.GetResult<{
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_value: Prisma.Decimal
    net_value: Prisma.Decimal
    pnl_all: Prisma.Decimal
    pnl_1d: Prisma.Decimal
    pnl_7d: Prisma.Decimal
    pnl_30d: Prisma.Decimal
    pnl_365d: Prisma.Decimal
    pnl_ytd: Prisma.Decimal
    yield_30d: Prisma.Decimal
    last_action: Prisma.JsonValue
    type: VaultType | null
  }, ExtArgs["result"]["mostYieldEarned"]>
  composites: {}
}

/**
 * Model MostYieldEarned
 * 
 */
export type MostYieldEarned = runtime.Types.DefaultSelection<MostYieldEarnedPayload>
export type LargestDebtPayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {}
  scalars: $Extensions.GetResult<{
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_value: Prisma.Decimal
    liquidation_proximity: Prisma.Decimal
    vault_debt: Prisma.Decimal
    coll_ratio: Prisma.Decimal
    last_action: Prisma.JsonValue
    type: VaultType | null
  }, ExtArgs["result"]["largestDebt"]>
  composites: {}
}

/**
 * Model LargestDebt
 * 
 */
export type LargestDebt = runtime.Types.DefaultSelection<LargestDebtPayload>
export type UsersWhoFollowVaultsPayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {}
  scalars: $Extensions.GetResult<{
    user_address: string
    vault_id: number
    vault_chain_id: number
    protocol: Protocol
  }, ExtArgs["result"]["usersWhoFollowVaults"]>
  composites: {}
}

/**
 * Model UsersWhoFollowVaults
 * 
 */
export type UsersWhoFollowVaults = runtime.Types.DefaultSelection<UsersWhoFollowVaultsPayload>
export type ProductHubItemsPayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {}
  scalars: $Extensions.GetResult<{
    id: string
    label: string
    network: NetworkNames
    primaryToken: string
    primaryTokenGroup: string | null
    product: Product[]
    protocol: Protocol
    secondaryToken: string
    secondaryTokenGroup: string | null
    weeklyNetApy: string | null
    depositToken: string | null
    earnStrategy: string | null
    fee: string | null
    liquidity: string | null
    managementType: ProductHubManagementSimple | null
    maxLtv: string | null
    maxMultiply: string | null
    multiplyStrategy: string | null
    multiplyStrategyType: ProductHubStrategy | null
    reverseTokens: boolean | null
    updatedAt: Date
  }, ExtArgs["result"]["productHubItems"]>
  composites: {}
}

/**
 * Model ProductHubItems
 * 
 */
export type ProductHubItems = runtime.Types.DefaultSelection<ProductHubItemsPayload>
export type AjnaRewardsWeeklyClaimPayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {}
  scalars: $Extensions.GetResult<{
    id: number
    timestamp: Date
    chain_id: number
    user_address: string
    amount: string
    week_number: number
    proof: string[]
  }, ExtArgs["result"]["ajnaRewardsWeeklyClaim"]>
  composites: {}
}

/**
 * Model AjnaRewardsWeeklyClaim
 * 
 */
export type AjnaRewardsWeeklyClaim = runtime.Types.DefaultSelection<AjnaRewardsWeeklyClaimPayload>
export type AjnaRewardsDailyClaimPayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {}
  scalars: $Extensions.GetResult<{
    id: number
    timestamp: Date
    chain_id: number
    user_address: string
    amount: string
    week_number: number
    day_number: number
  }, ExtArgs["result"]["ajnaRewardsDailyClaim"]>
  composites: {}
}

/**
 * Model AjnaRewardsDailyClaim
 * 
 */
export type AjnaRewardsDailyClaim = runtime.Types.DefaultSelection<AjnaRewardsDailyClaimPayload>
export type AjnaRewardsMerkleTreePayload<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
  objects: {}
  scalars: $Extensions.GetResult<{
    id: number
    timestamp: Date
    chain_id: number
    week_number: number
    tree_root: string
    tx_processed: boolean
  }, ExtArgs["result"]["ajnaRewardsMerkleTree"]>
  composites: {}
}

/**
 * Model AjnaRewardsMerkleTree
 * 
 */
export type AjnaRewardsMerkleTree = runtime.Types.DefaultSelection<AjnaRewardsMerkleTreePayload>

/**
 * Enums
 */

export const VaultType: {
  borrow: 'borrow',
  multiply: 'multiply'
};

export type VaultType = (typeof VaultType)[keyof typeof VaultType]


export const Protocol: {
  maker: 'maker',
  aavev2: 'aavev2',
  aavev3: 'aavev3',
  ajna: 'ajna'
};

export type Protocol = (typeof Protocol)[keyof typeof Protocol]


export const NetworkNames: {
  ethereum: 'ethereum',
  arbitrum: 'arbitrum',
  polygon: 'polygon',
  optimism: 'optimism'
};

export type NetworkNames = (typeof NetworkNames)[keyof typeof NetworkNames]


export const ProductHubManagementSimple: {
  active: 'active',
  passive: 'passive'
};

export type ProductHubManagementSimple = (typeof ProductHubManagementSimple)[keyof typeof ProductHubManagementSimple]


export const ProductHubStrategy: {
  long: 'long',
  short: 'short'
};

export type ProductHubStrategy = (typeof ProductHubStrategy)[keyof typeof ProductHubStrategy]


export const Product: {
  borrow: 'borrow',
  multiply: 'multiply',
  earn: 'earn'
};

export type Product = (typeof Product)[keyof typeof Product]


/**
 * ##  Prisma Client ʲˢ
 * 
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Migrations
 * const migrations = await prisma.migrations.findMany()
 * ```
 *
 * 
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  T extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof T ? T['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<T['log']> : never : never,
  GlobalReject extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined = 'rejectOnNotFound' extends keyof T
    ? T['rejectOnNotFound']
    : false,
  ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   * 
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Migrations
   * const migrations = await prisma.migrations.findMany()
   * ```
   *
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<T, Prisma.PrismaClientOptions>);
  $on<V extends (U | 'beforeExit')>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : V extends 'beforeExit' ? () => Promise<void> : Prisma.LogEvent) => void): void;

  /**
   * Connect with the database
   */
  $connect(): Promise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): Promise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): Promise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => Promise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): Promise<R>


  $extends: $Extensions.ExtendsHook<'extends', Prisma.TypeMapCb, ExtArgs>

      /**
   * `prisma.migrations`: Exposes CRUD operations for the **migrations** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Migrations
    * const migrations = await prisma.migrations.findMany()
    * ```
    */
  get migrations(): Prisma.migrationsDelegate<GlobalReject, ExtArgs>;

  /**
   * `prisma.tosApproval`: Exposes CRUD operations for the **TosApproval** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more TosApprovals
    * const tosApprovals = await prisma.tosApproval.findMany()
    * ```
    */
  get tosApproval(): Prisma.TosApprovalDelegate<GlobalReject, ExtArgs>;

  /**
   * `prisma.vault`: Exposes CRUD operations for the **Vault** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Vaults
    * const vaults = await prisma.vault.findMany()
    * ```
    */
  get vault(): Prisma.VaultDelegate<GlobalReject, ExtArgs>;

  /**
   * `prisma.user`: Exposes CRUD operations for the **User** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.user.findMany()
    * ```
    */
  get user(): Prisma.UserDelegate<GlobalReject, ExtArgs>;

  /**
   * `prisma.weeklyClaim`: Exposes CRUD operations for the **WeeklyClaim** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more WeeklyClaims
    * const weeklyClaims = await prisma.weeklyClaim.findMany()
    * ```
    */
  get weeklyClaim(): Prisma.WeeklyClaimDelegate<GlobalReject, ExtArgs>;

  /**
   * `prisma.merkleTree`: Exposes CRUD operations for the **MerkleTree** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more MerkleTrees
    * const merkleTrees = await prisma.merkleTree.findMany()
    * ```
    */
  get merkleTree(): Prisma.MerkleTreeDelegate<GlobalReject, ExtArgs>;

  /**
   * `prisma.walletRisk`: Exposes CRUD operations for the **WalletRisk** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more WalletRisks
    * const walletRisks = await prisma.walletRisk.findMany()
    * ```
    */
  get walletRisk(): Prisma.WalletRiskDelegate<GlobalReject, ExtArgs>;

  /**
   * `prisma.collateralType`: Exposes CRUD operations for the **CollateralType** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more CollateralTypes
    * const collateralTypes = await prisma.collateralType.findMany()
    * ```
    */
  get collateralType(): Prisma.CollateralTypeDelegate<GlobalReject, ExtArgs>;

  /**
   * `prisma.discover`: Exposes CRUD operations for the **Discover** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Discovers
    * const discovers = await prisma.discover.findMany()
    * ```
    */
  get discover(): Prisma.DiscoverDelegate<GlobalReject, ExtArgs>;

  /**
   * `prisma.highestRiskPositions`: Exposes CRUD operations for the **HighestRiskPositions** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more HighestRiskPositions
    * const highestRiskPositions = await prisma.highestRiskPositions.findMany()
    * ```
    */
  get highestRiskPositions(): Prisma.HighestRiskPositionsDelegate<GlobalReject, ExtArgs>;

  /**
   * `prisma.highestMultiplyPnl`: Exposes CRUD operations for the **HighestMultiplyPnl** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more HighestMultiplyPnls
    * const highestMultiplyPnls = await prisma.highestMultiplyPnl.findMany()
    * ```
    */
  get highestMultiplyPnl(): Prisma.HighestMultiplyPnlDelegate<GlobalReject, ExtArgs>;

  /**
   * `prisma.mostYieldEarned`: Exposes CRUD operations for the **MostYieldEarned** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more MostYieldEarneds
    * const mostYieldEarneds = await prisma.mostYieldEarned.findMany()
    * ```
    */
  get mostYieldEarned(): Prisma.MostYieldEarnedDelegate<GlobalReject, ExtArgs>;

  /**
   * `prisma.largestDebt`: Exposes CRUD operations for the **LargestDebt** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more LargestDebts
    * const largestDebts = await prisma.largestDebt.findMany()
    * ```
    */
  get largestDebt(): Prisma.LargestDebtDelegate<GlobalReject, ExtArgs>;

  /**
   * `prisma.usersWhoFollowVaults`: Exposes CRUD operations for the **UsersWhoFollowVaults** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more UsersWhoFollowVaults
    * const usersWhoFollowVaults = await prisma.usersWhoFollowVaults.findMany()
    * ```
    */
  get usersWhoFollowVaults(): Prisma.UsersWhoFollowVaultsDelegate<GlobalReject, ExtArgs>;

  /**
   * `prisma.productHubItems`: Exposes CRUD operations for the **ProductHubItems** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more ProductHubItems
    * const productHubItems = await prisma.productHubItems.findMany()
    * ```
    */
  get productHubItems(): Prisma.ProductHubItemsDelegate<GlobalReject, ExtArgs>;

  /**
   * `prisma.ajnaRewardsWeeklyClaim`: Exposes CRUD operations for the **AjnaRewardsWeeklyClaim** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more AjnaRewardsWeeklyClaims
    * const ajnaRewardsWeeklyClaims = await prisma.ajnaRewardsWeeklyClaim.findMany()
    * ```
    */
  get ajnaRewardsWeeklyClaim(): Prisma.AjnaRewardsWeeklyClaimDelegate<GlobalReject, ExtArgs>;

  /**
   * `prisma.ajnaRewardsDailyClaim`: Exposes CRUD operations for the **AjnaRewardsDailyClaim** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more AjnaRewardsDailyClaims
    * const ajnaRewardsDailyClaims = await prisma.ajnaRewardsDailyClaim.findMany()
    * ```
    */
  get ajnaRewardsDailyClaim(): Prisma.AjnaRewardsDailyClaimDelegate<GlobalReject, ExtArgs>;

  /**
   * `prisma.ajnaRewardsMerkleTree`: Exposes CRUD operations for the **AjnaRewardsMerkleTree** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more AjnaRewardsMerkleTrees
    * const ajnaRewardsMerkleTrees = await prisma.ajnaRewardsMerkleTree.findMany()
    * ```
    */
  get ajnaRewardsMerkleTree(): Prisma.AjnaRewardsMerkleTreeDelegate<GlobalReject, ExtArgs>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError
  export import NotFoundError = runtime.NotFoundError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql

  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics 
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export type Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export type Args<T, F extends $Public.Operation> = $Public.Args<T, F>
  export type Payload<T, F extends $Public.Operation> = $Public.Payload<T, F>
  export type Result<T, A, F extends $Public.Operation> = $Public.Result<T, A, F>
  export type Exact<T, W> = $Public.Exact<T, W>

  /**
   * Prisma Client JS version: 4.16.1
   * Query Engine version: b20ead4d3ab9e78ac112966e242ded703f4a052c
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion 

  /**
   * Utility Types
   */

  /**
   * From https://github.com/sindresorhus/type-fest/
   * Matches a JSON object.
   * This type can be useful to enforce some input to be JSON-compatible or as a super-type to be extended from. 
   */
  export type JsonObject = {[Key in string]?: JsonValue}

  /**
   * From https://github.com/sindresorhus/type-fest/
   * Matches a JSON array.
   */
  export interface JsonArray extends Array<JsonValue> {}

  /**
   * From https://github.com/sindresorhus/type-fest/
   * Matches any valid JSON value.
   */
  export type JsonValue = string | number | boolean | JsonObject | JsonArray | null

  /**
   * Matches a JSON object.
   * Unlike `JsonObject`, this type allows undefined and read-only properties.
   */
  export type InputJsonObject = {readonly [Key in string]?: InputJsonValue | null}

  /**
   * Matches a JSON array.
   * Unlike `JsonArray`, readonly arrays are assignable to this type.
   */
  export interface InputJsonArray extends ReadonlyArray<InputJsonValue | null> {}

  /**
   * Matches any valid value that can be used as an input for operations like
   * create and update as the value of a JSON field. Unlike `JsonValue`, this
   * type allows read-only arrays and read-only object properties and disallows
   * `null` at the top level.
   *
   * `null` cannot be used as the value of a JSON field because its meaning
   * would be ambiguous. Use `Prisma.JsonNull` to store the JSON null value or
   * `Prisma.DbNull` to clear the JSON value and set the field to the database
   * NULL value instead.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-by-null-values
   */
  export type InputJsonValue = string | number | boolean | InputJsonObject | InputJsonArray

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    * 
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    * 
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    * 
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    * 
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    * 
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    * 
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }
  type HasSelect = {
    select: any
  }
  type HasInclude = {
    include: any
  }
  type CheckSelect<T, S, U> = T extends SelectAndInclude
    ? 'Please either choose `select` or `include`'
    : T extends HasSelect
    ? U
    : T extends HasInclude
    ? U
    : S

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => Promise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? K : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but with an array
   */
  type PickArray<T, K extends Array<keyof T>> = Prisma__Pick<T, TupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    migrations: 'migrations',
    TosApproval: 'TosApproval',
    Vault: 'Vault',
    User: 'User',
    WeeklyClaim: 'WeeklyClaim',
    MerkleTree: 'MerkleTree',
    WalletRisk: 'WalletRisk',
    CollateralType: 'CollateralType',
    Discover: 'Discover',
    HighestRiskPositions: 'HighestRiskPositions',
    HighestMultiplyPnl: 'HighestMultiplyPnl',
    MostYieldEarned: 'MostYieldEarned',
    LargestDebt: 'LargestDebt',
    UsersWhoFollowVaults: 'UsersWhoFollowVaults',
    ProductHubItems: 'ProductHubItems',
    AjnaRewardsWeeklyClaim: 'AjnaRewardsWeeklyClaim',
    AjnaRewardsDailyClaim: 'AjnaRewardsDailyClaim',
    AjnaRewardsMerkleTree: 'AjnaRewardsMerkleTree'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }


  interface TypeMapCb extends $Utils.Fn<{extArgs: $Extensions.Args}, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs']>
  }

  export type TypeMap<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    meta: {
      modelProps: 'migrations' | 'tosApproval' | 'vault' | 'user' | 'weeklyClaim' | 'merkleTree' | 'walletRisk' | 'collateralType' | 'discover' | 'highestRiskPositions' | 'highestMultiplyPnl' | 'mostYieldEarned' | 'largestDebt' | 'usersWhoFollowVaults' | 'productHubItems' | 'ajnaRewardsWeeklyClaim' | 'ajnaRewardsDailyClaim' | 'ajnaRewardsMerkleTree'
      txIsolationLevel: Prisma.TransactionIsolationLevel
    },
    model: {
      migrations: {
        operations: {
          findUnique: {
            args: Prisma.migrationsFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<migrationsPayload> | null
            payload: migrationsPayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.migrationsFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<migrationsPayload>
            payload: migrationsPayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.migrationsFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<migrationsPayload> | null
            payload: migrationsPayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.migrationsFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<migrationsPayload>
            payload: migrationsPayload<ExtArgs>
          }
          findMany: {
            args: Prisma.migrationsFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<migrationsPayload>[]
            payload: migrationsPayload<ExtArgs>
          }
          create: {
            args: Prisma.migrationsCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<migrationsPayload>
            payload: migrationsPayload<ExtArgs>
          }
          createMany: {
            args: Prisma.migrationsCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: migrationsPayload<ExtArgs>
          }
          delete: {
            args: Prisma.migrationsDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<migrationsPayload>
            payload: migrationsPayload<ExtArgs>
          }
          update: {
            args: Prisma.migrationsUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<migrationsPayload>
            payload: migrationsPayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.migrationsDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: migrationsPayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.migrationsUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: migrationsPayload<ExtArgs>
          }
          upsert: {
            args: Prisma.migrationsUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<migrationsPayload>
            payload: migrationsPayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.MigrationsAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateMigrations>
            payload: migrationsPayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.MigrationsGroupByArgs<ExtArgs>,
            result: $Utils.Optional<MigrationsGroupByOutputType>[]
            payload: migrationsPayload<ExtArgs>
          }
          count: {
            args: Prisma.migrationsCountArgs<ExtArgs>,
            result: $Utils.Optional<MigrationsCountAggregateOutputType> | number
            payload: migrationsPayload<ExtArgs>
          }
        }
      }
      TosApproval: {
        operations: {
          findUnique: {
            args: Prisma.TosApprovalFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<TosApprovalPayload> | null
            payload: TosApprovalPayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.TosApprovalFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<TosApprovalPayload>
            payload: TosApprovalPayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.TosApprovalFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<TosApprovalPayload> | null
            payload: TosApprovalPayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.TosApprovalFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<TosApprovalPayload>
            payload: TosApprovalPayload<ExtArgs>
          }
          findMany: {
            args: Prisma.TosApprovalFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<TosApprovalPayload>[]
            payload: TosApprovalPayload<ExtArgs>
          }
          create: {
            args: Prisma.TosApprovalCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<TosApprovalPayload>
            payload: TosApprovalPayload<ExtArgs>
          }
          createMany: {
            args: Prisma.TosApprovalCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: TosApprovalPayload<ExtArgs>
          }
          delete: {
            args: Prisma.TosApprovalDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<TosApprovalPayload>
            payload: TosApprovalPayload<ExtArgs>
          }
          update: {
            args: Prisma.TosApprovalUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<TosApprovalPayload>
            payload: TosApprovalPayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.TosApprovalDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: TosApprovalPayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.TosApprovalUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: TosApprovalPayload<ExtArgs>
          }
          upsert: {
            args: Prisma.TosApprovalUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<TosApprovalPayload>
            payload: TosApprovalPayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.TosApprovalAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateTosApproval>
            payload: TosApprovalPayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.TosApprovalGroupByArgs<ExtArgs>,
            result: $Utils.Optional<TosApprovalGroupByOutputType>[]
            payload: TosApprovalPayload<ExtArgs>
          }
          count: {
            args: Prisma.TosApprovalCountArgs<ExtArgs>,
            result: $Utils.Optional<TosApprovalCountAggregateOutputType> | number
            payload: TosApprovalPayload<ExtArgs>
          }
        }
      }
      Vault: {
        operations: {
          findUnique: {
            args: Prisma.VaultFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<VaultPayload> | null
            payload: VaultPayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.VaultFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<VaultPayload>
            payload: VaultPayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.VaultFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<VaultPayload> | null
            payload: VaultPayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.VaultFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<VaultPayload>
            payload: VaultPayload<ExtArgs>
          }
          findMany: {
            args: Prisma.VaultFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<VaultPayload>[]
            payload: VaultPayload<ExtArgs>
          }
          create: {
            args: Prisma.VaultCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<VaultPayload>
            payload: VaultPayload<ExtArgs>
          }
          createMany: {
            args: Prisma.VaultCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: VaultPayload<ExtArgs>
          }
          delete: {
            args: Prisma.VaultDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<VaultPayload>
            payload: VaultPayload<ExtArgs>
          }
          update: {
            args: Prisma.VaultUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<VaultPayload>
            payload: VaultPayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.VaultDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: VaultPayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.VaultUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: VaultPayload<ExtArgs>
          }
          upsert: {
            args: Prisma.VaultUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<VaultPayload>
            payload: VaultPayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.VaultAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateVault>
            payload: VaultPayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.VaultGroupByArgs<ExtArgs>,
            result: $Utils.Optional<VaultGroupByOutputType>[]
            payload: VaultPayload<ExtArgs>
          }
          count: {
            args: Prisma.VaultCountArgs<ExtArgs>,
            result: $Utils.Optional<VaultCountAggregateOutputType> | number
            payload: VaultPayload<ExtArgs>
          }
        }
      }
      User: {
        operations: {
          findUnique: {
            args: Prisma.UserFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UserPayload> | null
            payload: UserPayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.UserFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UserPayload>
            payload: UserPayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.UserFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UserPayload> | null
            payload: UserPayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.UserFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UserPayload>
            payload: UserPayload<ExtArgs>
          }
          findMany: {
            args: Prisma.UserFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UserPayload>[]
            payload: UserPayload<ExtArgs>
          }
          create: {
            args: Prisma.UserCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UserPayload>
            payload: UserPayload<ExtArgs>
          }
          createMany: {
            args: Prisma.UserCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: UserPayload<ExtArgs>
          }
          delete: {
            args: Prisma.UserDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UserPayload>
            payload: UserPayload<ExtArgs>
          }
          update: {
            args: Prisma.UserUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UserPayload>
            payload: UserPayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.UserDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: UserPayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.UserUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: UserPayload<ExtArgs>
          }
          upsert: {
            args: Prisma.UserUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UserPayload>
            payload: UserPayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.UserAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateUser>
            payload: UserPayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.UserGroupByArgs<ExtArgs>,
            result: $Utils.Optional<UserGroupByOutputType>[]
            payload: UserPayload<ExtArgs>
          }
          count: {
            args: Prisma.UserCountArgs<ExtArgs>,
            result: $Utils.Optional<UserCountAggregateOutputType> | number
            payload: UserPayload<ExtArgs>
          }
        }
      }
      WeeklyClaim: {
        operations: {
          findUnique: {
            args: Prisma.WeeklyClaimFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WeeklyClaimPayload> | null
            payload: WeeklyClaimPayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.WeeklyClaimFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WeeklyClaimPayload>
            payload: WeeklyClaimPayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.WeeklyClaimFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WeeklyClaimPayload> | null
            payload: WeeklyClaimPayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.WeeklyClaimFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WeeklyClaimPayload>
            payload: WeeklyClaimPayload<ExtArgs>
          }
          findMany: {
            args: Prisma.WeeklyClaimFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WeeklyClaimPayload>[]
            payload: WeeklyClaimPayload<ExtArgs>
          }
          create: {
            args: Prisma.WeeklyClaimCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WeeklyClaimPayload>
            payload: WeeklyClaimPayload<ExtArgs>
          }
          createMany: {
            args: Prisma.WeeklyClaimCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: WeeklyClaimPayload<ExtArgs>
          }
          delete: {
            args: Prisma.WeeklyClaimDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WeeklyClaimPayload>
            payload: WeeklyClaimPayload<ExtArgs>
          }
          update: {
            args: Prisma.WeeklyClaimUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WeeklyClaimPayload>
            payload: WeeklyClaimPayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.WeeklyClaimDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: WeeklyClaimPayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.WeeklyClaimUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: WeeklyClaimPayload<ExtArgs>
          }
          upsert: {
            args: Prisma.WeeklyClaimUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WeeklyClaimPayload>
            payload: WeeklyClaimPayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.WeeklyClaimAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateWeeklyClaim>
            payload: WeeklyClaimPayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.WeeklyClaimGroupByArgs<ExtArgs>,
            result: $Utils.Optional<WeeklyClaimGroupByOutputType>[]
            payload: WeeklyClaimPayload<ExtArgs>
          }
          count: {
            args: Prisma.WeeklyClaimCountArgs<ExtArgs>,
            result: $Utils.Optional<WeeklyClaimCountAggregateOutputType> | number
            payload: WeeklyClaimPayload<ExtArgs>
          }
        }
      }
      MerkleTree: {
        operations: {
          findUnique: {
            args: Prisma.MerkleTreeFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MerkleTreePayload> | null
            payload: MerkleTreePayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.MerkleTreeFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MerkleTreePayload>
            payload: MerkleTreePayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.MerkleTreeFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MerkleTreePayload> | null
            payload: MerkleTreePayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.MerkleTreeFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MerkleTreePayload>
            payload: MerkleTreePayload<ExtArgs>
          }
          findMany: {
            args: Prisma.MerkleTreeFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MerkleTreePayload>[]
            payload: MerkleTreePayload<ExtArgs>
          }
          create: {
            args: Prisma.MerkleTreeCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MerkleTreePayload>
            payload: MerkleTreePayload<ExtArgs>
          }
          createMany: {
            args: Prisma.MerkleTreeCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: MerkleTreePayload<ExtArgs>
          }
          delete: {
            args: Prisma.MerkleTreeDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MerkleTreePayload>
            payload: MerkleTreePayload<ExtArgs>
          }
          update: {
            args: Prisma.MerkleTreeUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MerkleTreePayload>
            payload: MerkleTreePayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.MerkleTreeDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: MerkleTreePayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.MerkleTreeUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: MerkleTreePayload<ExtArgs>
          }
          upsert: {
            args: Prisma.MerkleTreeUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MerkleTreePayload>
            payload: MerkleTreePayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.MerkleTreeAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateMerkleTree>
            payload: MerkleTreePayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.MerkleTreeGroupByArgs<ExtArgs>,
            result: $Utils.Optional<MerkleTreeGroupByOutputType>[]
            payload: MerkleTreePayload<ExtArgs>
          }
          count: {
            args: Prisma.MerkleTreeCountArgs<ExtArgs>,
            result: $Utils.Optional<MerkleTreeCountAggregateOutputType> | number
            payload: MerkleTreePayload<ExtArgs>
          }
        }
      }
      WalletRisk: {
        operations: {
          findUnique: {
            args: Prisma.WalletRiskFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WalletRiskPayload> | null
            payload: WalletRiskPayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.WalletRiskFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WalletRiskPayload>
            payload: WalletRiskPayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.WalletRiskFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WalletRiskPayload> | null
            payload: WalletRiskPayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.WalletRiskFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WalletRiskPayload>
            payload: WalletRiskPayload<ExtArgs>
          }
          findMany: {
            args: Prisma.WalletRiskFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WalletRiskPayload>[]
            payload: WalletRiskPayload<ExtArgs>
          }
          create: {
            args: Prisma.WalletRiskCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WalletRiskPayload>
            payload: WalletRiskPayload<ExtArgs>
          }
          createMany: {
            args: Prisma.WalletRiskCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: WalletRiskPayload<ExtArgs>
          }
          delete: {
            args: Prisma.WalletRiskDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WalletRiskPayload>
            payload: WalletRiskPayload<ExtArgs>
          }
          update: {
            args: Prisma.WalletRiskUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WalletRiskPayload>
            payload: WalletRiskPayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.WalletRiskDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: WalletRiskPayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.WalletRiskUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: WalletRiskPayload<ExtArgs>
          }
          upsert: {
            args: Prisma.WalletRiskUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<WalletRiskPayload>
            payload: WalletRiskPayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.WalletRiskAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateWalletRisk>
            payload: WalletRiskPayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.WalletRiskGroupByArgs<ExtArgs>,
            result: $Utils.Optional<WalletRiskGroupByOutputType>[]
            payload: WalletRiskPayload<ExtArgs>
          }
          count: {
            args: Prisma.WalletRiskCountArgs<ExtArgs>,
            result: $Utils.Optional<WalletRiskCountAggregateOutputType> | number
            payload: WalletRiskPayload<ExtArgs>
          }
        }
      }
      CollateralType: {
        operations: {
          findUnique: {
            args: Prisma.CollateralTypeFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<CollateralTypePayload> | null
            payload: CollateralTypePayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.CollateralTypeFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<CollateralTypePayload>
            payload: CollateralTypePayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.CollateralTypeFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<CollateralTypePayload> | null
            payload: CollateralTypePayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.CollateralTypeFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<CollateralTypePayload>
            payload: CollateralTypePayload<ExtArgs>
          }
          findMany: {
            args: Prisma.CollateralTypeFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<CollateralTypePayload>[]
            payload: CollateralTypePayload<ExtArgs>
          }
          create: {
            args: Prisma.CollateralTypeCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<CollateralTypePayload>
            payload: CollateralTypePayload<ExtArgs>
          }
          createMany: {
            args: Prisma.CollateralTypeCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: CollateralTypePayload<ExtArgs>
          }
          delete: {
            args: Prisma.CollateralTypeDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<CollateralTypePayload>
            payload: CollateralTypePayload<ExtArgs>
          }
          update: {
            args: Prisma.CollateralTypeUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<CollateralTypePayload>
            payload: CollateralTypePayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.CollateralTypeDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: CollateralTypePayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.CollateralTypeUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: CollateralTypePayload<ExtArgs>
          }
          upsert: {
            args: Prisma.CollateralTypeUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<CollateralTypePayload>
            payload: CollateralTypePayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.CollateralTypeAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateCollateralType>
            payload: CollateralTypePayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.CollateralTypeGroupByArgs<ExtArgs>,
            result: $Utils.Optional<CollateralTypeGroupByOutputType>[]
            payload: CollateralTypePayload<ExtArgs>
          }
          count: {
            args: Prisma.CollateralTypeCountArgs<ExtArgs>,
            result: $Utils.Optional<CollateralTypeCountAggregateOutputType> | number
            payload: CollateralTypePayload<ExtArgs>
          }
        }
      }
      Discover: {
        operations: {
          findUnique: {
            args: Prisma.DiscoverFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<DiscoverPayload> | null
            payload: DiscoverPayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.DiscoverFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<DiscoverPayload>
            payload: DiscoverPayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.DiscoverFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<DiscoverPayload> | null
            payload: DiscoverPayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.DiscoverFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<DiscoverPayload>
            payload: DiscoverPayload<ExtArgs>
          }
          findMany: {
            args: Prisma.DiscoverFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<DiscoverPayload>[]
            payload: DiscoverPayload<ExtArgs>
          }
          create: {
            args: Prisma.DiscoverCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<DiscoverPayload>
            payload: DiscoverPayload<ExtArgs>
          }
          createMany: {
            args: Prisma.DiscoverCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: DiscoverPayload<ExtArgs>
          }
          delete: {
            args: Prisma.DiscoverDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<DiscoverPayload>
            payload: DiscoverPayload<ExtArgs>
          }
          update: {
            args: Prisma.DiscoverUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<DiscoverPayload>
            payload: DiscoverPayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.DiscoverDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: DiscoverPayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.DiscoverUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: DiscoverPayload<ExtArgs>
          }
          upsert: {
            args: Prisma.DiscoverUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<DiscoverPayload>
            payload: DiscoverPayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.DiscoverAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateDiscover>
            payload: DiscoverPayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.DiscoverGroupByArgs<ExtArgs>,
            result: $Utils.Optional<DiscoverGroupByOutputType>[]
            payload: DiscoverPayload<ExtArgs>
          }
          count: {
            args: Prisma.DiscoverCountArgs<ExtArgs>,
            result: $Utils.Optional<DiscoverCountAggregateOutputType> | number
            payload: DiscoverPayload<ExtArgs>
          }
        }
      }
      HighestRiskPositions: {
        operations: {
          findUnique: {
            args: Prisma.HighestRiskPositionsFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestRiskPositionsPayload> | null
            payload: HighestRiskPositionsPayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.HighestRiskPositionsFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestRiskPositionsPayload>
            payload: HighestRiskPositionsPayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.HighestRiskPositionsFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestRiskPositionsPayload> | null
            payload: HighestRiskPositionsPayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.HighestRiskPositionsFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestRiskPositionsPayload>
            payload: HighestRiskPositionsPayload<ExtArgs>
          }
          findMany: {
            args: Prisma.HighestRiskPositionsFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestRiskPositionsPayload>[]
            payload: HighestRiskPositionsPayload<ExtArgs>
          }
          create: {
            args: Prisma.HighestRiskPositionsCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestRiskPositionsPayload>
            payload: HighestRiskPositionsPayload<ExtArgs>
          }
          createMany: {
            args: Prisma.HighestRiskPositionsCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: HighestRiskPositionsPayload<ExtArgs>
          }
          delete: {
            args: Prisma.HighestRiskPositionsDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestRiskPositionsPayload>
            payload: HighestRiskPositionsPayload<ExtArgs>
          }
          update: {
            args: Prisma.HighestRiskPositionsUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestRiskPositionsPayload>
            payload: HighestRiskPositionsPayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.HighestRiskPositionsDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: HighestRiskPositionsPayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.HighestRiskPositionsUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: HighestRiskPositionsPayload<ExtArgs>
          }
          upsert: {
            args: Prisma.HighestRiskPositionsUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestRiskPositionsPayload>
            payload: HighestRiskPositionsPayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.HighestRiskPositionsAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateHighestRiskPositions>
            payload: HighestRiskPositionsPayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.HighestRiskPositionsGroupByArgs<ExtArgs>,
            result: $Utils.Optional<HighestRiskPositionsGroupByOutputType>[]
            payload: HighestRiskPositionsPayload<ExtArgs>
          }
          count: {
            args: Prisma.HighestRiskPositionsCountArgs<ExtArgs>,
            result: $Utils.Optional<HighestRiskPositionsCountAggregateOutputType> | number
            payload: HighestRiskPositionsPayload<ExtArgs>
          }
        }
      }
      HighestMultiplyPnl: {
        operations: {
          findUnique: {
            args: Prisma.HighestMultiplyPnlFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestMultiplyPnlPayload> | null
            payload: HighestMultiplyPnlPayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.HighestMultiplyPnlFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestMultiplyPnlPayload>
            payload: HighestMultiplyPnlPayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.HighestMultiplyPnlFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestMultiplyPnlPayload> | null
            payload: HighestMultiplyPnlPayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.HighestMultiplyPnlFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestMultiplyPnlPayload>
            payload: HighestMultiplyPnlPayload<ExtArgs>
          }
          findMany: {
            args: Prisma.HighestMultiplyPnlFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestMultiplyPnlPayload>[]
            payload: HighestMultiplyPnlPayload<ExtArgs>
          }
          create: {
            args: Prisma.HighestMultiplyPnlCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestMultiplyPnlPayload>
            payload: HighestMultiplyPnlPayload<ExtArgs>
          }
          createMany: {
            args: Prisma.HighestMultiplyPnlCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: HighestMultiplyPnlPayload<ExtArgs>
          }
          delete: {
            args: Prisma.HighestMultiplyPnlDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestMultiplyPnlPayload>
            payload: HighestMultiplyPnlPayload<ExtArgs>
          }
          update: {
            args: Prisma.HighestMultiplyPnlUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestMultiplyPnlPayload>
            payload: HighestMultiplyPnlPayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.HighestMultiplyPnlDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: HighestMultiplyPnlPayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.HighestMultiplyPnlUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: HighestMultiplyPnlPayload<ExtArgs>
          }
          upsert: {
            args: Prisma.HighestMultiplyPnlUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<HighestMultiplyPnlPayload>
            payload: HighestMultiplyPnlPayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.HighestMultiplyPnlAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateHighestMultiplyPnl>
            payload: HighestMultiplyPnlPayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.HighestMultiplyPnlGroupByArgs<ExtArgs>,
            result: $Utils.Optional<HighestMultiplyPnlGroupByOutputType>[]
            payload: HighestMultiplyPnlPayload<ExtArgs>
          }
          count: {
            args: Prisma.HighestMultiplyPnlCountArgs<ExtArgs>,
            result: $Utils.Optional<HighestMultiplyPnlCountAggregateOutputType> | number
            payload: HighestMultiplyPnlPayload<ExtArgs>
          }
        }
      }
      MostYieldEarned: {
        operations: {
          findUnique: {
            args: Prisma.MostYieldEarnedFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MostYieldEarnedPayload> | null
            payload: MostYieldEarnedPayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.MostYieldEarnedFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MostYieldEarnedPayload>
            payload: MostYieldEarnedPayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.MostYieldEarnedFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MostYieldEarnedPayload> | null
            payload: MostYieldEarnedPayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.MostYieldEarnedFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MostYieldEarnedPayload>
            payload: MostYieldEarnedPayload<ExtArgs>
          }
          findMany: {
            args: Prisma.MostYieldEarnedFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MostYieldEarnedPayload>[]
            payload: MostYieldEarnedPayload<ExtArgs>
          }
          create: {
            args: Prisma.MostYieldEarnedCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MostYieldEarnedPayload>
            payload: MostYieldEarnedPayload<ExtArgs>
          }
          createMany: {
            args: Prisma.MostYieldEarnedCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: MostYieldEarnedPayload<ExtArgs>
          }
          delete: {
            args: Prisma.MostYieldEarnedDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MostYieldEarnedPayload>
            payload: MostYieldEarnedPayload<ExtArgs>
          }
          update: {
            args: Prisma.MostYieldEarnedUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MostYieldEarnedPayload>
            payload: MostYieldEarnedPayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.MostYieldEarnedDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: MostYieldEarnedPayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.MostYieldEarnedUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: MostYieldEarnedPayload<ExtArgs>
          }
          upsert: {
            args: Prisma.MostYieldEarnedUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<MostYieldEarnedPayload>
            payload: MostYieldEarnedPayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.MostYieldEarnedAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateMostYieldEarned>
            payload: MostYieldEarnedPayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.MostYieldEarnedGroupByArgs<ExtArgs>,
            result: $Utils.Optional<MostYieldEarnedGroupByOutputType>[]
            payload: MostYieldEarnedPayload<ExtArgs>
          }
          count: {
            args: Prisma.MostYieldEarnedCountArgs<ExtArgs>,
            result: $Utils.Optional<MostYieldEarnedCountAggregateOutputType> | number
            payload: MostYieldEarnedPayload<ExtArgs>
          }
        }
      }
      LargestDebt: {
        operations: {
          findUnique: {
            args: Prisma.LargestDebtFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<LargestDebtPayload> | null
            payload: LargestDebtPayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.LargestDebtFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<LargestDebtPayload>
            payload: LargestDebtPayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.LargestDebtFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<LargestDebtPayload> | null
            payload: LargestDebtPayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.LargestDebtFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<LargestDebtPayload>
            payload: LargestDebtPayload<ExtArgs>
          }
          findMany: {
            args: Prisma.LargestDebtFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<LargestDebtPayload>[]
            payload: LargestDebtPayload<ExtArgs>
          }
          create: {
            args: Prisma.LargestDebtCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<LargestDebtPayload>
            payload: LargestDebtPayload<ExtArgs>
          }
          createMany: {
            args: Prisma.LargestDebtCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: LargestDebtPayload<ExtArgs>
          }
          delete: {
            args: Prisma.LargestDebtDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<LargestDebtPayload>
            payload: LargestDebtPayload<ExtArgs>
          }
          update: {
            args: Prisma.LargestDebtUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<LargestDebtPayload>
            payload: LargestDebtPayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.LargestDebtDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: LargestDebtPayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.LargestDebtUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: LargestDebtPayload<ExtArgs>
          }
          upsert: {
            args: Prisma.LargestDebtUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<LargestDebtPayload>
            payload: LargestDebtPayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.LargestDebtAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateLargestDebt>
            payload: LargestDebtPayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.LargestDebtGroupByArgs<ExtArgs>,
            result: $Utils.Optional<LargestDebtGroupByOutputType>[]
            payload: LargestDebtPayload<ExtArgs>
          }
          count: {
            args: Prisma.LargestDebtCountArgs<ExtArgs>,
            result: $Utils.Optional<LargestDebtCountAggregateOutputType> | number
            payload: LargestDebtPayload<ExtArgs>
          }
        }
      }
      UsersWhoFollowVaults: {
        operations: {
          findUnique: {
            args: Prisma.UsersWhoFollowVaultsFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UsersWhoFollowVaultsPayload> | null
            payload: UsersWhoFollowVaultsPayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.UsersWhoFollowVaultsFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UsersWhoFollowVaultsPayload>
            payload: UsersWhoFollowVaultsPayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.UsersWhoFollowVaultsFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UsersWhoFollowVaultsPayload> | null
            payload: UsersWhoFollowVaultsPayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.UsersWhoFollowVaultsFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UsersWhoFollowVaultsPayload>
            payload: UsersWhoFollowVaultsPayload<ExtArgs>
          }
          findMany: {
            args: Prisma.UsersWhoFollowVaultsFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UsersWhoFollowVaultsPayload>[]
            payload: UsersWhoFollowVaultsPayload<ExtArgs>
          }
          create: {
            args: Prisma.UsersWhoFollowVaultsCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UsersWhoFollowVaultsPayload>
            payload: UsersWhoFollowVaultsPayload<ExtArgs>
          }
          createMany: {
            args: Prisma.UsersWhoFollowVaultsCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: UsersWhoFollowVaultsPayload<ExtArgs>
          }
          delete: {
            args: Prisma.UsersWhoFollowVaultsDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UsersWhoFollowVaultsPayload>
            payload: UsersWhoFollowVaultsPayload<ExtArgs>
          }
          update: {
            args: Prisma.UsersWhoFollowVaultsUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UsersWhoFollowVaultsPayload>
            payload: UsersWhoFollowVaultsPayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.UsersWhoFollowVaultsDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: UsersWhoFollowVaultsPayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.UsersWhoFollowVaultsUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: UsersWhoFollowVaultsPayload<ExtArgs>
          }
          upsert: {
            args: Prisma.UsersWhoFollowVaultsUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<UsersWhoFollowVaultsPayload>
            payload: UsersWhoFollowVaultsPayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.UsersWhoFollowVaultsAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateUsersWhoFollowVaults>
            payload: UsersWhoFollowVaultsPayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.UsersWhoFollowVaultsGroupByArgs<ExtArgs>,
            result: $Utils.Optional<UsersWhoFollowVaultsGroupByOutputType>[]
            payload: UsersWhoFollowVaultsPayload<ExtArgs>
          }
          count: {
            args: Prisma.UsersWhoFollowVaultsCountArgs<ExtArgs>,
            result: $Utils.Optional<UsersWhoFollowVaultsCountAggregateOutputType> | number
            payload: UsersWhoFollowVaultsPayload<ExtArgs>
          }
        }
      }
      ProductHubItems: {
        operations: {
          findUnique: {
            args: Prisma.ProductHubItemsFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<ProductHubItemsPayload> | null
            payload: ProductHubItemsPayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.ProductHubItemsFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<ProductHubItemsPayload>
            payload: ProductHubItemsPayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.ProductHubItemsFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<ProductHubItemsPayload> | null
            payload: ProductHubItemsPayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.ProductHubItemsFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<ProductHubItemsPayload>
            payload: ProductHubItemsPayload<ExtArgs>
          }
          findMany: {
            args: Prisma.ProductHubItemsFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<ProductHubItemsPayload>[]
            payload: ProductHubItemsPayload<ExtArgs>
          }
          create: {
            args: Prisma.ProductHubItemsCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<ProductHubItemsPayload>
            payload: ProductHubItemsPayload<ExtArgs>
          }
          createMany: {
            args: Prisma.ProductHubItemsCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: ProductHubItemsPayload<ExtArgs>
          }
          delete: {
            args: Prisma.ProductHubItemsDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<ProductHubItemsPayload>
            payload: ProductHubItemsPayload<ExtArgs>
          }
          update: {
            args: Prisma.ProductHubItemsUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<ProductHubItemsPayload>
            payload: ProductHubItemsPayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.ProductHubItemsDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: ProductHubItemsPayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.ProductHubItemsUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: ProductHubItemsPayload<ExtArgs>
          }
          upsert: {
            args: Prisma.ProductHubItemsUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<ProductHubItemsPayload>
            payload: ProductHubItemsPayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.ProductHubItemsAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateProductHubItems>
            payload: ProductHubItemsPayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.ProductHubItemsGroupByArgs<ExtArgs>,
            result: $Utils.Optional<ProductHubItemsGroupByOutputType>[]
            payload: ProductHubItemsPayload<ExtArgs>
          }
          count: {
            args: Prisma.ProductHubItemsCountArgs<ExtArgs>,
            result: $Utils.Optional<ProductHubItemsCountAggregateOutputType> | number
            payload: ProductHubItemsPayload<ExtArgs>
          }
        }
      }
      AjnaRewardsWeeklyClaim: {
        operations: {
          findUnique: {
            args: Prisma.AjnaRewardsWeeklyClaimFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsWeeklyClaimPayload> | null
            payload: AjnaRewardsWeeklyClaimPayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.AjnaRewardsWeeklyClaimFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsWeeklyClaimPayload>
            payload: AjnaRewardsWeeklyClaimPayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.AjnaRewardsWeeklyClaimFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsWeeklyClaimPayload> | null
            payload: AjnaRewardsWeeklyClaimPayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.AjnaRewardsWeeklyClaimFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsWeeklyClaimPayload>
            payload: AjnaRewardsWeeklyClaimPayload<ExtArgs>
          }
          findMany: {
            args: Prisma.AjnaRewardsWeeklyClaimFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsWeeklyClaimPayload>[]
            payload: AjnaRewardsWeeklyClaimPayload<ExtArgs>
          }
          create: {
            args: Prisma.AjnaRewardsWeeklyClaimCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsWeeklyClaimPayload>
            payload: AjnaRewardsWeeklyClaimPayload<ExtArgs>
          }
          createMany: {
            args: Prisma.AjnaRewardsWeeklyClaimCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: AjnaRewardsWeeklyClaimPayload<ExtArgs>
          }
          delete: {
            args: Prisma.AjnaRewardsWeeklyClaimDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsWeeklyClaimPayload>
            payload: AjnaRewardsWeeklyClaimPayload<ExtArgs>
          }
          update: {
            args: Prisma.AjnaRewardsWeeklyClaimUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsWeeklyClaimPayload>
            payload: AjnaRewardsWeeklyClaimPayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.AjnaRewardsWeeklyClaimDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: AjnaRewardsWeeklyClaimPayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.AjnaRewardsWeeklyClaimUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: AjnaRewardsWeeklyClaimPayload<ExtArgs>
          }
          upsert: {
            args: Prisma.AjnaRewardsWeeklyClaimUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsWeeklyClaimPayload>
            payload: AjnaRewardsWeeklyClaimPayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.AjnaRewardsWeeklyClaimAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateAjnaRewardsWeeklyClaim>
            payload: AjnaRewardsWeeklyClaimPayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.AjnaRewardsWeeklyClaimGroupByArgs<ExtArgs>,
            result: $Utils.Optional<AjnaRewardsWeeklyClaimGroupByOutputType>[]
            payload: AjnaRewardsWeeklyClaimPayload<ExtArgs>
          }
          count: {
            args: Prisma.AjnaRewardsWeeklyClaimCountArgs<ExtArgs>,
            result: $Utils.Optional<AjnaRewardsWeeklyClaimCountAggregateOutputType> | number
            payload: AjnaRewardsWeeklyClaimPayload<ExtArgs>
          }
        }
      }
      AjnaRewardsDailyClaim: {
        operations: {
          findUnique: {
            args: Prisma.AjnaRewardsDailyClaimFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsDailyClaimPayload> | null
            payload: AjnaRewardsDailyClaimPayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.AjnaRewardsDailyClaimFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsDailyClaimPayload>
            payload: AjnaRewardsDailyClaimPayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.AjnaRewardsDailyClaimFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsDailyClaimPayload> | null
            payload: AjnaRewardsDailyClaimPayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.AjnaRewardsDailyClaimFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsDailyClaimPayload>
            payload: AjnaRewardsDailyClaimPayload<ExtArgs>
          }
          findMany: {
            args: Prisma.AjnaRewardsDailyClaimFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsDailyClaimPayload>[]
            payload: AjnaRewardsDailyClaimPayload<ExtArgs>
          }
          create: {
            args: Prisma.AjnaRewardsDailyClaimCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsDailyClaimPayload>
            payload: AjnaRewardsDailyClaimPayload<ExtArgs>
          }
          createMany: {
            args: Prisma.AjnaRewardsDailyClaimCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: AjnaRewardsDailyClaimPayload<ExtArgs>
          }
          delete: {
            args: Prisma.AjnaRewardsDailyClaimDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsDailyClaimPayload>
            payload: AjnaRewardsDailyClaimPayload<ExtArgs>
          }
          update: {
            args: Prisma.AjnaRewardsDailyClaimUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsDailyClaimPayload>
            payload: AjnaRewardsDailyClaimPayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.AjnaRewardsDailyClaimDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: AjnaRewardsDailyClaimPayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.AjnaRewardsDailyClaimUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: AjnaRewardsDailyClaimPayload<ExtArgs>
          }
          upsert: {
            args: Prisma.AjnaRewardsDailyClaimUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsDailyClaimPayload>
            payload: AjnaRewardsDailyClaimPayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.AjnaRewardsDailyClaimAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateAjnaRewardsDailyClaim>
            payload: AjnaRewardsDailyClaimPayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.AjnaRewardsDailyClaimGroupByArgs<ExtArgs>,
            result: $Utils.Optional<AjnaRewardsDailyClaimGroupByOutputType>[]
            payload: AjnaRewardsDailyClaimPayload<ExtArgs>
          }
          count: {
            args: Prisma.AjnaRewardsDailyClaimCountArgs<ExtArgs>,
            result: $Utils.Optional<AjnaRewardsDailyClaimCountAggregateOutputType> | number
            payload: AjnaRewardsDailyClaimPayload<ExtArgs>
          }
        }
      }
      AjnaRewardsMerkleTree: {
        operations: {
          findUnique: {
            args: Prisma.AjnaRewardsMerkleTreeFindUniqueArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsMerkleTreePayload> | null
            payload: AjnaRewardsMerkleTreePayload<ExtArgs>
          }
          findUniqueOrThrow: {
            args: Prisma.AjnaRewardsMerkleTreeFindUniqueOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsMerkleTreePayload>
            payload: AjnaRewardsMerkleTreePayload<ExtArgs>
          }
          findFirst: {
            args: Prisma.AjnaRewardsMerkleTreeFindFirstArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsMerkleTreePayload> | null
            payload: AjnaRewardsMerkleTreePayload<ExtArgs>
          }
          findFirstOrThrow: {
            args: Prisma.AjnaRewardsMerkleTreeFindFirstOrThrowArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsMerkleTreePayload>
            payload: AjnaRewardsMerkleTreePayload<ExtArgs>
          }
          findMany: {
            args: Prisma.AjnaRewardsMerkleTreeFindManyArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsMerkleTreePayload>[]
            payload: AjnaRewardsMerkleTreePayload<ExtArgs>
          }
          create: {
            args: Prisma.AjnaRewardsMerkleTreeCreateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsMerkleTreePayload>
            payload: AjnaRewardsMerkleTreePayload<ExtArgs>
          }
          createMany: {
            args: Prisma.AjnaRewardsMerkleTreeCreateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: AjnaRewardsMerkleTreePayload<ExtArgs>
          }
          delete: {
            args: Prisma.AjnaRewardsMerkleTreeDeleteArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsMerkleTreePayload>
            payload: AjnaRewardsMerkleTreePayload<ExtArgs>
          }
          update: {
            args: Prisma.AjnaRewardsMerkleTreeUpdateArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsMerkleTreePayload>
            payload: AjnaRewardsMerkleTreePayload<ExtArgs>
          }
          deleteMany: {
            args: Prisma.AjnaRewardsMerkleTreeDeleteManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: AjnaRewardsMerkleTreePayload<ExtArgs>
          }
          updateMany: {
            args: Prisma.AjnaRewardsMerkleTreeUpdateManyArgs<ExtArgs>,
            result: Prisma.BatchPayload
            payload: AjnaRewardsMerkleTreePayload<ExtArgs>
          }
          upsert: {
            args: Prisma.AjnaRewardsMerkleTreeUpsertArgs<ExtArgs>,
            result: $Utils.PayloadToResult<AjnaRewardsMerkleTreePayload>
            payload: AjnaRewardsMerkleTreePayload<ExtArgs>
          }
          aggregate: {
            args: Prisma.AjnaRewardsMerkleTreeAggregateArgs<ExtArgs>,
            result: $Utils.Optional<AggregateAjnaRewardsMerkleTree>
            payload: AjnaRewardsMerkleTreePayload<ExtArgs>
          }
          groupBy: {
            args: Prisma.AjnaRewardsMerkleTreeGroupByArgs<ExtArgs>,
            result: $Utils.Optional<AjnaRewardsMerkleTreeGroupByOutputType>[]
            payload: AjnaRewardsMerkleTreePayload<ExtArgs>
          }
          count: {
            args: Prisma.AjnaRewardsMerkleTreeCountArgs<ExtArgs>,
            result: $Utils.Optional<AjnaRewardsMerkleTreeCountAggregateOutputType> | number
            payload: AjnaRewardsMerkleTreePayload<ExtArgs>
          }
        }
      }
    }
  } & {
    other: {
      operations: {
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
          payload: any
        }
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
          payload: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
          payload: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
          payload: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<'define', Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type RejectOnNotFound = boolean | ((error: Error) => Error)
  export type RejectPerModel = { [P in ModelName]?: RejectOnNotFound }
  export type RejectPerOperation =  { [P in "findUnique" | "findFirst"]?: RejectPerModel | RejectOnNotFound } 
  type IsReject<T> = T extends true ? True : T extends (err: Error) => Error ? True : False
  export type HasReject<
    GlobalRejectSettings extends Prisma.PrismaClientOptions['rejectOnNotFound'],
    LocalRejectSettings,
    Action extends PrismaAction,
    Model extends ModelName
  > = LocalRejectSettings extends RejectOnNotFound
    ? IsReject<LocalRejectSettings>
    : GlobalRejectSettings extends RejectPerOperation
    ? Action extends keyof GlobalRejectSettings
      ? GlobalRejectSettings[Action] extends RejectOnNotFound
        ? IsReject<GlobalRejectSettings[Action]>
        : GlobalRejectSettings[Action] extends RejectPerModel
        ? Model extends keyof GlobalRejectSettings[Action]
          ? IsReject<GlobalRejectSettings[Action][Model]>
          : False
        : False
      : False
    : IsReject<GlobalRejectSettings>
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'

  export interface PrismaClientOptions {
    /**
     * Configure findUnique/findFirst to throw an error if the query returns null. 
     * @deprecated since 4.0.0. Use `findUniqueOrThrow`/`findFirstOrThrow` methods instead.
     * @example
     * ```
     * // Reject on both findUnique/findFirst
     * rejectOnNotFound: true
     * // Reject only on findFirst with a custom error
     * rejectOnNotFound: { findFirst: (err) => new Error("Custom Error")}
     * // Reject on user.findUnique with a custom error
     * rejectOnNotFound: { findUnique: {User: (err) => new Error("User not found")}}
     * ```
     */
    rejectOnNotFound?: RejectOnNotFound | RejectPerOperation
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources

    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat

    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: Array<LogLevel | LogDefinition>
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findMany'
    | 'findFirst'
    | 'create'
    | 'createMany'
    | 'update'
    | 'updateMany'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => Promise<T>,
  ) => Promise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type UserCountOutputType
   */


  export type UserCountOutputType = {
    referred_users: number
    weekly_claims: number
  }

  export type UserCountOutputTypeSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    referred_users?: boolean | UserCountOutputTypeCountReferred_usersArgs
    weekly_claims?: boolean | UserCountOutputTypeCountWeekly_claimsArgs
  }

  // Custom InputTypes

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserCountOutputType
     */
    select?: UserCountOutputTypeSelect<ExtArgs> | null
  }


  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountReferred_usersArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: UserWhereInput
  }


  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountWeekly_claimsArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: WeeklyClaimWhereInput
  }



  /**
   * Models
   */

  /**
   * Model migrations
   */


  export type AggregateMigrations = {
    _count: MigrationsCountAggregateOutputType | null
    _avg: MigrationsAvgAggregateOutputType | null
    _sum: MigrationsSumAggregateOutputType | null
    _min: MigrationsMinAggregateOutputType | null
    _max: MigrationsMaxAggregateOutputType | null
  }

  export type MigrationsAvgAggregateOutputType = {
    id: number | null
  }

  export type MigrationsSumAggregateOutputType = {
    id: number | null
  }

  export type MigrationsMinAggregateOutputType = {
    id: number | null
    name: string | null
    hash: string | null
    executed_at: Date | null
  }

  export type MigrationsMaxAggregateOutputType = {
    id: number | null
    name: string | null
    hash: string | null
    executed_at: Date | null
  }

  export type MigrationsCountAggregateOutputType = {
    id: number
    name: number
    hash: number
    executed_at: number
    _all: number
  }


  export type MigrationsAvgAggregateInputType = {
    id?: true
  }

  export type MigrationsSumAggregateInputType = {
    id?: true
  }

  export type MigrationsMinAggregateInputType = {
    id?: true
    name?: true
    hash?: true
    executed_at?: true
  }

  export type MigrationsMaxAggregateInputType = {
    id?: true
    name?: true
    hash?: true
    executed_at?: true
  }

  export type MigrationsCountAggregateInputType = {
    id?: true
    name?: true
    hash?: true
    executed_at?: true
    _all?: true
  }

  export type MigrationsAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which migrations to aggregate.
     */
    where?: migrationsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of migrations to fetch.
     */
    orderBy?: Enumerable<migrationsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: migrationsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` migrations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` migrations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned migrations
    **/
    _count?: true | MigrationsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: MigrationsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: MigrationsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: MigrationsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: MigrationsMaxAggregateInputType
  }

  export type GetMigrationsAggregateType<T extends MigrationsAggregateArgs> = {
        [P in keyof T & keyof AggregateMigrations]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMigrations[P]>
      : GetScalarType<T[P], AggregateMigrations[P]>
  }




  export type MigrationsGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: migrationsWhereInput
    orderBy?: Enumerable<migrationsOrderByWithAggregationInput>
    by: MigrationsScalarFieldEnum[]
    having?: migrationsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: MigrationsCountAggregateInputType | true
    _avg?: MigrationsAvgAggregateInputType
    _sum?: MigrationsSumAggregateInputType
    _min?: MigrationsMinAggregateInputType
    _max?: MigrationsMaxAggregateInputType
  }


  export type MigrationsGroupByOutputType = {
    id: number
    name: string
    hash: string
    executed_at: Date | null
    _count: MigrationsCountAggregateOutputType | null
    _avg: MigrationsAvgAggregateOutputType | null
    _sum: MigrationsSumAggregateOutputType | null
    _min: MigrationsMinAggregateOutputType | null
    _max: MigrationsMaxAggregateOutputType | null
  }

  type GetMigrationsGroupByPayload<T extends MigrationsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<MigrationsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof MigrationsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], MigrationsGroupByOutputType[P]>
            : GetScalarType<T[P], MigrationsGroupByOutputType[P]>
        }
      >
    >


  export type migrationsSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    hash?: boolean
    executed_at?: boolean
  }, ExtArgs["result"]["migrations"]>

  export type migrationsSelectScalar = {
    id?: boolean
    name?: boolean
    hash?: boolean
    executed_at?: boolean
  }


  type migrationsGetPayload<S extends boolean | null | undefined | migrationsArgs> = $Types.GetResult<migrationsPayload, S>

  type migrationsCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<migrationsFindManyArgs, 'select' | 'include'> & {
      select?: MigrationsCountAggregateInputType | true
    }

  export interface migrationsDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['migrations'], meta: { name: 'migrations' } }
    /**
     * Find zero or one Migrations that matches the filter.
     * @param {migrationsFindUniqueArgs} args - Arguments to find a Migrations
     * @example
     * // Get one Migrations
     * const migrations = await prisma.migrations.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends migrationsFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, migrationsFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'migrations'> extends True ? Prisma__migrationsClient<$Types.GetResult<migrationsPayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__migrationsClient<$Types.GetResult<migrationsPayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one Migrations that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {migrationsFindUniqueOrThrowArgs} args - Arguments to find a Migrations
     * @example
     * // Get one Migrations
     * const migrations = await prisma.migrations.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends migrationsFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, migrationsFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__migrationsClient<$Types.GetResult<migrationsPayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first Migrations that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {migrationsFindFirstArgs} args - Arguments to find a Migrations
     * @example
     * // Get one Migrations
     * const migrations = await prisma.migrations.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends migrationsFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, migrationsFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'migrations'> extends True ? Prisma__migrationsClient<$Types.GetResult<migrationsPayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__migrationsClient<$Types.GetResult<migrationsPayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first Migrations that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {migrationsFindFirstOrThrowArgs} args - Arguments to find a Migrations
     * @example
     * // Get one Migrations
     * const migrations = await prisma.migrations.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends migrationsFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, migrationsFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__migrationsClient<$Types.GetResult<migrationsPayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more Migrations that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {migrationsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Migrations
     * const migrations = await prisma.migrations.findMany()
     * 
     * // Get first 10 Migrations
     * const migrations = await prisma.migrations.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const migrationsWithIdOnly = await prisma.migrations.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends migrationsFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, migrationsFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<migrationsPayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a Migrations.
     * @param {migrationsCreateArgs} args - Arguments to create a Migrations.
     * @example
     * // Create one Migrations
     * const Migrations = await prisma.migrations.create({
     *   data: {
     *     // ... data to create a Migrations
     *   }
     * })
     * 
    **/
    create<T extends migrationsCreateArgs<ExtArgs>>(
      args: SelectSubset<T, migrationsCreateArgs<ExtArgs>>
    ): Prisma__migrationsClient<$Types.GetResult<migrationsPayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many Migrations.
     *     @param {migrationsCreateManyArgs} args - Arguments to create many Migrations.
     *     @example
     *     // Create many Migrations
     *     const migrations = await prisma.migrations.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends migrationsCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, migrationsCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Migrations.
     * @param {migrationsDeleteArgs} args - Arguments to delete one Migrations.
     * @example
     * // Delete one Migrations
     * const Migrations = await prisma.migrations.delete({
     *   where: {
     *     // ... filter to delete one Migrations
     *   }
     * })
     * 
    **/
    delete<T extends migrationsDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, migrationsDeleteArgs<ExtArgs>>
    ): Prisma__migrationsClient<$Types.GetResult<migrationsPayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one Migrations.
     * @param {migrationsUpdateArgs} args - Arguments to update one Migrations.
     * @example
     * // Update one Migrations
     * const migrations = await prisma.migrations.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends migrationsUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, migrationsUpdateArgs<ExtArgs>>
    ): Prisma__migrationsClient<$Types.GetResult<migrationsPayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more Migrations.
     * @param {migrationsDeleteManyArgs} args - Arguments to filter Migrations to delete.
     * @example
     * // Delete a few Migrations
     * const { count } = await prisma.migrations.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends migrationsDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, migrationsDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Migrations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {migrationsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Migrations
     * const migrations = await prisma.migrations.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends migrationsUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, migrationsUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Migrations.
     * @param {migrationsUpsertArgs} args - Arguments to update or create a Migrations.
     * @example
     * // Update or create a Migrations
     * const migrations = await prisma.migrations.upsert({
     *   create: {
     *     // ... data to create a Migrations
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Migrations we want to update
     *   }
     * })
    **/
    upsert<T extends migrationsUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, migrationsUpsertArgs<ExtArgs>>
    ): Prisma__migrationsClient<$Types.GetResult<migrationsPayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of Migrations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {migrationsCountArgs} args - Arguments to filter Migrations to count.
     * @example
     * // Count the number of Migrations
     * const count = await prisma.migrations.count({
     *   where: {
     *     // ... the filter for the Migrations we want to count
     *   }
     * })
    **/
    count<T extends migrationsCountArgs>(
      args?: Subset<T, migrationsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], MigrationsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Migrations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MigrationsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends MigrationsAggregateArgs>(args: Subset<T, MigrationsAggregateArgs>): Prisma.PrismaPromise<GetMigrationsAggregateType<T>>

    /**
     * Group by Migrations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MigrationsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends MigrationsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: MigrationsGroupByArgs['orderBy'] }
        : { orderBy?: MigrationsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, MigrationsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMigrationsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for migrations.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__migrationsClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * migrations base type for findUnique actions
   */
  export type migrationsFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the migrations
     */
    select?: migrationsSelect<ExtArgs> | null
    /**
     * Filter, which migrations to fetch.
     */
    where: migrationsWhereUniqueInput
  }

  /**
   * migrations findUnique
   */
  export interface migrationsFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends migrationsFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * migrations findUniqueOrThrow
   */
  export type migrationsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the migrations
     */
    select?: migrationsSelect<ExtArgs> | null
    /**
     * Filter, which migrations to fetch.
     */
    where: migrationsWhereUniqueInput
  }


  /**
   * migrations base type for findFirst actions
   */
  export type migrationsFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the migrations
     */
    select?: migrationsSelect<ExtArgs> | null
    /**
     * Filter, which migrations to fetch.
     */
    where?: migrationsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of migrations to fetch.
     */
    orderBy?: Enumerable<migrationsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for migrations.
     */
    cursor?: migrationsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` migrations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` migrations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of migrations.
     */
    distinct?: Enumerable<MigrationsScalarFieldEnum>
  }

  /**
   * migrations findFirst
   */
  export interface migrationsFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends migrationsFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * migrations findFirstOrThrow
   */
  export type migrationsFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the migrations
     */
    select?: migrationsSelect<ExtArgs> | null
    /**
     * Filter, which migrations to fetch.
     */
    where?: migrationsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of migrations to fetch.
     */
    orderBy?: Enumerable<migrationsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for migrations.
     */
    cursor?: migrationsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` migrations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` migrations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of migrations.
     */
    distinct?: Enumerable<MigrationsScalarFieldEnum>
  }


  /**
   * migrations findMany
   */
  export type migrationsFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the migrations
     */
    select?: migrationsSelect<ExtArgs> | null
    /**
     * Filter, which migrations to fetch.
     */
    where?: migrationsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of migrations to fetch.
     */
    orderBy?: Enumerable<migrationsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing migrations.
     */
    cursor?: migrationsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` migrations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` migrations.
     */
    skip?: number
    distinct?: Enumerable<MigrationsScalarFieldEnum>
  }


  /**
   * migrations create
   */
  export type migrationsCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the migrations
     */
    select?: migrationsSelect<ExtArgs> | null
    /**
     * The data needed to create a migrations.
     */
    data: XOR<migrationsCreateInput, migrationsUncheckedCreateInput>
  }


  /**
   * migrations createMany
   */
  export type migrationsCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many migrations.
     */
    data: Enumerable<migrationsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * migrations update
   */
  export type migrationsUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the migrations
     */
    select?: migrationsSelect<ExtArgs> | null
    /**
     * The data needed to update a migrations.
     */
    data: XOR<migrationsUpdateInput, migrationsUncheckedUpdateInput>
    /**
     * Choose, which migrations to update.
     */
    where: migrationsWhereUniqueInput
  }


  /**
   * migrations updateMany
   */
  export type migrationsUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update migrations.
     */
    data: XOR<migrationsUpdateManyMutationInput, migrationsUncheckedUpdateManyInput>
    /**
     * Filter which migrations to update
     */
    where?: migrationsWhereInput
  }


  /**
   * migrations upsert
   */
  export type migrationsUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the migrations
     */
    select?: migrationsSelect<ExtArgs> | null
    /**
     * The filter to search for the migrations to update in case it exists.
     */
    where: migrationsWhereUniqueInput
    /**
     * In case the migrations found by the `where` argument doesn't exist, create a new migrations with this data.
     */
    create: XOR<migrationsCreateInput, migrationsUncheckedCreateInput>
    /**
     * In case the migrations was found with the provided `where` argument, update it with this data.
     */
    update: XOR<migrationsUpdateInput, migrationsUncheckedUpdateInput>
  }


  /**
   * migrations delete
   */
  export type migrationsDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the migrations
     */
    select?: migrationsSelect<ExtArgs> | null
    /**
     * Filter which migrations to delete.
     */
    where: migrationsWhereUniqueInput
  }


  /**
   * migrations deleteMany
   */
  export type migrationsDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which migrations to delete
     */
    where?: migrationsWhereInput
  }


  /**
   * migrations without action
   */
  export type migrationsArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the migrations
     */
    select?: migrationsSelect<ExtArgs> | null
  }



  /**
   * Model TosApproval
   */


  export type AggregateTosApproval = {
    _count: TosApprovalCountAggregateOutputType | null
    _avg: TosApprovalAvgAggregateOutputType | null
    _sum: TosApprovalSumAggregateOutputType | null
    _min: TosApprovalMinAggregateOutputType | null
    _max: TosApprovalMaxAggregateOutputType | null
  }

  export type TosApprovalAvgAggregateOutputType = {
    id: number | null
    chain_id: number | null
  }

  export type TosApprovalSumAggregateOutputType = {
    id: number | null
    chain_id: number | null
  }

  export type TosApprovalMinAggregateOutputType = {
    id: number | null
    address: string | null
    signature: string | null
    message: string | null
    chain_id: number | null
    doc_version: string | null
    sign_date: Date | null
  }

  export type TosApprovalMaxAggregateOutputType = {
    id: number | null
    address: string | null
    signature: string | null
    message: string | null
    chain_id: number | null
    doc_version: string | null
    sign_date: Date | null
  }

  export type TosApprovalCountAggregateOutputType = {
    id: number
    address: number
    signature: number
    message: number
    chain_id: number
    doc_version: number
    sign_date: number
    _all: number
  }


  export type TosApprovalAvgAggregateInputType = {
    id?: true
    chain_id?: true
  }

  export type TosApprovalSumAggregateInputType = {
    id?: true
    chain_id?: true
  }

  export type TosApprovalMinAggregateInputType = {
    id?: true
    address?: true
    signature?: true
    message?: true
    chain_id?: true
    doc_version?: true
    sign_date?: true
  }

  export type TosApprovalMaxAggregateInputType = {
    id?: true
    address?: true
    signature?: true
    message?: true
    chain_id?: true
    doc_version?: true
    sign_date?: true
  }

  export type TosApprovalCountAggregateInputType = {
    id?: true
    address?: true
    signature?: true
    message?: true
    chain_id?: true
    doc_version?: true
    sign_date?: true
    _all?: true
  }

  export type TosApprovalAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which TosApproval to aggregate.
     */
    where?: TosApprovalWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TosApprovals to fetch.
     */
    orderBy?: Enumerable<TosApprovalOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: TosApprovalWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TosApprovals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TosApprovals.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned TosApprovals
    **/
    _count?: true | TosApprovalCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: TosApprovalAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: TosApprovalSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TosApprovalMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TosApprovalMaxAggregateInputType
  }

  export type GetTosApprovalAggregateType<T extends TosApprovalAggregateArgs> = {
        [P in keyof T & keyof AggregateTosApproval]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTosApproval[P]>
      : GetScalarType<T[P], AggregateTosApproval[P]>
  }




  export type TosApprovalGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: TosApprovalWhereInput
    orderBy?: Enumerable<TosApprovalOrderByWithAggregationInput>
    by: TosApprovalScalarFieldEnum[]
    having?: TosApprovalScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TosApprovalCountAggregateInputType | true
    _avg?: TosApprovalAvgAggregateInputType
    _sum?: TosApprovalSumAggregateInputType
    _min?: TosApprovalMinAggregateInputType
    _max?: TosApprovalMaxAggregateInputType
  }


  export type TosApprovalGroupByOutputType = {
    id: number
    address: string
    signature: string
    message: string
    chain_id: number
    doc_version: string
    sign_date: Date
    _count: TosApprovalCountAggregateOutputType | null
    _avg: TosApprovalAvgAggregateOutputType | null
    _sum: TosApprovalSumAggregateOutputType | null
    _min: TosApprovalMinAggregateOutputType | null
    _max: TosApprovalMaxAggregateOutputType | null
  }

  type GetTosApprovalGroupByPayload<T extends TosApprovalGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<TosApprovalGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TosApprovalGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TosApprovalGroupByOutputType[P]>
            : GetScalarType<T[P], TosApprovalGroupByOutputType[P]>
        }
      >
    >


  export type TosApprovalSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    address?: boolean
    signature?: boolean
    message?: boolean
    chain_id?: boolean
    doc_version?: boolean
    sign_date?: boolean
  }, ExtArgs["result"]["tosApproval"]>

  export type TosApprovalSelectScalar = {
    id?: boolean
    address?: boolean
    signature?: boolean
    message?: boolean
    chain_id?: boolean
    doc_version?: boolean
    sign_date?: boolean
  }


  type TosApprovalGetPayload<S extends boolean | null | undefined | TosApprovalArgs> = $Types.GetResult<TosApprovalPayload, S>

  type TosApprovalCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<TosApprovalFindManyArgs, 'select' | 'include'> & {
      select?: TosApprovalCountAggregateInputType | true
    }

  export interface TosApprovalDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['TosApproval'], meta: { name: 'TosApproval' } }
    /**
     * Find zero or one TosApproval that matches the filter.
     * @param {TosApprovalFindUniqueArgs} args - Arguments to find a TosApproval
     * @example
     * // Get one TosApproval
     * const tosApproval = await prisma.tosApproval.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends TosApprovalFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, TosApprovalFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'TosApproval'> extends True ? Prisma__TosApprovalClient<$Types.GetResult<TosApprovalPayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__TosApprovalClient<$Types.GetResult<TosApprovalPayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one TosApproval that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {TosApprovalFindUniqueOrThrowArgs} args - Arguments to find a TosApproval
     * @example
     * // Get one TosApproval
     * const tosApproval = await prisma.tosApproval.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends TosApprovalFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, TosApprovalFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__TosApprovalClient<$Types.GetResult<TosApprovalPayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first TosApproval that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TosApprovalFindFirstArgs} args - Arguments to find a TosApproval
     * @example
     * // Get one TosApproval
     * const tosApproval = await prisma.tosApproval.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends TosApprovalFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, TosApprovalFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'TosApproval'> extends True ? Prisma__TosApprovalClient<$Types.GetResult<TosApprovalPayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__TosApprovalClient<$Types.GetResult<TosApprovalPayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first TosApproval that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TosApprovalFindFirstOrThrowArgs} args - Arguments to find a TosApproval
     * @example
     * // Get one TosApproval
     * const tosApproval = await prisma.tosApproval.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends TosApprovalFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, TosApprovalFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__TosApprovalClient<$Types.GetResult<TosApprovalPayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more TosApprovals that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TosApprovalFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all TosApprovals
     * const tosApprovals = await prisma.tosApproval.findMany()
     * 
     * // Get first 10 TosApprovals
     * const tosApprovals = await prisma.tosApproval.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const tosApprovalWithIdOnly = await prisma.tosApproval.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends TosApprovalFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, TosApprovalFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<TosApprovalPayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a TosApproval.
     * @param {TosApprovalCreateArgs} args - Arguments to create a TosApproval.
     * @example
     * // Create one TosApproval
     * const TosApproval = await prisma.tosApproval.create({
     *   data: {
     *     // ... data to create a TosApproval
     *   }
     * })
     * 
    **/
    create<T extends TosApprovalCreateArgs<ExtArgs>>(
      args: SelectSubset<T, TosApprovalCreateArgs<ExtArgs>>
    ): Prisma__TosApprovalClient<$Types.GetResult<TosApprovalPayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many TosApprovals.
     *     @param {TosApprovalCreateManyArgs} args - Arguments to create many TosApprovals.
     *     @example
     *     // Create many TosApprovals
     *     const tosApproval = await prisma.tosApproval.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends TosApprovalCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, TosApprovalCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a TosApproval.
     * @param {TosApprovalDeleteArgs} args - Arguments to delete one TosApproval.
     * @example
     * // Delete one TosApproval
     * const TosApproval = await prisma.tosApproval.delete({
     *   where: {
     *     // ... filter to delete one TosApproval
     *   }
     * })
     * 
    **/
    delete<T extends TosApprovalDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, TosApprovalDeleteArgs<ExtArgs>>
    ): Prisma__TosApprovalClient<$Types.GetResult<TosApprovalPayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one TosApproval.
     * @param {TosApprovalUpdateArgs} args - Arguments to update one TosApproval.
     * @example
     * // Update one TosApproval
     * const tosApproval = await prisma.tosApproval.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends TosApprovalUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, TosApprovalUpdateArgs<ExtArgs>>
    ): Prisma__TosApprovalClient<$Types.GetResult<TosApprovalPayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more TosApprovals.
     * @param {TosApprovalDeleteManyArgs} args - Arguments to filter TosApprovals to delete.
     * @example
     * // Delete a few TosApprovals
     * const { count } = await prisma.tosApproval.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends TosApprovalDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, TosApprovalDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more TosApprovals.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TosApprovalUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many TosApprovals
     * const tosApproval = await prisma.tosApproval.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends TosApprovalUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, TosApprovalUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one TosApproval.
     * @param {TosApprovalUpsertArgs} args - Arguments to update or create a TosApproval.
     * @example
     * // Update or create a TosApproval
     * const tosApproval = await prisma.tosApproval.upsert({
     *   create: {
     *     // ... data to create a TosApproval
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the TosApproval we want to update
     *   }
     * })
    **/
    upsert<T extends TosApprovalUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, TosApprovalUpsertArgs<ExtArgs>>
    ): Prisma__TosApprovalClient<$Types.GetResult<TosApprovalPayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of TosApprovals.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TosApprovalCountArgs} args - Arguments to filter TosApprovals to count.
     * @example
     * // Count the number of TosApprovals
     * const count = await prisma.tosApproval.count({
     *   where: {
     *     // ... the filter for the TosApprovals we want to count
     *   }
     * })
    **/
    count<T extends TosApprovalCountArgs>(
      args?: Subset<T, TosApprovalCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TosApprovalCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a TosApproval.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TosApprovalAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TosApprovalAggregateArgs>(args: Subset<T, TosApprovalAggregateArgs>): Prisma.PrismaPromise<GetTosApprovalAggregateType<T>>

    /**
     * Group by TosApproval.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TosApprovalGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends TosApprovalGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: TosApprovalGroupByArgs['orderBy'] }
        : { orderBy?: TosApprovalGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, TosApprovalGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTosApprovalGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for TosApproval.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__TosApprovalClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * TosApproval base type for findUnique actions
   */
  export type TosApprovalFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TosApproval
     */
    select?: TosApprovalSelect<ExtArgs> | null
    /**
     * Filter, which TosApproval to fetch.
     */
    where: TosApprovalWhereUniqueInput
  }

  /**
   * TosApproval findUnique
   */
  export interface TosApprovalFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends TosApprovalFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * TosApproval findUniqueOrThrow
   */
  export type TosApprovalFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TosApproval
     */
    select?: TosApprovalSelect<ExtArgs> | null
    /**
     * Filter, which TosApproval to fetch.
     */
    where: TosApprovalWhereUniqueInput
  }


  /**
   * TosApproval base type for findFirst actions
   */
  export type TosApprovalFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TosApproval
     */
    select?: TosApprovalSelect<ExtArgs> | null
    /**
     * Filter, which TosApproval to fetch.
     */
    where?: TosApprovalWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TosApprovals to fetch.
     */
    orderBy?: Enumerable<TosApprovalOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TosApprovals.
     */
    cursor?: TosApprovalWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TosApprovals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TosApprovals.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TosApprovals.
     */
    distinct?: Enumerable<TosApprovalScalarFieldEnum>
  }

  /**
   * TosApproval findFirst
   */
  export interface TosApprovalFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends TosApprovalFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * TosApproval findFirstOrThrow
   */
  export type TosApprovalFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TosApproval
     */
    select?: TosApprovalSelect<ExtArgs> | null
    /**
     * Filter, which TosApproval to fetch.
     */
    where?: TosApprovalWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TosApprovals to fetch.
     */
    orderBy?: Enumerable<TosApprovalOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TosApprovals.
     */
    cursor?: TosApprovalWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TosApprovals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TosApprovals.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TosApprovals.
     */
    distinct?: Enumerable<TosApprovalScalarFieldEnum>
  }


  /**
   * TosApproval findMany
   */
  export type TosApprovalFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TosApproval
     */
    select?: TosApprovalSelect<ExtArgs> | null
    /**
     * Filter, which TosApprovals to fetch.
     */
    where?: TosApprovalWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TosApprovals to fetch.
     */
    orderBy?: Enumerable<TosApprovalOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing TosApprovals.
     */
    cursor?: TosApprovalWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TosApprovals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TosApprovals.
     */
    skip?: number
    distinct?: Enumerable<TosApprovalScalarFieldEnum>
  }


  /**
   * TosApproval create
   */
  export type TosApprovalCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TosApproval
     */
    select?: TosApprovalSelect<ExtArgs> | null
    /**
     * The data needed to create a TosApproval.
     */
    data: XOR<TosApprovalCreateInput, TosApprovalUncheckedCreateInput>
  }


  /**
   * TosApproval createMany
   */
  export type TosApprovalCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many TosApprovals.
     */
    data: Enumerable<TosApprovalCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * TosApproval update
   */
  export type TosApprovalUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TosApproval
     */
    select?: TosApprovalSelect<ExtArgs> | null
    /**
     * The data needed to update a TosApproval.
     */
    data: XOR<TosApprovalUpdateInput, TosApprovalUncheckedUpdateInput>
    /**
     * Choose, which TosApproval to update.
     */
    where: TosApprovalWhereUniqueInput
  }


  /**
   * TosApproval updateMany
   */
  export type TosApprovalUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update TosApprovals.
     */
    data: XOR<TosApprovalUpdateManyMutationInput, TosApprovalUncheckedUpdateManyInput>
    /**
     * Filter which TosApprovals to update
     */
    where?: TosApprovalWhereInput
  }


  /**
   * TosApproval upsert
   */
  export type TosApprovalUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TosApproval
     */
    select?: TosApprovalSelect<ExtArgs> | null
    /**
     * The filter to search for the TosApproval to update in case it exists.
     */
    where: TosApprovalWhereUniqueInput
    /**
     * In case the TosApproval found by the `where` argument doesn't exist, create a new TosApproval with this data.
     */
    create: XOR<TosApprovalCreateInput, TosApprovalUncheckedCreateInput>
    /**
     * In case the TosApproval was found with the provided `where` argument, update it with this data.
     */
    update: XOR<TosApprovalUpdateInput, TosApprovalUncheckedUpdateInput>
  }


  /**
   * TosApproval delete
   */
  export type TosApprovalDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TosApproval
     */
    select?: TosApprovalSelect<ExtArgs> | null
    /**
     * Filter which TosApproval to delete.
     */
    where: TosApprovalWhereUniqueInput
  }


  /**
   * TosApproval deleteMany
   */
  export type TosApprovalDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which TosApprovals to delete
     */
    where?: TosApprovalWhereInput
  }


  /**
   * TosApproval without action
   */
  export type TosApprovalArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TosApproval
     */
    select?: TosApprovalSelect<ExtArgs> | null
  }



  /**
   * Model Vault
   */


  export type AggregateVault = {
    _count: VaultCountAggregateOutputType | null
    _avg: VaultAvgAggregateOutputType | null
    _sum: VaultSumAggregateOutputType | null
    _min: VaultMinAggregateOutputType | null
    _max: VaultMaxAggregateOutputType | null
  }

  export type VaultAvgAggregateOutputType = {
    vault_id: number | null
    chain_id: number | null
  }

  export type VaultSumAggregateOutputType = {
    vault_id: number | null
    chain_id: number | null
  }

  export type VaultMinAggregateOutputType = {
    vault_id: number | null
    type: VaultType | null
    owner_address: string | null
    chain_id: number | null
    protocol: string | null
  }

  export type VaultMaxAggregateOutputType = {
    vault_id: number | null
    type: VaultType | null
    owner_address: string | null
    chain_id: number | null
    protocol: string | null
  }

  export type VaultCountAggregateOutputType = {
    vault_id: number
    type: number
    owner_address: number
    chain_id: number
    protocol: number
    _all: number
  }


  export type VaultAvgAggregateInputType = {
    vault_id?: true
    chain_id?: true
  }

  export type VaultSumAggregateInputType = {
    vault_id?: true
    chain_id?: true
  }

  export type VaultMinAggregateInputType = {
    vault_id?: true
    type?: true
    owner_address?: true
    chain_id?: true
    protocol?: true
  }

  export type VaultMaxAggregateInputType = {
    vault_id?: true
    type?: true
    owner_address?: true
    chain_id?: true
    protocol?: true
  }

  export type VaultCountAggregateInputType = {
    vault_id?: true
    type?: true
    owner_address?: true
    chain_id?: true
    protocol?: true
    _all?: true
  }

  export type VaultAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which Vault to aggregate.
     */
    where?: VaultWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Vaults to fetch.
     */
    orderBy?: Enumerable<VaultOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: VaultWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Vaults from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Vaults.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Vaults
    **/
    _count?: true | VaultCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: VaultAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: VaultSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: VaultMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: VaultMaxAggregateInputType
  }

  export type GetVaultAggregateType<T extends VaultAggregateArgs> = {
        [P in keyof T & keyof AggregateVault]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateVault[P]>
      : GetScalarType<T[P], AggregateVault[P]>
  }




  export type VaultGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: VaultWhereInput
    orderBy?: Enumerable<VaultOrderByWithAggregationInput>
    by: VaultScalarFieldEnum[]
    having?: VaultScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: VaultCountAggregateInputType | true
    _avg?: VaultAvgAggregateInputType
    _sum?: VaultSumAggregateInputType
    _min?: VaultMinAggregateInputType
    _max?: VaultMaxAggregateInputType
  }


  export type VaultGroupByOutputType = {
    vault_id: number
    type: VaultType
    owner_address: string
    chain_id: number | null
    protocol: string
    _count: VaultCountAggregateOutputType | null
    _avg: VaultAvgAggregateOutputType | null
    _sum: VaultSumAggregateOutputType | null
    _min: VaultMinAggregateOutputType | null
    _max: VaultMaxAggregateOutputType | null
  }

  type GetVaultGroupByPayload<T extends VaultGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<VaultGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof VaultGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], VaultGroupByOutputType[P]>
            : GetScalarType<T[P], VaultGroupByOutputType[P]>
        }
      >
    >


  export type VaultSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    vault_id?: boolean
    type?: boolean
    owner_address?: boolean
    chain_id?: boolean
    protocol?: boolean
  }, ExtArgs["result"]["vault"]>

  export type VaultSelectScalar = {
    vault_id?: boolean
    type?: boolean
    owner_address?: boolean
    chain_id?: boolean
    protocol?: boolean
  }


  type VaultGetPayload<S extends boolean | null | undefined | VaultArgs> = $Types.GetResult<VaultPayload, S>

  type VaultCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<VaultFindManyArgs, 'select' | 'include'> & {
      select?: VaultCountAggregateInputType | true
    }

  export interface VaultDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Vault'], meta: { name: 'Vault' } }
    /**
     * Find zero or one Vault that matches the filter.
     * @param {VaultFindUniqueArgs} args - Arguments to find a Vault
     * @example
     * // Get one Vault
     * const vault = await prisma.vault.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends VaultFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, VaultFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'Vault'> extends True ? Prisma__VaultClient<$Types.GetResult<VaultPayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__VaultClient<$Types.GetResult<VaultPayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one Vault that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {VaultFindUniqueOrThrowArgs} args - Arguments to find a Vault
     * @example
     * // Get one Vault
     * const vault = await prisma.vault.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends VaultFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, VaultFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__VaultClient<$Types.GetResult<VaultPayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first Vault that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VaultFindFirstArgs} args - Arguments to find a Vault
     * @example
     * // Get one Vault
     * const vault = await prisma.vault.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends VaultFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, VaultFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'Vault'> extends True ? Prisma__VaultClient<$Types.GetResult<VaultPayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__VaultClient<$Types.GetResult<VaultPayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first Vault that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VaultFindFirstOrThrowArgs} args - Arguments to find a Vault
     * @example
     * // Get one Vault
     * const vault = await prisma.vault.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends VaultFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, VaultFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__VaultClient<$Types.GetResult<VaultPayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more Vaults that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VaultFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Vaults
     * const vaults = await prisma.vault.findMany()
     * 
     * // Get first 10 Vaults
     * const vaults = await prisma.vault.findMany({ take: 10 })
     * 
     * // Only select the `vault_id`
     * const vaultWithVault_idOnly = await prisma.vault.findMany({ select: { vault_id: true } })
     * 
    **/
    findMany<T extends VaultFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, VaultFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<VaultPayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a Vault.
     * @param {VaultCreateArgs} args - Arguments to create a Vault.
     * @example
     * // Create one Vault
     * const Vault = await prisma.vault.create({
     *   data: {
     *     // ... data to create a Vault
     *   }
     * })
     * 
    **/
    create<T extends VaultCreateArgs<ExtArgs>>(
      args: SelectSubset<T, VaultCreateArgs<ExtArgs>>
    ): Prisma__VaultClient<$Types.GetResult<VaultPayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many Vaults.
     *     @param {VaultCreateManyArgs} args - Arguments to create many Vaults.
     *     @example
     *     // Create many Vaults
     *     const vault = await prisma.vault.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends VaultCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, VaultCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Vault.
     * @param {VaultDeleteArgs} args - Arguments to delete one Vault.
     * @example
     * // Delete one Vault
     * const Vault = await prisma.vault.delete({
     *   where: {
     *     // ... filter to delete one Vault
     *   }
     * })
     * 
    **/
    delete<T extends VaultDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, VaultDeleteArgs<ExtArgs>>
    ): Prisma__VaultClient<$Types.GetResult<VaultPayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one Vault.
     * @param {VaultUpdateArgs} args - Arguments to update one Vault.
     * @example
     * // Update one Vault
     * const vault = await prisma.vault.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends VaultUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, VaultUpdateArgs<ExtArgs>>
    ): Prisma__VaultClient<$Types.GetResult<VaultPayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more Vaults.
     * @param {VaultDeleteManyArgs} args - Arguments to filter Vaults to delete.
     * @example
     * // Delete a few Vaults
     * const { count } = await prisma.vault.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends VaultDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, VaultDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Vaults.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VaultUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Vaults
     * const vault = await prisma.vault.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends VaultUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, VaultUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Vault.
     * @param {VaultUpsertArgs} args - Arguments to update or create a Vault.
     * @example
     * // Update or create a Vault
     * const vault = await prisma.vault.upsert({
     *   create: {
     *     // ... data to create a Vault
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Vault we want to update
     *   }
     * })
    **/
    upsert<T extends VaultUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, VaultUpsertArgs<ExtArgs>>
    ): Prisma__VaultClient<$Types.GetResult<VaultPayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of Vaults.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VaultCountArgs} args - Arguments to filter Vaults to count.
     * @example
     * // Count the number of Vaults
     * const count = await prisma.vault.count({
     *   where: {
     *     // ... the filter for the Vaults we want to count
     *   }
     * })
    **/
    count<T extends VaultCountArgs>(
      args?: Subset<T, VaultCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], VaultCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Vault.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VaultAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends VaultAggregateArgs>(args: Subset<T, VaultAggregateArgs>): Prisma.PrismaPromise<GetVaultAggregateType<T>>

    /**
     * Group by Vault.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VaultGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends VaultGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: VaultGroupByArgs['orderBy'] }
        : { orderBy?: VaultGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, VaultGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetVaultGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for Vault.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__VaultClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * Vault base type for findUnique actions
   */
  export type VaultFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vault
     */
    select?: VaultSelect<ExtArgs> | null
    /**
     * Filter, which Vault to fetch.
     */
    where: VaultWhereUniqueInput
  }

  /**
   * Vault findUnique
   */
  export interface VaultFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends VaultFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * Vault findUniqueOrThrow
   */
  export type VaultFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vault
     */
    select?: VaultSelect<ExtArgs> | null
    /**
     * Filter, which Vault to fetch.
     */
    where: VaultWhereUniqueInput
  }


  /**
   * Vault base type for findFirst actions
   */
  export type VaultFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vault
     */
    select?: VaultSelect<ExtArgs> | null
    /**
     * Filter, which Vault to fetch.
     */
    where?: VaultWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Vaults to fetch.
     */
    orderBy?: Enumerable<VaultOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Vaults.
     */
    cursor?: VaultWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Vaults from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Vaults.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Vaults.
     */
    distinct?: Enumerable<VaultScalarFieldEnum>
  }

  /**
   * Vault findFirst
   */
  export interface VaultFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends VaultFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * Vault findFirstOrThrow
   */
  export type VaultFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vault
     */
    select?: VaultSelect<ExtArgs> | null
    /**
     * Filter, which Vault to fetch.
     */
    where?: VaultWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Vaults to fetch.
     */
    orderBy?: Enumerable<VaultOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Vaults.
     */
    cursor?: VaultWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Vaults from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Vaults.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Vaults.
     */
    distinct?: Enumerable<VaultScalarFieldEnum>
  }


  /**
   * Vault findMany
   */
  export type VaultFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vault
     */
    select?: VaultSelect<ExtArgs> | null
    /**
     * Filter, which Vaults to fetch.
     */
    where?: VaultWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Vaults to fetch.
     */
    orderBy?: Enumerable<VaultOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Vaults.
     */
    cursor?: VaultWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Vaults from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Vaults.
     */
    skip?: number
    distinct?: Enumerable<VaultScalarFieldEnum>
  }


  /**
   * Vault create
   */
  export type VaultCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vault
     */
    select?: VaultSelect<ExtArgs> | null
    /**
     * The data needed to create a Vault.
     */
    data: XOR<VaultCreateInput, VaultUncheckedCreateInput>
  }


  /**
   * Vault createMany
   */
  export type VaultCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Vaults.
     */
    data: Enumerable<VaultCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * Vault update
   */
  export type VaultUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vault
     */
    select?: VaultSelect<ExtArgs> | null
    /**
     * The data needed to update a Vault.
     */
    data: XOR<VaultUpdateInput, VaultUncheckedUpdateInput>
    /**
     * Choose, which Vault to update.
     */
    where: VaultWhereUniqueInput
  }


  /**
   * Vault updateMany
   */
  export type VaultUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Vaults.
     */
    data: XOR<VaultUpdateManyMutationInput, VaultUncheckedUpdateManyInput>
    /**
     * Filter which Vaults to update
     */
    where?: VaultWhereInput
  }


  /**
   * Vault upsert
   */
  export type VaultUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vault
     */
    select?: VaultSelect<ExtArgs> | null
    /**
     * The filter to search for the Vault to update in case it exists.
     */
    where: VaultWhereUniqueInput
    /**
     * In case the Vault found by the `where` argument doesn't exist, create a new Vault with this data.
     */
    create: XOR<VaultCreateInput, VaultUncheckedCreateInput>
    /**
     * In case the Vault was found with the provided `where` argument, update it with this data.
     */
    update: XOR<VaultUpdateInput, VaultUncheckedUpdateInput>
  }


  /**
   * Vault delete
   */
  export type VaultDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vault
     */
    select?: VaultSelect<ExtArgs> | null
    /**
     * Filter which Vault to delete.
     */
    where: VaultWhereUniqueInput
  }


  /**
   * Vault deleteMany
   */
  export type VaultDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which Vaults to delete
     */
    where?: VaultWhereInput
  }


  /**
   * Vault without action
   */
  export type VaultArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Vault
     */
    select?: VaultSelect<ExtArgs> | null
  }



  /**
   * Model User
   */


  export type AggregateUser = {
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  export type UserMinAggregateOutputType = {
    address: string | null
    timestamp: Date | null
    user_that_referred_address: string | null
    accepted: boolean | null
  }

  export type UserMaxAggregateOutputType = {
    address: string | null
    timestamp: Date | null
    user_that_referred_address: string | null
    accepted: boolean | null
  }

  export type UserCountAggregateOutputType = {
    address: number
    timestamp: number
    user_that_referred_address: number
    accepted: number
    _all: number
  }


  export type UserMinAggregateInputType = {
    address?: true
    timestamp?: true
    user_that_referred_address?: true
    accepted?: true
  }

  export type UserMaxAggregateInputType = {
    address?: true
    timestamp?: true
    user_that_referred_address?: true
    accepted?: true
  }

  export type UserCountAggregateInputType = {
    address?: true
    timestamp?: true
    user_that_referred_address?: true
    accepted?: true
    _all?: true
  }

  export type UserAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which User to aggregate.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: Enumerable<UserOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Users
    **/
    _count?: true | UserCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserMaxAggregateInputType
  }

  export type GetUserAggregateType<T extends UserAggregateArgs> = {
        [P in keyof T & keyof AggregateUser]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser[P]>
      : GetScalarType<T[P], AggregateUser[P]>
  }




  export type UserGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: UserWhereInput
    orderBy?: Enumerable<UserOrderByWithAggregationInput>
    by: UserScalarFieldEnum[]
    having?: UserScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserCountAggregateInputType | true
    _min?: UserMinAggregateInputType
    _max?: UserMaxAggregateInputType
  }


  export type UserGroupByOutputType = {
    address: string
    timestamp: Date
    user_that_referred_address: string | null
    accepted: boolean
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  type GetUserGroupByPayload<T extends UserGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<UserGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserGroupByOutputType[P]>
            : GetScalarType<T[P], UserGroupByOutputType[P]>
        }
      >
    >


  export type UserSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    address?: boolean
    timestamp?: boolean
    user_that_referred_address?: boolean
    accepted?: boolean
    user_that_referred?: boolean | UserArgs<ExtArgs>
    referred_users?: boolean | User$referred_usersArgs<ExtArgs>
    weekly_claims?: boolean | User$weekly_claimsArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeArgs<ExtArgs>
  }, ExtArgs["result"]["user"]>

  export type UserSelectScalar = {
    address?: boolean
    timestamp?: boolean
    user_that_referred_address?: boolean
    accepted?: boolean
  }

  export type UserInclude<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    user_that_referred?: boolean | UserArgs<ExtArgs>
    referred_users?: boolean | User$referred_usersArgs<ExtArgs>
    weekly_claims?: boolean | User$weekly_claimsArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeArgs<ExtArgs>
  }


  type UserGetPayload<S extends boolean | null | undefined | UserArgs> = $Types.GetResult<UserPayload, S>

  type UserCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<UserFindManyArgs, 'select' | 'include'> & {
      select?: UserCountAggregateInputType | true
    }

  export interface UserDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['User'], meta: { name: 'User' } }
    /**
     * Find zero or one User that matches the filter.
     * @param {UserFindUniqueArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends UserFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, UserFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'User'> extends True ? Prisma__UserClient<$Types.GetResult<UserPayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__UserClient<$Types.GetResult<UserPayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one User that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {UserFindUniqueOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends UserFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, UserFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__UserClient<$Types.GetResult<UserPayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first User that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends UserFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, UserFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'User'> extends True ? Prisma__UserClient<$Types.GetResult<UserPayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__UserClient<$Types.GetResult<UserPayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first User that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends UserFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, UserFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__UserClient<$Types.GetResult<UserPayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.user.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.user.findMany({ take: 10 })
     * 
     * // Only select the `address`
     * const userWithAddressOnly = await prisma.user.findMany({ select: { address: true } })
     * 
    **/
    findMany<T extends UserFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, UserFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<UserPayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a User.
     * @param {UserCreateArgs} args - Arguments to create a User.
     * @example
     * // Create one User
     * const User = await prisma.user.create({
     *   data: {
     *     // ... data to create a User
     *   }
     * })
     * 
    **/
    create<T extends UserCreateArgs<ExtArgs>>(
      args: SelectSubset<T, UserCreateArgs<ExtArgs>>
    ): Prisma__UserClient<$Types.GetResult<UserPayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many Users.
     *     @param {UserCreateManyArgs} args - Arguments to create many Users.
     *     @example
     *     // Create many Users
     *     const user = await prisma.user.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends UserCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, UserCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a User.
     * @param {UserDeleteArgs} args - Arguments to delete one User.
     * @example
     * // Delete one User
     * const User = await prisma.user.delete({
     *   where: {
     *     // ... filter to delete one User
     *   }
     * })
     * 
    **/
    delete<T extends UserDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, UserDeleteArgs<ExtArgs>>
    ): Prisma__UserClient<$Types.GetResult<UserPayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one User.
     * @param {UserUpdateArgs} args - Arguments to update one User.
     * @example
     * // Update one User
     * const user = await prisma.user.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends UserUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, UserUpdateArgs<ExtArgs>>
    ): Prisma__UserClient<$Types.GetResult<UserPayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more Users.
     * @param {UserDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.user.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends UserDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, UserDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends UserUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, UserUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one User.
     * @param {UserUpsertArgs} args - Arguments to update or create a User.
     * @example
     * // Update or create a User
     * const user = await prisma.user.upsert({
     *   create: {
     *     // ... data to create a User
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User we want to update
     *   }
     * })
    **/
    upsert<T extends UserUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, UserUpsertArgs<ExtArgs>>
    ): Prisma__UserClient<$Types.GetResult<UserPayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.user.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends UserCountArgs>(
      args?: Subset<T, UserCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserAggregateArgs>(args: Subset<T, UserAggregateArgs>): Prisma.PrismaPromise<GetUserAggregateType<T>>

    /**
     * Group by User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserGroupByArgs['orderBy'] }
        : { orderBy?: UserGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for User.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__UserClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);

    user_that_referred<T extends UserArgs<ExtArgs> = {}>(args?: Subset<T, UserArgs<ExtArgs>>): Prisma__UserClient<$Types.GetResult<UserPayload<ExtArgs>, T, 'findUnique', never> | Null, never, ExtArgs>;

    referred_users<T extends User$referred_usersArgs<ExtArgs> = {}>(args?: Subset<T, User$referred_usersArgs<ExtArgs>>): Prisma.PrismaPromise<$Types.GetResult<UserPayload<ExtArgs>, T, 'findMany', never>| Null>;

    weekly_claims<T extends User$weekly_claimsArgs<ExtArgs> = {}>(args?: Subset<T, User$weekly_claimsArgs<ExtArgs>>): Prisma.PrismaPromise<$Types.GetResult<WeeklyClaimPayload<ExtArgs>, T, 'findMany', never>| Null>;

    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * User base type for findUnique actions
   */
  export type UserFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findUnique
   */
  export interface UserFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends UserFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * User findUniqueOrThrow
   */
  export type UserFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }


  /**
   * User base type for findFirst actions
   */
  export type UserFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: Enumerable<UserOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: Enumerable<UserScalarFieldEnum>
  }

  /**
   * User findFirst
   */
  export interface UserFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends UserFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * User findFirstOrThrow
   */
  export type UserFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: Enumerable<UserOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: Enumerable<UserScalarFieldEnum>
  }


  /**
   * User findMany
   */
  export type UserFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which Users to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: Enumerable<UserOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    distinct?: Enumerable<UserScalarFieldEnum>
  }


  /**
   * User create
   */
  export type UserCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to create a User.
     */
    data: XOR<UserCreateInput, UserUncheckedCreateInput>
  }


  /**
   * User createMany
   */
  export type UserCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Users.
     */
    data: Enumerable<UserCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * User update
   */
  export type UserUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to update a User.
     */
    data: XOR<UserUpdateInput, UserUncheckedUpdateInput>
    /**
     * Choose, which User to update.
     */
    where: UserWhereUniqueInput
  }


  /**
   * User updateMany
   */
  export type UserUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
  }


  /**
   * User upsert
   */
  export type UserUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The filter to search for the User to update in case it exists.
     */
    where: UserWhereUniqueInput
    /**
     * In case the User found by the `where` argument doesn't exist, create a new User with this data.
     */
    create: XOR<UserCreateInput, UserUncheckedCreateInput>
    /**
     * In case the User was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserUpdateInput, UserUncheckedUpdateInput>
  }


  /**
   * User delete
   */
  export type UserDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter which User to delete.
     */
    where: UserWhereUniqueInput
  }


  /**
   * User deleteMany
   */
  export type UserDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which Users to delete
     */
    where?: UserWhereInput
  }


  /**
   * User.referred_users
   */
  export type User$referred_usersArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
    where?: UserWhereInput
    orderBy?: Enumerable<UserOrderByWithRelationInput>
    cursor?: UserWhereUniqueInput
    take?: number
    skip?: number
    distinct?: Enumerable<UserScalarFieldEnum>
  }


  /**
   * User.weekly_claims
   */
  export type User$weekly_claimsArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WeeklyClaim
     */
    select?: WeeklyClaimSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: WeeklyClaimInclude<ExtArgs> | null
    where?: WeeklyClaimWhereInput
    orderBy?: Enumerable<WeeklyClaimOrderByWithRelationInput>
    cursor?: WeeklyClaimWhereUniqueInput
    take?: number
    skip?: number
    distinct?: Enumerable<WeeklyClaimScalarFieldEnum>
  }


  /**
   * User without action
   */
  export type UserArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: UserInclude<ExtArgs> | null
  }



  /**
   * Model WeeklyClaim
   */


  export type AggregateWeeklyClaim = {
    _count: WeeklyClaimCountAggregateOutputType | null
    _avg: WeeklyClaimAvgAggregateOutputType | null
    _sum: WeeklyClaimSumAggregateOutputType | null
    _min: WeeklyClaimMinAggregateOutputType | null
    _max: WeeklyClaimMaxAggregateOutputType | null
  }

  export type WeeklyClaimAvgAggregateOutputType = {
    id: number | null
    week_number: number | null
  }

  export type WeeklyClaimSumAggregateOutputType = {
    id: number | null
    week_number: number | null
  }

  export type WeeklyClaimMinAggregateOutputType = {
    id: number | null
    timestamp: Date | null
    week_number: number | null
    user_address: string | null
    amount: string | null
  }

  export type WeeklyClaimMaxAggregateOutputType = {
    id: number | null
    timestamp: Date | null
    week_number: number | null
    user_address: string | null
    amount: string | null
  }

  export type WeeklyClaimCountAggregateOutputType = {
    id: number
    timestamp: number
    week_number: number
    user_address: number
    proof: number
    amount: number
    _all: number
  }


  export type WeeklyClaimAvgAggregateInputType = {
    id?: true
    week_number?: true
  }

  export type WeeklyClaimSumAggregateInputType = {
    id?: true
    week_number?: true
  }

  export type WeeklyClaimMinAggregateInputType = {
    id?: true
    timestamp?: true
    week_number?: true
    user_address?: true
    amount?: true
  }

  export type WeeklyClaimMaxAggregateInputType = {
    id?: true
    timestamp?: true
    week_number?: true
    user_address?: true
    amount?: true
  }

  export type WeeklyClaimCountAggregateInputType = {
    id?: true
    timestamp?: true
    week_number?: true
    user_address?: true
    proof?: true
    amount?: true
    _all?: true
  }

  export type WeeklyClaimAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which WeeklyClaim to aggregate.
     */
    where?: WeeklyClaimWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WeeklyClaims to fetch.
     */
    orderBy?: Enumerable<WeeklyClaimOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: WeeklyClaimWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WeeklyClaims from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WeeklyClaims.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned WeeklyClaims
    **/
    _count?: true | WeeklyClaimCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: WeeklyClaimAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: WeeklyClaimSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: WeeklyClaimMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: WeeklyClaimMaxAggregateInputType
  }

  export type GetWeeklyClaimAggregateType<T extends WeeklyClaimAggregateArgs> = {
        [P in keyof T & keyof AggregateWeeklyClaim]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateWeeklyClaim[P]>
      : GetScalarType<T[P], AggregateWeeklyClaim[P]>
  }




  export type WeeklyClaimGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: WeeklyClaimWhereInput
    orderBy?: Enumerable<WeeklyClaimOrderByWithAggregationInput>
    by: WeeklyClaimScalarFieldEnum[]
    having?: WeeklyClaimScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: WeeklyClaimCountAggregateInputType | true
    _avg?: WeeklyClaimAvgAggregateInputType
    _sum?: WeeklyClaimSumAggregateInputType
    _min?: WeeklyClaimMinAggregateInputType
    _max?: WeeklyClaimMaxAggregateInputType
  }


  export type WeeklyClaimGroupByOutputType = {
    id: number
    timestamp: Date | null
    week_number: number
    user_address: string
    proof: string[]
    amount: string
    _count: WeeklyClaimCountAggregateOutputType | null
    _avg: WeeklyClaimAvgAggregateOutputType | null
    _sum: WeeklyClaimSumAggregateOutputType | null
    _min: WeeklyClaimMinAggregateOutputType | null
    _max: WeeklyClaimMaxAggregateOutputType | null
  }

  type GetWeeklyClaimGroupByPayload<T extends WeeklyClaimGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<WeeklyClaimGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof WeeklyClaimGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], WeeklyClaimGroupByOutputType[P]>
            : GetScalarType<T[P], WeeklyClaimGroupByOutputType[P]>
        }
      >
    >


  export type WeeklyClaimSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    timestamp?: boolean
    week_number?: boolean
    user_address?: boolean
    proof?: boolean
    amount?: boolean
    claimant?: boolean | UserArgs<ExtArgs>
  }, ExtArgs["result"]["weeklyClaim"]>

  export type WeeklyClaimSelectScalar = {
    id?: boolean
    timestamp?: boolean
    week_number?: boolean
    user_address?: boolean
    proof?: boolean
    amount?: boolean
  }

  export type WeeklyClaimInclude<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    claimant?: boolean | UserArgs<ExtArgs>
  }


  type WeeklyClaimGetPayload<S extends boolean | null | undefined | WeeklyClaimArgs> = $Types.GetResult<WeeklyClaimPayload, S>

  type WeeklyClaimCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<WeeklyClaimFindManyArgs, 'select' | 'include'> & {
      select?: WeeklyClaimCountAggregateInputType | true
    }

  export interface WeeklyClaimDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['WeeklyClaim'], meta: { name: 'WeeklyClaim' } }
    /**
     * Find zero or one WeeklyClaim that matches the filter.
     * @param {WeeklyClaimFindUniqueArgs} args - Arguments to find a WeeklyClaim
     * @example
     * // Get one WeeklyClaim
     * const weeklyClaim = await prisma.weeklyClaim.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends WeeklyClaimFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, WeeklyClaimFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'WeeklyClaim'> extends True ? Prisma__WeeklyClaimClient<$Types.GetResult<WeeklyClaimPayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__WeeklyClaimClient<$Types.GetResult<WeeklyClaimPayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one WeeklyClaim that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {WeeklyClaimFindUniqueOrThrowArgs} args - Arguments to find a WeeklyClaim
     * @example
     * // Get one WeeklyClaim
     * const weeklyClaim = await prisma.weeklyClaim.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends WeeklyClaimFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, WeeklyClaimFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__WeeklyClaimClient<$Types.GetResult<WeeklyClaimPayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first WeeklyClaim that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WeeklyClaimFindFirstArgs} args - Arguments to find a WeeklyClaim
     * @example
     * // Get one WeeklyClaim
     * const weeklyClaim = await prisma.weeklyClaim.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends WeeklyClaimFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, WeeklyClaimFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'WeeklyClaim'> extends True ? Prisma__WeeklyClaimClient<$Types.GetResult<WeeklyClaimPayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__WeeklyClaimClient<$Types.GetResult<WeeklyClaimPayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first WeeklyClaim that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WeeklyClaimFindFirstOrThrowArgs} args - Arguments to find a WeeklyClaim
     * @example
     * // Get one WeeklyClaim
     * const weeklyClaim = await prisma.weeklyClaim.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends WeeklyClaimFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, WeeklyClaimFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__WeeklyClaimClient<$Types.GetResult<WeeklyClaimPayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more WeeklyClaims that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WeeklyClaimFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all WeeklyClaims
     * const weeklyClaims = await prisma.weeklyClaim.findMany()
     * 
     * // Get first 10 WeeklyClaims
     * const weeklyClaims = await prisma.weeklyClaim.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const weeklyClaimWithIdOnly = await prisma.weeklyClaim.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends WeeklyClaimFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, WeeklyClaimFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<WeeklyClaimPayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a WeeklyClaim.
     * @param {WeeklyClaimCreateArgs} args - Arguments to create a WeeklyClaim.
     * @example
     * // Create one WeeklyClaim
     * const WeeklyClaim = await prisma.weeklyClaim.create({
     *   data: {
     *     // ... data to create a WeeklyClaim
     *   }
     * })
     * 
    **/
    create<T extends WeeklyClaimCreateArgs<ExtArgs>>(
      args: SelectSubset<T, WeeklyClaimCreateArgs<ExtArgs>>
    ): Prisma__WeeklyClaimClient<$Types.GetResult<WeeklyClaimPayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many WeeklyClaims.
     *     @param {WeeklyClaimCreateManyArgs} args - Arguments to create many WeeklyClaims.
     *     @example
     *     // Create many WeeklyClaims
     *     const weeklyClaim = await prisma.weeklyClaim.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends WeeklyClaimCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, WeeklyClaimCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a WeeklyClaim.
     * @param {WeeklyClaimDeleteArgs} args - Arguments to delete one WeeklyClaim.
     * @example
     * // Delete one WeeklyClaim
     * const WeeklyClaim = await prisma.weeklyClaim.delete({
     *   where: {
     *     // ... filter to delete one WeeklyClaim
     *   }
     * })
     * 
    **/
    delete<T extends WeeklyClaimDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, WeeklyClaimDeleteArgs<ExtArgs>>
    ): Prisma__WeeklyClaimClient<$Types.GetResult<WeeklyClaimPayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one WeeklyClaim.
     * @param {WeeklyClaimUpdateArgs} args - Arguments to update one WeeklyClaim.
     * @example
     * // Update one WeeklyClaim
     * const weeklyClaim = await prisma.weeklyClaim.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends WeeklyClaimUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, WeeklyClaimUpdateArgs<ExtArgs>>
    ): Prisma__WeeklyClaimClient<$Types.GetResult<WeeklyClaimPayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more WeeklyClaims.
     * @param {WeeklyClaimDeleteManyArgs} args - Arguments to filter WeeklyClaims to delete.
     * @example
     * // Delete a few WeeklyClaims
     * const { count } = await prisma.weeklyClaim.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends WeeklyClaimDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, WeeklyClaimDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more WeeklyClaims.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WeeklyClaimUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many WeeklyClaims
     * const weeklyClaim = await prisma.weeklyClaim.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends WeeklyClaimUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, WeeklyClaimUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one WeeklyClaim.
     * @param {WeeklyClaimUpsertArgs} args - Arguments to update or create a WeeklyClaim.
     * @example
     * // Update or create a WeeklyClaim
     * const weeklyClaim = await prisma.weeklyClaim.upsert({
     *   create: {
     *     // ... data to create a WeeklyClaim
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the WeeklyClaim we want to update
     *   }
     * })
    **/
    upsert<T extends WeeklyClaimUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, WeeklyClaimUpsertArgs<ExtArgs>>
    ): Prisma__WeeklyClaimClient<$Types.GetResult<WeeklyClaimPayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of WeeklyClaims.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WeeklyClaimCountArgs} args - Arguments to filter WeeklyClaims to count.
     * @example
     * // Count the number of WeeklyClaims
     * const count = await prisma.weeklyClaim.count({
     *   where: {
     *     // ... the filter for the WeeklyClaims we want to count
     *   }
     * })
    **/
    count<T extends WeeklyClaimCountArgs>(
      args?: Subset<T, WeeklyClaimCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], WeeklyClaimCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a WeeklyClaim.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WeeklyClaimAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends WeeklyClaimAggregateArgs>(args: Subset<T, WeeklyClaimAggregateArgs>): Prisma.PrismaPromise<GetWeeklyClaimAggregateType<T>>

    /**
     * Group by WeeklyClaim.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WeeklyClaimGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends WeeklyClaimGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: WeeklyClaimGroupByArgs['orderBy'] }
        : { orderBy?: WeeklyClaimGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, WeeklyClaimGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetWeeklyClaimGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for WeeklyClaim.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__WeeklyClaimClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);

    claimant<T extends UserArgs<ExtArgs> = {}>(args?: Subset<T, UserArgs<ExtArgs>>): Prisma__UserClient<$Types.GetResult<UserPayload<ExtArgs>, T, 'findUnique', never> | Null, never, ExtArgs>;

    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * WeeklyClaim base type for findUnique actions
   */
  export type WeeklyClaimFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WeeklyClaim
     */
    select?: WeeklyClaimSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: WeeklyClaimInclude<ExtArgs> | null
    /**
     * Filter, which WeeklyClaim to fetch.
     */
    where: WeeklyClaimWhereUniqueInput
  }

  /**
   * WeeklyClaim findUnique
   */
  export interface WeeklyClaimFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends WeeklyClaimFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * WeeklyClaim findUniqueOrThrow
   */
  export type WeeklyClaimFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WeeklyClaim
     */
    select?: WeeklyClaimSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: WeeklyClaimInclude<ExtArgs> | null
    /**
     * Filter, which WeeklyClaim to fetch.
     */
    where: WeeklyClaimWhereUniqueInput
  }


  /**
   * WeeklyClaim base type for findFirst actions
   */
  export type WeeklyClaimFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WeeklyClaim
     */
    select?: WeeklyClaimSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: WeeklyClaimInclude<ExtArgs> | null
    /**
     * Filter, which WeeklyClaim to fetch.
     */
    where?: WeeklyClaimWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WeeklyClaims to fetch.
     */
    orderBy?: Enumerable<WeeklyClaimOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for WeeklyClaims.
     */
    cursor?: WeeklyClaimWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WeeklyClaims from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WeeklyClaims.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of WeeklyClaims.
     */
    distinct?: Enumerable<WeeklyClaimScalarFieldEnum>
  }

  /**
   * WeeklyClaim findFirst
   */
  export interface WeeklyClaimFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends WeeklyClaimFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * WeeklyClaim findFirstOrThrow
   */
  export type WeeklyClaimFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WeeklyClaim
     */
    select?: WeeklyClaimSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: WeeklyClaimInclude<ExtArgs> | null
    /**
     * Filter, which WeeklyClaim to fetch.
     */
    where?: WeeklyClaimWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WeeklyClaims to fetch.
     */
    orderBy?: Enumerable<WeeklyClaimOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for WeeklyClaims.
     */
    cursor?: WeeklyClaimWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WeeklyClaims from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WeeklyClaims.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of WeeklyClaims.
     */
    distinct?: Enumerable<WeeklyClaimScalarFieldEnum>
  }


  /**
   * WeeklyClaim findMany
   */
  export type WeeklyClaimFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WeeklyClaim
     */
    select?: WeeklyClaimSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: WeeklyClaimInclude<ExtArgs> | null
    /**
     * Filter, which WeeklyClaims to fetch.
     */
    where?: WeeklyClaimWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WeeklyClaims to fetch.
     */
    orderBy?: Enumerable<WeeklyClaimOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing WeeklyClaims.
     */
    cursor?: WeeklyClaimWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WeeklyClaims from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WeeklyClaims.
     */
    skip?: number
    distinct?: Enumerable<WeeklyClaimScalarFieldEnum>
  }


  /**
   * WeeklyClaim create
   */
  export type WeeklyClaimCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WeeklyClaim
     */
    select?: WeeklyClaimSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: WeeklyClaimInclude<ExtArgs> | null
    /**
     * The data needed to create a WeeklyClaim.
     */
    data: XOR<WeeklyClaimCreateInput, WeeklyClaimUncheckedCreateInput>
  }


  /**
   * WeeklyClaim createMany
   */
  export type WeeklyClaimCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many WeeklyClaims.
     */
    data: Enumerable<WeeklyClaimCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * WeeklyClaim update
   */
  export type WeeklyClaimUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WeeklyClaim
     */
    select?: WeeklyClaimSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: WeeklyClaimInclude<ExtArgs> | null
    /**
     * The data needed to update a WeeklyClaim.
     */
    data: XOR<WeeklyClaimUpdateInput, WeeklyClaimUncheckedUpdateInput>
    /**
     * Choose, which WeeklyClaim to update.
     */
    where: WeeklyClaimWhereUniqueInput
  }


  /**
   * WeeklyClaim updateMany
   */
  export type WeeklyClaimUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update WeeklyClaims.
     */
    data: XOR<WeeklyClaimUpdateManyMutationInput, WeeklyClaimUncheckedUpdateManyInput>
    /**
     * Filter which WeeklyClaims to update
     */
    where?: WeeklyClaimWhereInput
  }


  /**
   * WeeklyClaim upsert
   */
  export type WeeklyClaimUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WeeklyClaim
     */
    select?: WeeklyClaimSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: WeeklyClaimInclude<ExtArgs> | null
    /**
     * The filter to search for the WeeklyClaim to update in case it exists.
     */
    where: WeeklyClaimWhereUniqueInput
    /**
     * In case the WeeklyClaim found by the `where` argument doesn't exist, create a new WeeklyClaim with this data.
     */
    create: XOR<WeeklyClaimCreateInput, WeeklyClaimUncheckedCreateInput>
    /**
     * In case the WeeklyClaim was found with the provided `where` argument, update it with this data.
     */
    update: XOR<WeeklyClaimUpdateInput, WeeklyClaimUncheckedUpdateInput>
  }


  /**
   * WeeklyClaim delete
   */
  export type WeeklyClaimDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WeeklyClaim
     */
    select?: WeeklyClaimSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: WeeklyClaimInclude<ExtArgs> | null
    /**
     * Filter which WeeklyClaim to delete.
     */
    where: WeeklyClaimWhereUniqueInput
  }


  /**
   * WeeklyClaim deleteMany
   */
  export type WeeklyClaimDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which WeeklyClaims to delete
     */
    where?: WeeklyClaimWhereInput
  }


  /**
   * WeeklyClaim without action
   */
  export type WeeklyClaimArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WeeklyClaim
     */
    select?: WeeklyClaimSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well.
     */
    include?: WeeklyClaimInclude<ExtArgs> | null
  }



  /**
   * Model MerkleTree
   */


  export type AggregateMerkleTree = {
    _count: MerkleTreeCountAggregateOutputType | null
    _avg: MerkleTreeAvgAggregateOutputType | null
    _sum: MerkleTreeSumAggregateOutputType | null
    _min: MerkleTreeMinAggregateOutputType | null
    _max: MerkleTreeMaxAggregateOutputType | null
  }

  export type MerkleTreeAvgAggregateOutputType = {
    week_number: number | null
    start_block: number | null
    end_block: number | null
  }

  export type MerkleTreeSumAggregateOutputType = {
    week_number: number | null
    start_block: number | null
    end_block: number | null
  }

  export type MerkleTreeMinAggregateOutputType = {
    week_number: number | null
    start_block: number | null
    end_block: number | null
    timestamp: Date | null
    tree_root: string | null
    snapshot: string | null
  }

  export type MerkleTreeMaxAggregateOutputType = {
    week_number: number | null
    start_block: number | null
    end_block: number | null
    timestamp: Date | null
    tree_root: string | null
    snapshot: string | null
  }

  export type MerkleTreeCountAggregateOutputType = {
    week_number: number
    start_block: number
    end_block: number
    timestamp: number
    tree_root: number
    snapshot: number
    _all: number
  }


  export type MerkleTreeAvgAggregateInputType = {
    week_number?: true
    start_block?: true
    end_block?: true
  }

  export type MerkleTreeSumAggregateInputType = {
    week_number?: true
    start_block?: true
    end_block?: true
  }

  export type MerkleTreeMinAggregateInputType = {
    week_number?: true
    start_block?: true
    end_block?: true
    timestamp?: true
    tree_root?: true
    snapshot?: true
  }

  export type MerkleTreeMaxAggregateInputType = {
    week_number?: true
    start_block?: true
    end_block?: true
    timestamp?: true
    tree_root?: true
    snapshot?: true
  }

  export type MerkleTreeCountAggregateInputType = {
    week_number?: true
    start_block?: true
    end_block?: true
    timestamp?: true
    tree_root?: true
    snapshot?: true
    _all?: true
  }

  export type MerkleTreeAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which MerkleTree to aggregate.
     */
    where?: MerkleTreeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MerkleTrees to fetch.
     */
    orderBy?: Enumerable<MerkleTreeOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: MerkleTreeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MerkleTrees from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MerkleTrees.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned MerkleTrees
    **/
    _count?: true | MerkleTreeCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: MerkleTreeAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: MerkleTreeSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: MerkleTreeMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: MerkleTreeMaxAggregateInputType
  }

  export type GetMerkleTreeAggregateType<T extends MerkleTreeAggregateArgs> = {
        [P in keyof T & keyof AggregateMerkleTree]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMerkleTree[P]>
      : GetScalarType<T[P], AggregateMerkleTree[P]>
  }




  export type MerkleTreeGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: MerkleTreeWhereInput
    orderBy?: Enumerable<MerkleTreeOrderByWithAggregationInput>
    by: MerkleTreeScalarFieldEnum[]
    having?: MerkleTreeScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: MerkleTreeCountAggregateInputType | true
    _avg?: MerkleTreeAvgAggregateInputType
    _sum?: MerkleTreeSumAggregateInputType
    _min?: MerkleTreeMinAggregateInputType
    _max?: MerkleTreeMaxAggregateInputType
  }


  export type MerkleTreeGroupByOutputType = {
    week_number: number
    start_block: number | null
    end_block: number | null
    timestamp: Date | null
    tree_root: string
    snapshot: string | null
    _count: MerkleTreeCountAggregateOutputType | null
    _avg: MerkleTreeAvgAggregateOutputType | null
    _sum: MerkleTreeSumAggregateOutputType | null
    _min: MerkleTreeMinAggregateOutputType | null
    _max: MerkleTreeMaxAggregateOutputType | null
  }

  type GetMerkleTreeGroupByPayload<T extends MerkleTreeGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<MerkleTreeGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof MerkleTreeGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], MerkleTreeGroupByOutputType[P]>
            : GetScalarType<T[P], MerkleTreeGroupByOutputType[P]>
        }
      >
    >


  export type MerkleTreeSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    week_number?: boolean
    start_block?: boolean
    end_block?: boolean
    timestamp?: boolean
    tree_root?: boolean
    snapshot?: boolean
  }, ExtArgs["result"]["merkleTree"]>

  export type MerkleTreeSelectScalar = {
    week_number?: boolean
    start_block?: boolean
    end_block?: boolean
    timestamp?: boolean
    tree_root?: boolean
    snapshot?: boolean
  }


  type MerkleTreeGetPayload<S extends boolean | null | undefined | MerkleTreeArgs> = $Types.GetResult<MerkleTreePayload, S>

  type MerkleTreeCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<MerkleTreeFindManyArgs, 'select' | 'include'> & {
      select?: MerkleTreeCountAggregateInputType | true
    }

  export interface MerkleTreeDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['MerkleTree'], meta: { name: 'MerkleTree' } }
    /**
     * Find zero or one MerkleTree that matches the filter.
     * @param {MerkleTreeFindUniqueArgs} args - Arguments to find a MerkleTree
     * @example
     * // Get one MerkleTree
     * const merkleTree = await prisma.merkleTree.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends MerkleTreeFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, MerkleTreeFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'MerkleTree'> extends True ? Prisma__MerkleTreeClient<$Types.GetResult<MerkleTreePayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__MerkleTreeClient<$Types.GetResult<MerkleTreePayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one MerkleTree that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {MerkleTreeFindUniqueOrThrowArgs} args - Arguments to find a MerkleTree
     * @example
     * // Get one MerkleTree
     * const merkleTree = await prisma.merkleTree.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends MerkleTreeFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, MerkleTreeFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__MerkleTreeClient<$Types.GetResult<MerkleTreePayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first MerkleTree that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MerkleTreeFindFirstArgs} args - Arguments to find a MerkleTree
     * @example
     * // Get one MerkleTree
     * const merkleTree = await prisma.merkleTree.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends MerkleTreeFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, MerkleTreeFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'MerkleTree'> extends True ? Prisma__MerkleTreeClient<$Types.GetResult<MerkleTreePayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__MerkleTreeClient<$Types.GetResult<MerkleTreePayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first MerkleTree that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MerkleTreeFindFirstOrThrowArgs} args - Arguments to find a MerkleTree
     * @example
     * // Get one MerkleTree
     * const merkleTree = await prisma.merkleTree.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends MerkleTreeFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, MerkleTreeFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__MerkleTreeClient<$Types.GetResult<MerkleTreePayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more MerkleTrees that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MerkleTreeFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all MerkleTrees
     * const merkleTrees = await prisma.merkleTree.findMany()
     * 
     * // Get first 10 MerkleTrees
     * const merkleTrees = await prisma.merkleTree.findMany({ take: 10 })
     * 
     * // Only select the `week_number`
     * const merkleTreeWithWeek_numberOnly = await prisma.merkleTree.findMany({ select: { week_number: true } })
     * 
    **/
    findMany<T extends MerkleTreeFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, MerkleTreeFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<MerkleTreePayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a MerkleTree.
     * @param {MerkleTreeCreateArgs} args - Arguments to create a MerkleTree.
     * @example
     * // Create one MerkleTree
     * const MerkleTree = await prisma.merkleTree.create({
     *   data: {
     *     // ... data to create a MerkleTree
     *   }
     * })
     * 
    **/
    create<T extends MerkleTreeCreateArgs<ExtArgs>>(
      args: SelectSubset<T, MerkleTreeCreateArgs<ExtArgs>>
    ): Prisma__MerkleTreeClient<$Types.GetResult<MerkleTreePayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many MerkleTrees.
     *     @param {MerkleTreeCreateManyArgs} args - Arguments to create many MerkleTrees.
     *     @example
     *     // Create many MerkleTrees
     *     const merkleTree = await prisma.merkleTree.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends MerkleTreeCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, MerkleTreeCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a MerkleTree.
     * @param {MerkleTreeDeleteArgs} args - Arguments to delete one MerkleTree.
     * @example
     * // Delete one MerkleTree
     * const MerkleTree = await prisma.merkleTree.delete({
     *   where: {
     *     // ... filter to delete one MerkleTree
     *   }
     * })
     * 
    **/
    delete<T extends MerkleTreeDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, MerkleTreeDeleteArgs<ExtArgs>>
    ): Prisma__MerkleTreeClient<$Types.GetResult<MerkleTreePayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one MerkleTree.
     * @param {MerkleTreeUpdateArgs} args - Arguments to update one MerkleTree.
     * @example
     * // Update one MerkleTree
     * const merkleTree = await prisma.merkleTree.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends MerkleTreeUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, MerkleTreeUpdateArgs<ExtArgs>>
    ): Prisma__MerkleTreeClient<$Types.GetResult<MerkleTreePayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more MerkleTrees.
     * @param {MerkleTreeDeleteManyArgs} args - Arguments to filter MerkleTrees to delete.
     * @example
     * // Delete a few MerkleTrees
     * const { count } = await prisma.merkleTree.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends MerkleTreeDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, MerkleTreeDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more MerkleTrees.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MerkleTreeUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many MerkleTrees
     * const merkleTree = await prisma.merkleTree.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends MerkleTreeUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, MerkleTreeUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one MerkleTree.
     * @param {MerkleTreeUpsertArgs} args - Arguments to update or create a MerkleTree.
     * @example
     * // Update or create a MerkleTree
     * const merkleTree = await prisma.merkleTree.upsert({
     *   create: {
     *     // ... data to create a MerkleTree
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the MerkleTree we want to update
     *   }
     * })
    **/
    upsert<T extends MerkleTreeUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, MerkleTreeUpsertArgs<ExtArgs>>
    ): Prisma__MerkleTreeClient<$Types.GetResult<MerkleTreePayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of MerkleTrees.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MerkleTreeCountArgs} args - Arguments to filter MerkleTrees to count.
     * @example
     * // Count the number of MerkleTrees
     * const count = await prisma.merkleTree.count({
     *   where: {
     *     // ... the filter for the MerkleTrees we want to count
     *   }
     * })
    **/
    count<T extends MerkleTreeCountArgs>(
      args?: Subset<T, MerkleTreeCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], MerkleTreeCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a MerkleTree.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MerkleTreeAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends MerkleTreeAggregateArgs>(args: Subset<T, MerkleTreeAggregateArgs>): Prisma.PrismaPromise<GetMerkleTreeAggregateType<T>>

    /**
     * Group by MerkleTree.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MerkleTreeGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends MerkleTreeGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: MerkleTreeGroupByArgs['orderBy'] }
        : { orderBy?: MerkleTreeGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, MerkleTreeGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMerkleTreeGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for MerkleTree.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__MerkleTreeClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * MerkleTree base type for findUnique actions
   */
  export type MerkleTreeFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MerkleTree
     */
    select?: MerkleTreeSelect<ExtArgs> | null
    /**
     * Filter, which MerkleTree to fetch.
     */
    where: MerkleTreeWhereUniqueInput
  }

  /**
   * MerkleTree findUnique
   */
  export interface MerkleTreeFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends MerkleTreeFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * MerkleTree findUniqueOrThrow
   */
  export type MerkleTreeFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MerkleTree
     */
    select?: MerkleTreeSelect<ExtArgs> | null
    /**
     * Filter, which MerkleTree to fetch.
     */
    where: MerkleTreeWhereUniqueInput
  }


  /**
   * MerkleTree base type for findFirst actions
   */
  export type MerkleTreeFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MerkleTree
     */
    select?: MerkleTreeSelect<ExtArgs> | null
    /**
     * Filter, which MerkleTree to fetch.
     */
    where?: MerkleTreeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MerkleTrees to fetch.
     */
    orderBy?: Enumerable<MerkleTreeOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MerkleTrees.
     */
    cursor?: MerkleTreeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MerkleTrees from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MerkleTrees.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MerkleTrees.
     */
    distinct?: Enumerable<MerkleTreeScalarFieldEnum>
  }

  /**
   * MerkleTree findFirst
   */
  export interface MerkleTreeFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends MerkleTreeFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * MerkleTree findFirstOrThrow
   */
  export type MerkleTreeFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MerkleTree
     */
    select?: MerkleTreeSelect<ExtArgs> | null
    /**
     * Filter, which MerkleTree to fetch.
     */
    where?: MerkleTreeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MerkleTrees to fetch.
     */
    orderBy?: Enumerable<MerkleTreeOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MerkleTrees.
     */
    cursor?: MerkleTreeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MerkleTrees from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MerkleTrees.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MerkleTrees.
     */
    distinct?: Enumerable<MerkleTreeScalarFieldEnum>
  }


  /**
   * MerkleTree findMany
   */
  export type MerkleTreeFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MerkleTree
     */
    select?: MerkleTreeSelect<ExtArgs> | null
    /**
     * Filter, which MerkleTrees to fetch.
     */
    where?: MerkleTreeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MerkleTrees to fetch.
     */
    orderBy?: Enumerable<MerkleTreeOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing MerkleTrees.
     */
    cursor?: MerkleTreeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MerkleTrees from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MerkleTrees.
     */
    skip?: number
    distinct?: Enumerable<MerkleTreeScalarFieldEnum>
  }


  /**
   * MerkleTree create
   */
  export type MerkleTreeCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MerkleTree
     */
    select?: MerkleTreeSelect<ExtArgs> | null
    /**
     * The data needed to create a MerkleTree.
     */
    data: XOR<MerkleTreeCreateInput, MerkleTreeUncheckedCreateInput>
  }


  /**
   * MerkleTree createMany
   */
  export type MerkleTreeCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many MerkleTrees.
     */
    data: Enumerable<MerkleTreeCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * MerkleTree update
   */
  export type MerkleTreeUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MerkleTree
     */
    select?: MerkleTreeSelect<ExtArgs> | null
    /**
     * The data needed to update a MerkleTree.
     */
    data: XOR<MerkleTreeUpdateInput, MerkleTreeUncheckedUpdateInput>
    /**
     * Choose, which MerkleTree to update.
     */
    where: MerkleTreeWhereUniqueInput
  }


  /**
   * MerkleTree updateMany
   */
  export type MerkleTreeUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update MerkleTrees.
     */
    data: XOR<MerkleTreeUpdateManyMutationInput, MerkleTreeUncheckedUpdateManyInput>
    /**
     * Filter which MerkleTrees to update
     */
    where?: MerkleTreeWhereInput
  }


  /**
   * MerkleTree upsert
   */
  export type MerkleTreeUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MerkleTree
     */
    select?: MerkleTreeSelect<ExtArgs> | null
    /**
     * The filter to search for the MerkleTree to update in case it exists.
     */
    where: MerkleTreeWhereUniqueInput
    /**
     * In case the MerkleTree found by the `where` argument doesn't exist, create a new MerkleTree with this data.
     */
    create: XOR<MerkleTreeCreateInput, MerkleTreeUncheckedCreateInput>
    /**
     * In case the MerkleTree was found with the provided `where` argument, update it with this data.
     */
    update: XOR<MerkleTreeUpdateInput, MerkleTreeUncheckedUpdateInput>
  }


  /**
   * MerkleTree delete
   */
  export type MerkleTreeDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MerkleTree
     */
    select?: MerkleTreeSelect<ExtArgs> | null
    /**
     * Filter which MerkleTree to delete.
     */
    where: MerkleTreeWhereUniqueInput
  }


  /**
   * MerkleTree deleteMany
   */
  export type MerkleTreeDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which MerkleTrees to delete
     */
    where?: MerkleTreeWhereInput
  }


  /**
   * MerkleTree without action
   */
  export type MerkleTreeArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MerkleTree
     */
    select?: MerkleTreeSelect<ExtArgs> | null
  }



  /**
   * Model WalletRisk
   */


  export type AggregateWalletRisk = {
    _count: WalletRiskCountAggregateOutputType | null
    _min: WalletRiskMinAggregateOutputType | null
    _max: WalletRiskMaxAggregateOutputType | null
  }

  export type WalletRiskMinAggregateOutputType = {
    address: string | null
    last_check: Date | null
    is_risky: boolean | null
  }

  export type WalletRiskMaxAggregateOutputType = {
    address: string | null
    last_check: Date | null
    is_risky: boolean | null
  }

  export type WalletRiskCountAggregateOutputType = {
    address: number
    last_check: number
    is_risky: number
    _all: number
  }


  export type WalletRiskMinAggregateInputType = {
    address?: true
    last_check?: true
    is_risky?: true
  }

  export type WalletRiskMaxAggregateInputType = {
    address?: true
    last_check?: true
    is_risky?: true
  }

  export type WalletRiskCountAggregateInputType = {
    address?: true
    last_check?: true
    is_risky?: true
    _all?: true
  }

  export type WalletRiskAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which WalletRisk to aggregate.
     */
    where?: WalletRiskWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WalletRisks to fetch.
     */
    orderBy?: Enumerable<WalletRiskOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: WalletRiskWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WalletRisks from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WalletRisks.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned WalletRisks
    **/
    _count?: true | WalletRiskCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: WalletRiskMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: WalletRiskMaxAggregateInputType
  }

  export type GetWalletRiskAggregateType<T extends WalletRiskAggregateArgs> = {
        [P in keyof T & keyof AggregateWalletRisk]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateWalletRisk[P]>
      : GetScalarType<T[P], AggregateWalletRisk[P]>
  }




  export type WalletRiskGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: WalletRiskWhereInput
    orderBy?: Enumerable<WalletRiskOrderByWithAggregationInput>
    by: WalletRiskScalarFieldEnum[]
    having?: WalletRiskScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: WalletRiskCountAggregateInputType | true
    _min?: WalletRiskMinAggregateInputType
    _max?: WalletRiskMaxAggregateInputType
  }


  export type WalletRiskGroupByOutputType = {
    address: string
    last_check: Date
    is_risky: boolean
    _count: WalletRiskCountAggregateOutputType | null
    _min: WalletRiskMinAggregateOutputType | null
    _max: WalletRiskMaxAggregateOutputType | null
  }

  type GetWalletRiskGroupByPayload<T extends WalletRiskGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<WalletRiskGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof WalletRiskGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], WalletRiskGroupByOutputType[P]>
            : GetScalarType<T[P], WalletRiskGroupByOutputType[P]>
        }
      >
    >


  export type WalletRiskSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    address?: boolean
    last_check?: boolean
    is_risky?: boolean
  }, ExtArgs["result"]["walletRisk"]>

  export type WalletRiskSelectScalar = {
    address?: boolean
    last_check?: boolean
    is_risky?: boolean
  }


  type WalletRiskGetPayload<S extends boolean | null | undefined | WalletRiskArgs> = $Types.GetResult<WalletRiskPayload, S>

  type WalletRiskCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<WalletRiskFindManyArgs, 'select' | 'include'> & {
      select?: WalletRiskCountAggregateInputType | true
    }

  export interface WalletRiskDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['WalletRisk'], meta: { name: 'WalletRisk' } }
    /**
     * Find zero or one WalletRisk that matches the filter.
     * @param {WalletRiskFindUniqueArgs} args - Arguments to find a WalletRisk
     * @example
     * // Get one WalletRisk
     * const walletRisk = await prisma.walletRisk.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends WalletRiskFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, WalletRiskFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'WalletRisk'> extends True ? Prisma__WalletRiskClient<$Types.GetResult<WalletRiskPayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__WalletRiskClient<$Types.GetResult<WalletRiskPayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one WalletRisk that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {WalletRiskFindUniqueOrThrowArgs} args - Arguments to find a WalletRisk
     * @example
     * // Get one WalletRisk
     * const walletRisk = await prisma.walletRisk.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends WalletRiskFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, WalletRiskFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__WalletRiskClient<$Types.GetResult<WalletRiskPayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first WalletRisk that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WalletRiskFindFirstArgs} args - Arguments to find a WalletRisk
     * @example
     * // Get one WalletRisk
     * const walletRisk = await prisma.walletRisk.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends WalletRiskFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, WalletRiskFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'WalletRisk'> extends True ? Prisma__WalletRiskClient<$Types.GetResult<WalletRiskPayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__WalletRiskClient<$Types.GetResult<WalletRiskPayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first WalletRisk that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WalletRiskFindFirstOrThrowArgs} args - Arguments to find a WalletRisk
     * @example
     * // Get one WalletRisk
     * const walletRisk = await prisma.walletRisk.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends WalletRiskFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, WalletRiskFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__WalletRiskClient<$Types.GetResult<WalletRiskPayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more WalletRisks that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WalletRiskFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all WalletRisks
     * const walletRisks = await prisma.walletRisk.findMany()
     * 
     * // Get first 10 WalletRisks
     * const walletRisks = await prisma.walletRisk.findMany({ take: 10 })
     * 
     * // Only select the `address`
     * const walletRiskWithAddressOnly = await prisma.walletRisk.findMany({ select: { address: true } })
     * 
    **/
    findMany<T extends WalletRiskFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, WalletRiskFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<WalletRiskPayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a WalletRisk.
     * @param {WalletRiskCreateArgs} args - Arguments to create a WalletRisk.
     * @example
     * // Create one WalletRisk
     * const WalletRisk = await prisma.walletRisk.create({
     *   data: {
     *     // ... data to create a WalletRisk
     *   }
     * })
     * 
    **/
    create<T extends WalletRiskCreateArgs<ExtArgs>>(
      args: SelectSubset<T, WalletRiskCreateArgs<ExtArgs>>
    ): Prisma__WalletRiskClient<$Types.GetResult<WalletRiskPayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many WalletRisks.
     *     @param {WalletRiskCreateManyArgs} args - Arguments to create many WalletRisks.
     *     @example
     *     // Create many WalletRisks
     *     const walletRisk = await prisma.walletRisk.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends WalletRiskCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, WalletRiskCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a WalletRisk.
     * @param {WalletRiskDeleteArgs} args - Arguments to delete one WalletRisk.
     * @example
     * // Delete one WalletRisk
     * const WalletRisk = await prisma.walletRisk.delete({
     *   where: {
     *     // ... filter to delete one WalletRisk
     *   }
     * })
     * 
    **/
    delete<T extends WalletRiskDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, WalletRiskDeleteArgs<ExtArgs>>
    ): Prisma__WalletRiskClient<$Types.GetResult<WalletRiskPayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one WalletRisk.
     * @param {WalletRiskUpdateArgs} args - Arguments to update one WalletRisk.
     * @example
     * // Update one WalletRisk
     * const walletRisk = await prisma.walletRisk.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends WalletRiskUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, WalletRiskUpdateArgs<ExtArgs>>
    ): Prisma__WalletRiskClient<$Types.GetResult<WalletRiskPayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more WalletRisks.
     * @param {WalletRiskDeleteManyArgs} args - Arguments to filter WalletRisks to delete.
     * @example
     * // Delete a few WalletRisks
     * const { count } = await prisma.walletRisk.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends WalletRiskDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, WalletRiskDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more WalletRisks.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WalletRiskUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many WalletRisks
     * const walletRisk = await prisma.walletRisk.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends WalletRiskUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, WalletRiskUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one WalletRisk.
     * @param {WalletRiskUpsertArgs} args - Arguments to update or create a WalletRisk.
     * @example
     * // Update or create a WalletRisk
     * const walletRisk = await prisma.walletRisk.upsert({
     *   create: {
     *     // ... data to create a WalletRisk
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the WalletRisk we want to update
     *   }
     * })
    **/
    upsert<T extends WalletRiskUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, WalletRiskUpsertArgs<ExtArgs>>
    ): Prisma__WalletRiskClient<$Types.GetResult<WalletRiskPayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of WalletRisks.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WalletRiskCountArgs} args - Arguments to filter WalletRisks to count.
     * @example
     * // Count the number of WalletRisks
     * const count = await prisma.walletRisk.count({
     *   where: {
     *     // ... the filter for the WalletRisks we want to count
     *   }
     * })
    **/
    count<T extends WalletRiskCountArgs>(
      args?: Subset<T, WalletRiskCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], WalletRiskCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a WalletRisk.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WalletRiskAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends WalletRiskAggregateArgs>(args: Subset<T, WalletRiskAggregateArgs>): Prisma.PrismaPromise<GetWalletRiskAggregateType<T>>

    /**
     * Group by WalletRisk.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WalletRiskGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends WalletRiskGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: WalletRiskGroupByArgs['orderBy'] }
        : { orderBy?: WalletRiskGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, WalletRiskGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetWalletRiskGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for WalletRisk.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__WalletRiskClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * WalletRisk base type for findUnique actions
   */
  export type WalletRiskFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WalletRisk
     */
    select?: WalletRiskSelect<ExtArgs> | null
    /**
     * Filter, which WalletRisk to fetch.
     */
    where: WalletRiskWhereUniqueInput
  }

  /**
   * WalletRisk findUnique
   */
  export interface WalletRiskFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends WalletRiskFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * WalletRisk findUniqueOrThrow
   */
  export type WalletRiskFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WalletRisk
     */
    select?: WalletRiskSelect<ExtArgs> | null
    /**
     * Filter, which WalletRisk to fetch.
     */
    where: WalletRiskWhereUniqueInput
  }


  /**
   * WalletRisk base type for findFirst actions
   */
  export type WalletRiskFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WalletRisk
     */
    select?: WalletRiskSelect<ExtArgs> | null
    /**
     * Filter, which WalletRisk to fetch.
     */
    where?: WalletRiskWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WalletRisks to fetch.
     */
    orderBy?: Enumerable<WalletRiskOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for WalletRisks.
     */
    cursor?: WalletRiskWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WalletRisks from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WalletRisks.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of WalletRisks.
     */
    distinct?: Enumerable<WalletRiskScalarFieldEnum>
  }

  /**
   * WalletRisk findFirst
   */
  export interface WalletRiskFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends WalletRiskFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * WalletRisk findFirstOrThrow
   */
  export type WalletRiskFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WalletRisk
     */
    select?: WalletRiskSelect<ExtArgs> | null
    /**
     * Filter, which WalletRisk to fetch.
     */
    where?: WalletRiskWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WalletRisks to fetch.
     */
    orderBy?: Enumerable<WalletRiskOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for WalletRisks.
     */
    cursor?: WalletRiskWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WalletRisks from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WalletRisks.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of WalletRisks.
     */
    distinct?: Enumerable<WalletRiskScalarFieldEnum>
  }


  /**
   * WalletRisk findMany
   */
  export type WalletRiskFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WalletRisk
     */
    select?: WalletRiskSelect<ExtArgs> | null
    /**
     * Filter, which WalletRisks to fetch.
     */
    where?: WalletRiskWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WalletRisks to fetch.
     */
    orderBy?: Enumerable<WalletRiskOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing WalletRisks.
     */
    cursor?: WalletRiskWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WalletRisks from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WalletRisks.
     */
    skip?: number
    distinct?: Enumerable<WalletRiskScalarFieldEnum>
  }


  /**
   * WalletRisk create
   */
  export type WalletRiskCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WalletRisk
     */
    select?: WalletRiskSelect<ExtArgs> | null
    /**
     * The data needed to create a WalletRisk.
     */
    data: XOR<WalletRiskCreateInput, WalletRiskUncheckedCreateInput>
  }


  /**
   * WalletRisk createMany
   */
  export type WalletRiskCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many WalletRisks.
     */
    data: Enumerable<WalletRiskCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * WalletRisk update
   */
  export type WalletRiskUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WalletRisk
     */
    select?: WalletRiskSelect<ExtArgs> | null
    /**
     * The data needed to update a WalletRisk.
     */
    data: XOR<WalletRiskUpdateInput, WalletRiskUncheckedUpdateInput>
    /**
     * Choose, which WalletRisk to update.
     */
    where: WalletRiskWhereUniqueInput
  }


  /**
   * WalletRisk updateMany
   */
  export type WalletRiskUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update WalletRisks.
     */
    data: XOR<WalletRiskUpdateManyMutationInput, WalletRiskUncheckedUpdateManyInput>
    /**
     * Filter which WalletRisks to update
     */
    where?: WalletRiskWhereInput
  }


  /**
   * WalletRisk upsert
   */
  export type WalletRiskUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WalletRisk
     */
    select?: WalletRiskSelect<ExtArgs> | null
    /**
     * The filter to search for the WalletRisk to update in case it exists.
     */
    where: WalletRiskWhereUniqueInput
    /**
     * In case the WalletRisk found by the `where` argument doesn't exist, create a new WalletRisk with this data.
     */
    create: XOR<WalletRiskCreateInput, WalletRiskUncheckedCreateInput>
    /**
     * In case the WalletRisk was found with the provided `where` argument, update it with this data.
     */
    update: XOR<WalletRiskUpdateInput, WalletRiskUncheckedUpdateInput>
  }


  /**
   * WalletRisk delete
   */
  export type WalletRiskDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WalletRisk
     */
    select?: WalletRiskSelect<ExtArgs> | null
    /**
     * Filter which WalletRisk to delete.
     */
    where: WalletRiskWhereUniqueInput
  }


  /**
   * WalletRisk deleteMany
   */
  export type WalletRiskDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which WalletRisks to delete
     */
    where?: WalletRiskWhereInput
  }


  /**
   * WalletRisk without action
   */
  export type WalletRiskArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WalletRisk
     */
    select?: WalletRiskSelect<ExtArgs> | null
  }



  /**
   * Model CollateralType
   */


  export type AggregateCollateralType = {
    _count: CollateralTypeCountAggregateOutputType | null
    _avg: CollateralTypeAvgAggregateOutputType | null
    _sum: CollateralTypeSumAggregateOutputType | null
    _min: CollateralTypeMinAggregateOutputType | null
    _max: CollateralTypeMaxAggregateOutputType | null
  }

  export type CollateralTypeAvgAggregateOutputType = {
    next_price: Decimal | null
    current_price: Decimal | null
    liquidation_ratio: Decimal | null
    liquidation_penalty: Decimal | null
    rate: Decimal | null
    market_price: Decimal | null
  }

  export type CollateralTypeSumAggregateOutputType = {
    next_price: Decimal | null
    current_price: Decimal | null
    liquidation_ratio: Decimal | null
    liquidation_penalty: Decimal | null
    rate: Decimal | null
    market_price: Decimal | null
  }

  export type CollateralTypeMinAggregateOutputType = {
    collateral_name: string | null
    token: string | null
    next_price: Decimal | null
    current_price: Decimal | null
    liquidation_ratio: Decimal | null
    liquidation_penalty: Decimal | null
    rate: Decimal | null
    market_price: Decimal | null
  }

  export type CollateralTypeMaxAggregateOutputType = {
    collateral_name: string | null
    token: string | null
    next_price: Decimal | null
    current_price: Decimal | null
    liquidation_ratio: Decimal | null
    liquidation_penalty: Decimal | null
    rate: Decimal | null
    market_price: Decimal | null
  }

  export type CollateralTypeCountAggregateOutputType = {
    collateral_name: number
    token: number
    next_price: number
    current_price: number
    liquidation_ratio: number
    liquidation_penalty: number
    rate: number
    market_price: number
    _all: number
  }


  export type CollateralTypeAvgAggregateInputType = {
    next_price?: true
    current_price?: true
    liquidation_ratio?: true
    liquidation_penalty?: true
    rate?: true
    market_price?: true
  }

  export type CollateralTypeSumAggregateInputType = {
    next_price?: true
    current_price?: true
    liquidation_ratio?: true
    liquidation_penalty?: true
    rate?: true
    market_price?: true
  }

  export type CollateralTypeMinAggregateInputType = {
    collateral_name?: true
    token?: true
    next_price?: true
    current_price?: true
    liquidation_ratio?: true
    liquidation_penalty?: true
    rate?: true
    market_price?: true
  }

  export type CollateralTypeMaxAggregateInputType = {
    collateral_name?: true
    token?: true
    next_price?: true
    current_price?: true
    liquidation_ratio?: true
    liquidation_penalty?: true
    rate?: true
    market_price?: true
  }

  export type CollateralTypeCountAggregateInputType = {
    collateral_name?: true
    token?: true
    next_price?: true
    current_price?: true
    liquidation_ratio?: true
    liquidation_penalty?: true
    rate?: true
    market_price?: true
    _all?: true
  }

  export type CollateralTypeAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which CollateralType to aggregate.
     */
    where?: CollateralTypeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CollateralTypes to fetch.
     */
    orderBy?: Enumerable<CollateralTypeOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: CollateralTypeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CollateralTypes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CollateralTypes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned CollateralTypes
    **/
    _count?: true | CollateralTypeCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: CollateralTypeAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: CollateralTypeSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CollateralTypeMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CollateralTypeMaxAggregateInputType
  }

  export type GetCollateralTypeAggregateType<T extends CollateralTypeAggregateArgs> = {
        [P in keyof T & keyof AggregateCollateralType]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCollateralType[P]>
      : GetScalarType<T[P], AggregateCollateralType[P]>
  }




  export type CollateralTypeGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: CollateralTypeWhereInput
    orderBy?: Enumerable<CollateralTypeOrderByWithAggregationInput>
    by: CollateralTypeScalarFieldEnum[]
    having?: CollateralTypeScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CollateralTypeCountAggregateInputType | true
    _avg?: CollateralTypeAvgAggregateInputType
    _sum?: CollateralTypeSumAggregateInputType
    _min?: CollateralTypeMinAggregateInputType
    _max?: CollateralTypeMaxAggregateInputType
  }


  export type CollateralTypeGroupByOutputType = {
    collateral_name: string
    token: string
    next_price: Decimal
    current_price: Decimal
    liquidation_ratio: Decimal
    liquidation_penalty: Decimal
    rate: Decimal | null
    market_price: Decimal | null
    _count: CollateralTypeCountAggregateOutputType | null
    _avg: CollateralTypeAvgAggregateOutputType | null
    _sum: CollateralTypeSumAggregateOutputType | null
    _min: CollateralTypeMinAggregateOutputType | null
    _max: CollateralTypeMaxAggregateOutputType | null
  }

  type GetCollateralTypeGroupByPayload<T extends CollateralTypeGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<CollateralTypeGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CollateralTypeGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CollateralTypeGroupByOutputType[P]>
            : GetScalarType<T[P], CollateralTypeGroupByOutputType[P]>
        }
      >
    >


  export type CollateralTypeSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    collateral_name?: boolean
    token?: boolean
    next_price?: boolean
    current_price?: boolean
    liquidation_ratio?: boolean
    liquidation_penalty?: boolean
    rate?: boolean
    market_price?: boolean
  }, ExtArgs["result"]["collateralType"]>

  export type CollateralTypeSelectScalar = {
    collateral_name?: boolean
    token?: boolean
    next_price?: boolean
    current_price?: boolean
    liquidation_ratio?: boolean
    liquidation_penalty?: boolean
    rate?: boolean
    market_price?: boolean
  }


  type CollateralTypeGetPayload<S extends boolean | null | undefined | CollateralTypeArgs> = $Types.GetResult<CollateralTypePayload, S>

  type CollateralTypeCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<CollateralTypeFindManyArgs, 'select' | 'include'> & {
      select?: CollateralTypeCountAggregateInputType | true
    }

  export interface CollateralTypeDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['CollateralType'], meta: { name: 'CollateralType' } }
    /**
     * Find zero or one CollateralType that matches the filter.
     * @param {CollateralTypeFindUniqueArgs} args - Arguments to find a CollateralType
     * @example
     * // Get one CollateralType
     * const collateralType = await prisma.collateralType.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends CollateralTypeFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, CollateralTypeFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'CollateralType'> extends True ? Prisma__CollateralTypeClient<$Types.GetResult<CollateralTypePayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__CollateralTypeClient<$Types.GetResult<CollateralTypePayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one CollateralType that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {CollateralTypeFindUniqueOrThrowArgs} args - Arguments to find a CollateralType
     * @example
     * // Get one CollateralType
     * const collateralType = await prisma.collateralType.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends CollateralTypeFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, CollateralTypeFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__CollateralTypeClient<$Types.GetResult<CollateralTypePayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first CollateralType that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CollateralTypeFindFirstArgs} args - Arguments to find a CollateralType
     * @example
     * // Get one CollateralType
     * const collateralType = await prisma.collateralType.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends CollateralTypeFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, CollateralTypeFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'CollateralType'> extends True ? Prisma__CollateralTypeClient<$Types.GetResult<CollateralTypePayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__CollateralTypeClient<$Types.GetResult<CollateralTypePayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first CollateralType that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CollateralTypeFindFirstOrThrowArgs} args - Arguments to find a CollateralType
     * @example
     * // Get one CollateralType
     * const collateralType = await prisma.collateralType.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends CollateralTypeFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, CollateralTypeFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__CollateralTypeClient<$Types.GetResult<CollateralTypePayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more CollateralTypes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CollateralTypeFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all CollateralTypes
     * const collateralTypes = await prisma.collateralType.findMany()
     * 
     * // Get first 10 CollateralTypes
     * const collateralTypes = await prisma.collateralType.findMany({ take: 10 })
     * 
     * // Only select the `collateral_name`
     * const collateralTypeWithCollateral_nameOnly = await prisma.collateralType.findMany({ select: { collateral_name: true } })
     * 
    **/
    findMany<T extends CollateralTypeFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, CollateralTypeFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<CollateralTypePayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a CollateralType.
     * @param {CollateralTypeCreateArgs} args - Arguments to create a CollateralType.
     * @example
     * // Create one CollateralType
     * const CollateralType = await prisma.collateralType.create({
     *   data: {
     *     // ... data to create a CollateralType
     *   }
     * })
     * 
    **/
    create<T extends CollateralTypeCreateArgs<ExtArgs>>(
      args: SelectSubset<T, CollateralTypeCreateArgs<ExtArgs>>
    ): Prisma__CollateralTypeClient<$Types.GetResult<CollateralTypePayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many CollateralTypes.
     *     @param {CollateralTypeCreateManyArgs} args - Arguments to create many CollateralTypes.
     *     @example
     *     // Create many CollateralTypes
     *     const collateralType = await prisma.collateralType.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends CollateralTypeCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, CollateralTypeCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a CollateralType.
     * @param {CollateralTypeDeleteArgs} args - Arguments to delete one CollateralType.
     * @example
     * // Delete one CollateralType
     * const CollateralType = await prisma.collateralType.delete({
     *   where: {
     *     // ... filter to delete one CollateralType
     *   }
     * })
     * 
    **/
    delete<T extends CollateralTypeDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, CollateralTypeDeleteArgs<ExtArgs>>
    ): Prisma__CollateralTypeClient<$Types.GetResult<CollateralTypePayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one CollateralType.
     * @param {CollateralTypeUpdateArgs} args - Arguments to update one CollateralType.
     * @example
     * // Update one CollateralType
     * const collateralType = await prisma.collateralType.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends CollateralTypeUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, CollateralTypeUpdateArgs<ExtArgs>>
    ): Prisma__CollateralTypeClient<$Types.GetResult<CollateralTypePayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more CollateralTypes.
     * @param {CollateralTypeDeleteManyArgs} args - Arguments to filter CollateralTypes to delete.
     * @example
     * // Delete a few CollateralTypes
     * const { count } = await prisma.collateralType.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends CollateralTypeDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, CollateralTypeDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more CollateralTypes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CollateralTypeUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many CollateralTypes
     * const collateralType = await prisma.collateralType.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends CollateralTypeUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, CollateralTypeUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one CollateralType.
     * @param {CollateralTypeUpsertArgs} args - Arguments to update or create a CollateralType.
     * @example
     * // Update or create a CollateralType
     * const collateralType = await prisma.collateralType.upsert({
     *   create: {
     *     // ... data to create a CollateralType
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the CollateralType we want to update
     *   }
     * })
    **/
    upsert<T extends CollateralTypeUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, CollateralTypeUpsertArgs<ExtArgs>>
    ): Prisma__CollateralTypeClient<$Types.GetResult<CollateralTypePayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of CollateralTypes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CollateralTypeCountArgs} args - Arguments to filter CollateralTypes to count.
     * @example
     * // Count the number of CollateralTypes
     * const count = await prisma.collateralType.count({
     *   where: {
     *     // ... the filter for the CollateralTypes we want to count
     *   }
     * })
    **/
    count<T extends CollateralTypeCountArgs>(
      args?: Subset<T, CollateralTypeCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CollateralTypeCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a CollateralType.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CollateralTypeAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CollateralTypeAggregateArgs>(args: Subset<T, CollateralTypeAggregateArgs>): Prisma.PrismaPromise<GetCollateralTypeAggregateType<T>>

    /**
     * Group by CollateralType.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CollateralTypeGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends CollateralTypeGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: CollateralTypeGroupByArgs['orderBy'] }
        : { orderBy?: CollateralTypeGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, CollateralTypeGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCollateralTypeGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for CollateralType.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__CollateralTypeClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * CollateralType base type for findUnique actions
   */
  export type CollateralTypeFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CollateralType
     */
    select?: CollateralTypeSelect<ExtArgs> | null
    /**
     * Filter, which CollateralType to fetch.
     */
    where: CollateralTypeWhereUniqueInput
  }

  /**
   * CollateralType findUnique
   */
  export interface CollateralTypeFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends CollateralTypeFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * CollateralType findUniqueOrThrow
   */
  export type CollateralTypeFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CollateralType
     */
    select?: CollateralTypeSelect<ExtArgs> | null
    /**
     * Filter, which CollateralType to fetch.
     */
    where: CollateralTypeWhereUniqueInput
  }


  /**
   * CollateralType base type for findFirst actions
   */
  export type CollateralTypeFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CollateralType
     */
    select?: CollateralTypeSelect<ExtArgs> | null
    /**
     * Filter, which CollateralType to fetch.
     */
    where?: CollateralTypeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CollateralTypes to fetch.
     */
    orderBy?: Enumerable<CollateralTypeOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for CollateralTypes.
     */
    cursor?: CollateralTypeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CollateralTypes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CollateralTypes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CollateralTypes.
     */
    distinct?: Enumerable<CollateralTypeScalarFieldEnum>
  }

  /**
   * CollateralType findFirst
   */
  export interface CollateralTypeFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends CollateralTypeFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * CollateralType findFirstOrThrow
   */
  export type CollateralTypeFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CollateralType
     */
    select?: CollateralTypeSelect<ExtArgs> | null
    /**
     * Filter, which CollateralType to fetch.
     */
    where?: CollateralTypeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CollateralTypes to fetch.
     */
    orderBy?: Enumerable<CollateralTypeOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for CollateralTypes.
     */
    cursor?: CollateralTypeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CollateralTypes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CollateralTypes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CollateralTypes.
     */
    distinct?: Enumerable<CollateralTypeScalarFieldEnum>
  }


  /**
   * CollateralType findMany
   */
  export type CollateralTypeFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CollateralType
     */
    select?: CollateralTypeSelect<ExtArgs> | null
    /**
     * Filter, which CollateralTypes to fetch.
     */
    where?: CollateralTypeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CollateralTypes to fetch.
     */
    orderBy?: Enumerable<CollateralTypeOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing CollateralTypes.
     */
    cursor?: CollateralTypeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CollateralTypes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CollateralTypes.
     */
    skip?: number
    distinct?: Enumerable<CollateralTypeScalarFieldEnum>
  }


  /**
   * CollateralType create
   */
  export type CollateralTypeCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CollateralType
     */
    select?: CollateralTypeSelect<ExtArgs> | null
    /**
     * The data needed to create a CollateralType.
     */
    data: XOR<CollateralTypeCreateInput, CollateralTypeUncheckedCreateInput>
  }


  /**
   * CollateralType createMany
   */
  export type CollateralTypeCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many CollateralTypes.
     */
    data: Enumerable<CollateralTypeCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * CollateralType update
   */
  export type CollateralTypeUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CollateralType
     */
    select?: CollateralTypeSelect<ExtArgs> | null
    /**
     * The data needed to update a CollateralType.
     */
    data: XOR<CollateralTypeUpdateInput, CollateralTypeUncheckedUpdateInput>
    /**
     * Choose, which CollateralType to update.
     */
    where: CollateralTypeWhereUniqueInput
  }


  /**
   * CollateralType updateMany
   */
  export type CollateralTypeUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update CollateralTypes.
     */
    data: XOR<CollateralTypeUpdateManyMutationInput, CollateralTypeUncheckedUpdateManyInput>
    /**
     * Filter which CollateralTypes to update
     */
    where?: CollateralTypeWhereInput
  }


  /**
   * CollateralType upsert
   */
  export type CollateralTypeUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CollateralType
     */
    select?: CollateralTypeSelect<ExtArgs> | null
    /**
     * The filter to search for the CollateralType to update in case it exists.
     */
    where: CollateralTypeWhereUniqueInput
    /**
     * In case the CollateralType found by the `where` argument doesn't exist, create a new CollateralType with this data.
     */
    create: XOR<CollateralTypeCreateInput, CollateralTypeUncheckedCreateInput>
    /**
     * In case the CollateralType was found with the provided `where` argument, update it with this data.
     */
    update: XOR<CollateralTypeUpdateInput, CollateralTypeUncheckedUpdateInput>
  }


  /**
   * CollateralType delete
   */
  export type CollateralTypeDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CollateralType
     */
    select?: CollateralTypeSelect<ExtArgs> | null
    /**
     * Filter which CollateralType to delete.
     */
    where: CollateralTypeWhereUniqueInput
  }


  /**
   * CollateralType deleteMany
   */
  export type CollateralTypeDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which CollateralTypes to delete
     */
    where?: CollateralTypeWhereInput
  }


  /**
   * CollateralType without action
   */
  export type CollateralTypeArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CollateralType
     */
    select?: CollateralTypeSelect<ExtArgs> | null
  }



  /**
   * Model Discover
   */


  export type AggregateDiscover = {
    _count: DiscoverCountAggregateOutputType | null
    _avg: DiscoverAvgAggregateOutputType | null
    _sum: DiscoverSumAggregateOutputType | null
    _min: DiscoverMinAggregateOutputType | null
    _max: DiscoverMaxAggregateOutputType | null
  }

  export type DiscoverAvgAggregateOutputType = {
    vault_debt: Decimal | null
    vault_normalized_debt: Decimal | null
    vault_collateral: Decimal | null
    yield_30d: Decimal | null
    pnl_all: Decimal | null
    pnl_1d: Decimal | null
    pnl_7d: Decimal | null
    pnl_30d: Decimal | null
    pnl_365d: Decimal | null
    pnl_ytd: Decimal | null
    net_profit_all: Decimal | null
    net_profit_1d: Decimal | null
    net_profit_7d: Decimal | null
    net_profit_30d: Decimal | null
    net_profit_365d: Decimal | null
    net_profit_ytd: Decimal | null
  }

  export type DiscoverSumAggregateOutputType = {
    vault_debt: Decimal | null
    vault_normalized_debt: Decimal | null
    vault_collateral: Decimal | null
    yield_30d: Decimal | null
    pnl_all: Decimal | null
    pnl_1d: Decimal | null
    pnl_7d: Decimal | null
    pnl_30d: Decimal | null
    pnl_365d: Decimal | null
    pnl_ytd: Decimal | null
    net_profit_all: Decimal | null
    net_profit_1d: Decimal | null
    net_profit_7d: Decimal | null
    net_profit_30d: Decimal | null
    net_profit_365d: Decimal | null
    net_profit_ytd: Decimal | null
  }

  export type DiscoverMinAggregateOutputType = {
    protocol_id: string | null
    position_id: string | null
    collateral_type: string | null
    vault_debt: Decimal | null
    vault_normalized_debt: Decimal | null
    vault_collateral: Decimal | null
    yield_30d: Decimal | null
    pnl_all: Decimal | null
    pnl_1d: Decimal | null
    pnl_7d: Decimal | null
    pnl_30d: Decimal | null
    pnl_365d: Decimal | null
    pnl_ytd: Decimal | null
    net_profit_all: Decimal | null
    net_profit_1d: Decimal | null
    net_profit_7d: Decimal | null
    net_profit_30d: Decimal | null
    net_profit_365d: Decimal | null
    net_profit_ytd: Decimal | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type DiscoverMaxAggregateOutputType = {
    protocol_id: string | null
    position_id: string | null
    collateral_type: string | null
    vault_debt: Decimal | null
    vault_normalized_debt: Decimal | null
    vault_collateral: Decimal | null
    yield_30d: Decimal | null
    pnl_all: Decimal | null
    pnl_1d: Decimal | null
    pnl_7d: Decimal | null
    pnl_30d: Decimal | null
    pnl_365d: Decimal | null
    pnl_ytd: Decimal | null
    net_profit_all: Decimal | null
    net_profit_1d: Decimal | null
    net_profit_7d: Decimal | null
    net_profit_30d: Decimal | null
    net_profit_365d: Decimal | null
    net_profit_ytd: Decimal | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type DiscoverCountAggregateOutputType = {
    protocol_id: number
    position_id: number
    collateral_type: number
    vault_debt: number
    vault_normalized_debt: number
    vault_collateral: number
    yield_30d: number
    status: number
    last_action: number
    pnl_all: number
    pnl_1d: number
    pnl_7d: number
    pnl_30d: number
    pnl_365d: number
    pnl_ytd: number
    net_profit_all: number
    net_profit_1d: number
    net_profit_7d: number
    net_profit_30d: number
    net_profit_365d: number
    net_profit_ytd: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type DiscoverAvgAggregateInputType = {
    vault_debt?: true
    vault_normalized_debt?: true
    vault_collateral?: true
    yield_30d?: true
    pnl_all?: true
    pnl_1d?: true
    pnl_7d?: true
    pnl_30d?: true
    pnl_365d?: true
    pnl_ytd?: true
    net_profit_all?: true
    net_profit_1d?: true
    net_profit_7d?: true
    net_profit_30d?: true
    net_profit_365d?: true
    net_profit_ytd?: true
  }

  export type DiscoverSumAggregateInputType = {
    vault_debt?: true
    vault_normalized_debt?: true
    vault_collateral?: true
    yield_30d?: true
    pnl_all?: true
    pnl_1d?: true
    pnl_7d?: true
    pnl_30d?: true
    pnl_365d?: true
    pnl_ytd?: true
    net_profit_all?: true
    net_profit_1d?: true
    net_profit_7d?: true
    net_profit_30d?: true
    net_profit_365d?: true
    net_profit_ytd?: true
  }

  export type DiscoverMinAggregateInputType = {
    protocol_id?: true
    position_id?: true
    collateral_type?: true
    vault_debt?: true
    vault_normalized_debt?: true
    vault_collateral?: true
    yield_30d?: true
    pnl_all?: true
    pnl_1d?: true
    pnl_7d?: true
    pnl_30d?: true
    pnl_365d?: true
    pnl_ytd?: true
    net_profit_all?: true
    net_profit_1d?: true
    net_profit_7d?: true
    net_profit_30d?: true
    net_profit_365d?: true
    net_profit_ytd?: true
    createdAt?: true
    updatedAt?: true
  }

  export type DiscoverMaxAggregateInputType = {
    protocol_id?: true
    position_id?: true
    collateral_type?: true
    vault_debt?: true
    vault_normalized_debt?: true
    vault_collateral?: true
    yield_30d?: true
    pnl_all?: true
    pnl_1d?: true
    pnl_7d?: true
    pnl_30d?: true
    pnl_365d?: true
    pnl_ytd?: true
    net_profit_all?: true
    net_profit_1d?: true
    net_profit_7d?: true
    net_profit_30d?: true
    net_profit_365d?: true
    net_profit_ytd?: true
    createdAt?: true
    updatedAt?: true
  }

  export type DiscoverCountAggregateInputType = {
    protocol_id?: true
    position_id?: true
    collateral_type?: true
    vault_debt?: true
    vault_normalized_debt?: true
    vault_collateral?: true
    yield_30d?: true
    status?: true
    last_action?: true
    pnl_all?: true
    pnl_1d?: true
    pnl_7d?: true
    pnl_30d?: true
    pnl_365d?: true
    pnl_ytd?: true
    net_profit_all?: true
    net_profit_1d?: true
    net_profit_7d?: true
    net_profit_30d?: true
    net_profit_365d?: true
    net_profit_ytd?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type DiscoverAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which Discover to aggregate.
     */
    where?: DiscoverWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Discovers to fetch.
     */
    orderBy?: Enumerable<DiscoverOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: DiscoverWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Discovers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Discovers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Discovers
    **/
    _count?: true | DiscoverCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: DiscoverAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: DiscoverSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: DiscoverMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: DiscoverMaxAggregateInputType
  }

  export type GetDiscoverAggregateType<T extends DiscoverAggregateArgs> = {
        [P in keyof T & keyof AggregateDiscover]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateDiscover[P]>
      : GetScalarType<T[P], AggregateDiscover[P]>
  }




  export type DiscoverGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: DiscoverWhereInput
    orderBy?: Enumerable<DiscoverOrderByWithAggregationInput>
    by: DiscoverScalarFieldEnum[]
    having?: DiscoverScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: DiscoverCountAggregateInputType | true
    _avg?: DiscoverAvgAggregateInputType
    _sum?: DiscoverSumAggregateInputType
    _min?: DiscoverMinAggregateInputType
    _max?: DiscoverMaxAggregateInputType
  }


  export type DiscoverGroupByOutputType = {
    protocol_id: string
    position_id: string
    collateral_type: string
    vault_debt: Decimal
    vault_normalized_debt: Decimal | null
    vault_collateral: Decimal
    yield_30d: Decimal
    status: JsonValue
    last_action: JsonValue
    pnl_all: Decimal
    pnl_1d: Decimal
    pnl_7d: Decimal
    pnl_30d: Decimal
    pnl_365d: Decimal
    pnl_ytd: Decimal
    net_profit_all: Decimal
    net_profit_1d: Decimal
    net_profit_7d: Decimal
    net_profit_30d: Decimal
    net_profit_365d: Decimal
    net_profit_ytd: Decimal
    createdAt: Date
    updatedAt: Date
    _count: DiscoverCountAggregateOutputType | null
    _avg: DiscoverAvgAggregateOutputType | null
    _sum: DiscoverSumAggregateOutputType | null
    _min: DiscoverMinAggregateOutputType | null
    _max: DiscoverMaxAggregateOutputType | null
  }

  type GetDiscoverGroupByPayload<T extends DiscoverGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<DiscoverGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof DiscoverGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], DiscoverGroupByOutputType[P]>
            : GetScalarType<T[P], DiscoverGroupByOutputType[P]>
        }
      >
    >


  export type DiscoverSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    protocol_id?: boolean
    position_id?: boolean
    collateral_type?: boolean
    vault_debt?: boolean
    vault_normalized_debt?: boolean
    vault_collateral?: boolean
    yield_30d?: boolean
    status?: boolean
    last_action?: boolean
    pnl_all?: boolean
    pnl_1d?: boolean
    pnl_7d?: boolean
    pnl_30d?: boolean
    pnl_365d?: boolean
    pnl_ytd?: boolean
    net_profit_all?: boolean
    net_profit_1d?: boolean
    net_profit_7d?: boolean
    net_profit_30d?: boolean
    net_profit_365d?: boolean
    net_profit_ytd?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["discover"]>

  export type DiscoverSelectScalar = {
    protocol_id?: boolean
    position_id?: boolean
    collateral_type?: boolean
    vault_debt?: boolean
    vault_normalized_debt?: boolean
    vault_collateral?: boolean
    yield_30d?: boolean
    status?: boolean
    last_action?: boolean
    pnl_all?: boolean
    pnl_1d?: boolean
    pnl_7d?: boolean
    pnl_30d?: boolean
    pnl_365d?: boolean
    pnl_ytd?: boolean
    net_profit_all?: boolean
    net_profit_1d?: boolean
    net_profit_7d?: boolean
    net_profit_30d?: boolean
    net_profit_365d?: boolean
    net_profit_ytd?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }


  type DiscoverGetPayload<S extends boolean | null | undefined | DiscoverArgs> = $Types.GetResult<DiscoverPayload, S>

  type DiscoverCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<DiscoverFindManyArgs, 'select' | 'include'> & {
      select?: DiscoverCountAggregateInputType | true
    }

  export interface DiscoverDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Discover'], meta: { name: 'Discover' } }
    /**
     * Find zero or one Discover that matches the filter.
     * @param {DiscoverFindUniqueArgs} args - Arguments to find a Discover
     * @example
     * // Get one Discover
     * const discover = await prisma.discover.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends DiscoverFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, DiscoverFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'Discover'> extends True ? Prisma__DiscoverClient<$Types.GetResult<DiscoverPayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__DiscoverClient<$Types.GetResult<DiscoverPayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one Discover that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {DiscoverFindUniqueOrThrowArgs} args - Arguments to find a Discover
     * @example
     * // Get one Discover
     * const discover = await prisma.discover.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends DiscoverFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, DiscoverFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__DiscoverClient<$Types.GetResult<DiscoverPayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first Discover that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DiscoverFindFirstArgs} args - Arguments to find a Discover
     * @example
     * // Get one Discover
     * const discover = await prisma.discover.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends DiscoverFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, DiscoverFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'Discover'> extends True ? Prisma__DiscoverClient<$Types.GetResult<DiscoverPayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__DiscoverClient<$Types.GetResult<DiscoverPayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first Discover that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DiscoverFindFirstOrThrowArgs} args - Arguments to find a Discover
     * @example
     * // Get one Discover
     * const discover = await prisma.discover.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends DiscoverFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, DiscoverFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__DiscoverClient<$Types.GetResult<DiscoverPayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more Discovers that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DiscoverFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Discovers
     * const discovers = await prisma.discover.findMany()
     * 
     * // Get first 10 Discovers
     * const discovers = await prisma.discover.findMany({ take: 10 })
     * 
     * // Only select the `protocol_id`
     * const discoverWithProtocol_idOnly = await prisma.discover.findMany({ select: { protocol_id: true } })
     * 
    **/
    findMany<T extends DiscoverFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, DiscoverFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<DiscoverPayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a Discover.
     * @param {DiscoverCreateArgs} args - Arguments to create a Discover.
     * @example
     * // Create one Discover
     * const Discover = await prisma.discover.create({
     *   data: {
     *     // ... data to create a Discover
     *   }
     * })
     * 
    **/
    create<T extends DiscoverCreateArgs<ExtArgs>>(
      args: SelectSubset<T, DiscoverCreateArgs<ExtArgs>>
    ): Prisma__DiscoverClient<$Types.GetResult<DiscoverPayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many Discovers.
     *     @param {DiscoverCreateManyArgs} args - Arguments to create many Discovers.
     *     @example
     *     // Create many Discovers
     *     const discover = await prisma.discover.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends DiscoverCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, DiscoverCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Discover.
     * @param {DiscoverDeleteArgs} args - Arguments to delete one Discover.
     * @example
     * // Delete one Discover
     * const Discover = await prisma.discover.delete({
     *   where: {
     *     // ... filter to delete one Discover
     *   }
     * })
     * 
    **/
    delete<T extends DiscoverDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, DiscoverDeleteArgs<ExtArgs>>
    ): Prisma__DiscoverClient<$Types.GetResult<DiscoverPayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one Discover.
     * @param {DiscoverUpdateArgs} args - Arguments to update one Discover.
     * @example
     * // Update one Discover
     * const discover = await prisma.discover.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends DiscoverUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, DiscoverUpdateArgs<ExtArgs>>
    ): Prisma__DiscoverClient<$Types.GetResult<DiscoverPayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more Discovers.
     * @param {DiscoverDeleteManyArgs} args - Arguments to filter Discovers to delete.
     * @example
     * // Delete a few Discovers
     * const { count } = await prisma.discover.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends DiscoverDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, DiscoverDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Discovers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DiscoverUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Discovers
     * const discover = await prisma.discover.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends DiscoverUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, DiscoverUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Discover.
     * @param {DiscoverUpsertArgs} args - Arguments to update or create a Discover.
     * @example
     * // Update or create a Discover
     * const discover = await prisma.discover.upsert({
     *   create: {
     *     // ... data to create a Discover
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Discover we want to update
     *   }
     * })
    **/
    upsert<T extends DiscoverUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, DiscoverUpsertArgs<ExtArgs>>
    ): Prisma__DiscoverClient<$Types.GetResult<DiscoverPayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of Discovers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DiscoverCountArgs} args - Arguments to filter Discovers to count.
     * @example
     * // Count the number of Discovers
     * const count = await prisma.discover.count({
     *   where: {
     *     // ... the filter for the Discovers we want to count
     *   }
     * })
    **/
    count<T extends DiscoverCountArgs>(
      args?: Subset<T, DiscoverCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], DiscoverCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Discover.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DiscoverAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends DiscoverAggregateArgs>(args: Subset<T, DiscoverAggregateArgs>): Prisma.PrismaPromise<GetDiscoverAggregateType<T>>

    /**
     * Group by Discover.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DiscoverGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends DiscoverGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: DiscoverGroupByArgs['orderBy'] }
        : { orderBy?: DiscoverGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, DiscoverGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetDiscoverGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for Discover.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__DiscoverClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * Discover base type for findUnique actions
   */
  export type DiscoverFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Discover
     */
    select?: DiscoverSelect<ExtArgs> | null
    /**
     * Filter, which Discover to fetch.
     */
    where: DiscoverWhereUniqueInput
  }

  /**
   * Discover findUnique
   */
  export interface DiscoverFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends DiscoverFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * Discover findUniqueOrThrow
   */
  export type DiscoverFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Discover
     */
    select?: DiscoverSelect<ExtArgs> | null
    /**
     * Filter, which Discover to fetch.
     */
    where: DiscoverWhereUniqueInput
  }


  /**
   * Discover base type for findFirst actions
   */
  export type DiscoverFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Discover
     */
    select?: DiscoverSelect<ExtArgs> | null
    /**
     * Filter, which Discover to fetch.
     */
    where?: DiscoverWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Discovers to fetch.
     */
    orderBy?: Enumerable<DiscoverOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Discovers.
     */
    cursor?: DiscoverWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Discovers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Discovers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Discovers.
     */
    distinct?: Enumerable<DiscoverScalarFieldEnum>
  }

  /**
   * Discover findFirst
   */
  export interface DiscoverFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends DiscoverFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * Discover findFirstOrThrow
   */
  export type DiscoverFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Discover
     */
    select?: DiscoverSelect<ExtArgs> | null
    /**
     * Filter, which Discover to fetch.
     */
    where?: DiscoverWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Discovers to fetch.
     */
    orderBy?: Enumerable<DiscoverOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Discovers.
     */
    cursor?: DiscoverWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Discovers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Discovers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Discovers.
     */
    distinct?: Enumerable<DiscoverScalarFieldEnum>
  }


  /**
   * Discover findMany
   */
  export type DiscoverFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Discover
     */
    select?: DiscoverSelect<ExtArgs> | null
    /**
     * Filter, which Discovers to fetch.
     */
    where?: DiscoverWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Discovers to fetch.
     */
    orderBy?: Enumerable<DiscoverOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Discovers.
     */
    cursor?: DiscoverWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Discovers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Discovers.
     */
    skip?: number
    distinct?: Enumerable<DiscoverScalarFieldEnum>
  }


  /**
   * Discover create
   */
  export type DiscoverCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Discover
     */
    select?: DiscoverSelect<ExtArgs> | null
    /**
     * The data needed to create a Discover.
     */
    data: XOR<DiscoverCreateInput, DiscoverUncheckedCreateInput>
  }


  /**
   * Discover createMany
   */
  export type DiscoverCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Discovers.
     */
    data: Enumerable<DiscoverCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * Discover update
   */
  export type DiscoverUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Discover
     */
    select?: DiscoverSelect<ExtArgs> | null
    /**
     * The data needed to update a Discover.
     */
    data: XOR<DiscoverUpdateInput, DiscoverUncheckedUpdateInput>
    /**
     * Choose, which Discover to update.
     */
    where: DiscoverWhereUniqueInput
  }


  /**
   * Discover updateMany
   */
  export type DiscoverUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Discovers.
     */
    data: XOR<DiscoverUpdateManyMutationInput, DiscoverUncheckedUpdateManyInput>
    /**
     * Filter which Discovers to update
     */
    where?: DiscoverWhereInput
  }


  /**
   * Discover upsert
   */
  export type DiscoverUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Discover
     */
    select?: DiscoverSelect<ExtArgs> | null
    /**
     * The filter to search for the Discover to update in case it exists.
     */
    where: DiscoverWhereUniqueInput
    /**
     * In case the Discover found by the `where` argument doesn't exist, create a new Discover with this data.
     */
    create: XOR<DiscoverCreateInput, DiscoverUncheckedCreateInput>
    /**
     * In case the Discover was found with the provided `where` argument, update it with this data.
     */
    update: XOR<DiscoverUpdateInput, DiscoverUncheckedUpdateInput>
  }


  /**
   * Discover delete
   */
  export type DiscoverDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Discover
     */
    select?: DiscoverSelect<ExtArgs> | null
    /**
     * Filter which Discover to delete.
     */
    where: DiscoverWhereUniqueInput
  }


  /**
   * Discover deleteMany
   */
  export type DiscoverDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which Discovers to delete
     */
    where?: DiscoverWhereInput
  }


  /**
   * Discover without action
   */
  export type DiscoverArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Discover
     */
    select?: DiscoverSelect<ExtArgs> | null
  }



  /**
   * Model HighestRiskPositions
   */


  export type AggregateHighestRiskPositions = {
    _count: HighestRiskPositionsCountAggregateOutputType | null
    _avg: HighestRiskPositionsAvgAggregateOutputType | null
    _sum: HighestRiskPositionsSumAggregateOutputType | null
    _min: HighestRiskPositionsMinAggregateOutputType | null
    _max: HighestRiskPositionsMaxAggregateOutputType | null
  }

  export type HighestRiskPositionsAvgAggregateOutputType = {
    collateral_ratio: Decimal | null
    collateral_value: Decimal | null
    liquidation_proximity: Decimal | null
    liquidation_price: Decimal | null
    liquidation_value: Decimal | null
    next_price: Decimal | null
  }

  export type HighestRiskPositionsSumAggregateOutputType = {
    collateral_ratio: Decimal | null
    collateral_value: Decimal | null
    liquidation_proximity: Decimal | null
    liquidation_price: Decimal | null
    liquidation_value: Decimal | null
    next_price: Decimal | null
  }

  export type HighestRiskPositionsMinAggregateOutputType = {
    protocol_id: string | null
    position_id: string | null
    collateral_type: string | null
    token: string | null
    collateral_ratio: Decimal | null
    collateral_value: Decimal | null
    liquidation_proximity: Decimal | null
    liquidation_price: Decimal | null
    liquidation_value: Decimal | null
    next_price: Decimal | null
    type: VaultType | null
  }

  export type HighestRiskPositionsMaxAggregateOutputType = {
    protocol_id: string | null
    position_id: string | null
    collateral_type: string | null
    token: string | null
    collateral_ratio: Decimal | null
    collateral_value: Decimal | null
    liquidation_proximity: Decimal | null
    liquidation_price: Decimal | null
    liquidation_value: Decimal | null
    next_price: Decimal | null
    type: VaultType | null
  }

  export type HighestRiskPositionsCountAggregateOutputType = {
    protocol_id: number
    position_id: number
    collateral_type: number
    token: number
    collateral_ratio: number
    collateral_value: number
    liquidation_proximity: number
    liquidation_price: number
    liquidation_value: number
    next_price: number
    status: number
    type: number
    _all: number
  }


  export type HighestRiskPositionsAvgAggregateInputType = {
    collateral_ratio?: true
    collateral_value?: true
    liquidation_proximity?: true
    liquidation_price?: true
    liquidation_value?: true
    next_price?: true
  }

  export type HighestRiskPositionsSumAggregateInputType = {
    collateral_ratio?: true
    collateral_value?: true
    liquidation_proximity?: true
    liquidation_price?: true
    liquidation_value?: true
    next_price?: true
  }

  export type HighestRiskPositionsMinAggregateInputType = {
    protocol_id?: true
    position_id?: true
    collateral_type?: true
    token?: true
    collateral_ratio?: true
    collateral_value?: true
    liquidation_proximity?: true
    liquidation_price?: true
    liquidation_value?: true
    next_price?: true
    type?: true
  }

  export type HighestRiskPositionsMaxAggregateInputType = {
    protocol_id?: true
    position_id?: true
    collateral_type?: true
    token?: true
    collateral_ratio?: true
    collateral_value?: true
    liquidation_proximity?: true
    liquidation_price?: true
    liquidation_value?: true
    next_price?: true
    type?: true
  }

  export type HighestRiskPositionsCountAggregateInputType = {
    protocol_id?: true
    position_id?: true
    collateral_type?: true
    token?: true
    collateral_ratio?: true
    collateral_value?: true
    liquidation_proximity?: true
    liquidation_price?: true
    liquidation_value?: true
    next_price?: true
    status?: true
    type?: true
    _all?: true
  }

  export type HighestRiskPositionsAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which HighestRiskPositions to aggregate.
     */
    where?: HighestRiskPositionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of HighestRiskPositions to fetch.
     */
    orderBy?: Enumerable<HighestRiskPositionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: HighestRiskPositionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` HighestRiskPositions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` HighestRiskPositions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned HighestRiskPositions
    **/
    _count?: true | HighestRiskPositionsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: HighestRiskPositionsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: HighestRiskPositionsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: HighestRiskPositionsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: HighestRiskPositionsMaxAggregateInputType
  }

  export type GetHighestRiskPositionsAggregateType<T extends HighestRiskPositionsAggregateArgs> = {
        [P in keyof T & keyof AggregateHighestRiskPositions]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateHighestRiskPositions[P]>
      : GetScalarType<T[P], AggregateHighestRiskPositions[P]>
  }




  export type HighestRiskPositionsGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: HighestRiskPositionsWhereInput
    orderBy?: Enumerable<HighestRiskPositionsOrderByWithAggregationInput>
    by: HighestRiskPositionsScalarFieldEnum[]
    having?: HighestRiskPositionsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: HighestRiskPositionsCountAggregateInputType | true
    _avg?: HighestRiskPositionsAvgAggregateInputType
    _sum?: HighestRiskPositionsSumAggregateInputType
    _min?: HighestRiskPositionsMinAggregateInputType
    _max?: HighestRiskPositionsMaxAggregateInputType
  }


  export type HighestRiskPositionsGroupByOutputType = {
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_ratio: Decimal
    collateral_value: Decimal
    liquidation_proximity: Decimal
    liquidation_price: Decimal
    liquidation_value: Decimal
    next_price: Decimal
    status: JsonValue
    type: VaultType | null
    _count: HighestRiskPositionsCountAggregateOutputType | null
    _avg: HighestRiskPositionsAvgAggregateOutputType | null
    _sum: HighestRiskPositionsSumAggregateOutputType | null
    _min: HighestRiskPositionsMinAggregateOutputType | null
    _max: HighestRiskPositionsMaxAggregateOutputType | null
  }

  type GetHighestRiskPositionsGroupByPayload<T extends HighestRiskPositionsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<HighestRiskPositionsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof HighestRiskPositionsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], HighestRiskPositionsGroupByOutputType[P]>
            : GetScalarType<T[P], HighestRiskPositionsGroupByOutputType[P]>
        }
      >
    >


  export type HighestRiskPositionsSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    protocol_id?: boolean
    position_id?: boolean
    collateral_type?: boolean
    token?: boolean
    collateral_ratio?: boolean
    collateral_value?: boolean
    liquidation_proximity?: boolean
    liquidation_price?: boolean
    liquidation_value?: boolean
    next_price?: boolean
    status?: boolean
    type?: boolean
  }, ExtArgs["result"]["highestRiskPositions"]>

  export type HighestRiskPositionsSelectScalar = {
    protocol_id?: boolean
    position_id?: boolean
    collateral_type?: boolean
    token?: boolean
    collateral_ratio?: boolean
    collateral_value?: boolean
    liquidation_proximity?: boolean
    liquidation_price?: boolean
    liquidation_value?: boolean
    next_price?: boolean
    status?: boolean
    type?: boolean
  }


  type HighestRiskPositionsGetPayload<S extends boolean | null | undefined | HighestRiskPositionsArgs> = $Types.GetResult<HighestRiskPositionsPayload, S>

  type HighestRiskPositionsCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<HighestRiskPositionsFindManyArgs, 'select' | 'include'> & {
      select?: HighestRiskPositionsCountAggregateInputType | true
    }

  export interface HighestRiskPositionsDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['HighestRiskPositions'], meta: { name: 'HighestRiskPositions' } }
    /**
     * Find zero or one HighestRiskPositions that matches the filter.
     * @param {HighestRiskPositionsFindUniqueArgs} args - Arguments to find a HighestRiskPositions
     * @example
     * // Get one HighestRiskPositions
     * const highestRiskPositions = await prisma.highestRiskPositions.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends HighestRiskPositionsFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, HighestRiskPositionsFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'HighestRiskPositions'> extends True ? Prisma__HighestRiskPositionsClient<$Types.GetResult<HighestRiskPositionsPayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__HighestRiskPositionsClient<$Types.GetResult<HighestRiskPositionsPayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one HighestRiskPositions that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {HighestRiskPositionsFindUniqueOrThrowArgs} args - Arguments to find a HighestRiskPositions
     * @example
     * // Get one HighestRiskPositions
     * const highestRiskPositions = await prisma.highestRiskPositions.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends HighestRiskPositionsFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, HighestRiskPositionsFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__HighestRiskPositionsClient<$Types.GetResult<HighestRiskPositionsPayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first HighestRiskPositions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HighestRiskPositionsFindFirstArgs} args - Arguments to find a HighestRiskPositions
     * @example
     * // Get one HighestRiskPositions
     * const highestRiskPositions = await prisma.highestRiskPositions.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends HighestRiskPositionsFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, HighestRiskPositionsFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'HighestRiskPositions'> extends True ? Prisma__HighestRiskPositionsClient<$Types.GetResult<HighestRiskPositionsPayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__HighestRiskPositionsClient<$Types.GetResult<HighestRiskPositionsPayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first HighestRiskPositions that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HighestRiskPositionsFindFirstOrThrowArgs} args - Arguments to find a HighestRiskPositions
     * @example
     * // Get one HighestRiskPositions
     * const highestRiskPositions = await prisma.highestRiskPositions.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends HighestRiskPositionsFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, HighestRiskPositionsFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__HighestRiskPositionsClient<$Types.GetResult<HighestRiskPositionsPayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more HighestRiskPositions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HighestRiskPositionsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all HighestRiskPositions
     * const highestRiskPositions = await prisma.highestRiskPositions.findMany()
     * 
     * // Get first 10 HighestRiskPositions
     * const highestRiskPositions = await prisma.highestRiskPositions.findMany({ take: 10 })
     * 
     * // Only select the `protocol_id`
     * const highestRiskPositionsWithProtocol_idOnly = await prisma.highestRiskPositions.findMany({ select: { protocol_id: true } })
     * 
    **/
    findMany<T extends HighestRiskPositionsFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, HighestRiskPositionsFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<HighestRiskPositionsPayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a HighestRiskPositions.
     * @param {HighestRiskPositionsCreateArgs} args - Arguments to create a HighestRiskPositions.
     * @example
     * // Create one HighestRiskPositions
     * const HighestRiskPositions = await prisma.highestRiskPositions.create({
     *   data: {
     *     // ... data to create a HighestRiskPositions
     *   }
     * })
     * 
    **/
    create<T extends HighestRiskPositionsCreateArgs<ExtArgs>>(
      args: SelectSubset<T, HighestRiskPositionsCreateArgs<ExtArgs>>
    ): Prisma__HighestRiskPositionsClient<$Types.GetResult<HighestRiskPositionsPayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many HighestRiskPositions.
     *     @param {HighestRiskPositionsCreateManyArgs} args - Arguments to create many HighestRiskPositions.
     *     @example
     *     // Create many HighestRiskPositions
     *     const highestRiskPositions = await prisma.highestRiskPositions.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends HighestRiskPositionsCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, HighestRiskPositionsCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a HighestRiskPositions.
     * @param {HighestRiskPositionsDeleteArgs} args - Arguments to delete one HighestRiskPositions.
     * @example
     * // Delete one HighestRiskPositions
     * const HighestRiskPositions = await prisma.highestRiskPositions.delete({
     *   where: {
     *     // ... filter to delete one HighestRiskPositions
     *   }
     * })
     * 
    **/
    delete<T extends HighestRiskPositionsDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, HighestRiskPositionsDeleteArgs<ExtArgs>>
    ): Prisma__HighestRiskPositionsClient<$Types.GetResult<HighestRiskPositionsPayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one HighestRiskPositions.
     * @param {HighestRiskPositionsUpdateArgs} args - Arguments to update one HighestRiskPositions.
     * @example
     * // Update one HighestRiskPositions
     * const highestRiskPositions = await prisma.highestRiskPositions.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends HighestRiskPositionsUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, HighestRiskPositionsUpdateArgs<ExtArgs>>
    ): Prisma__HighestRiskPositionsClient<$Types.GetResult<HighestRiskPositionsPayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more HighestRiskPositions.
     * @param {HighestRiskPositionsDeleteManyArgs} args - Arguments to filter HighestRiskPositions to delete.
     * @example
     * // Delete a few HighestRiskPositions
     * const { count } = await prisma.highestRiskPositions.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends HighestRiskPositionsDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, HighestRiskPositionsDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more HighestRiskPositions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HighestRiskPositionsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many HighestRiskPositions
     * const highestRiskPositions = await prisma.highestRiskPositions.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends HighestRiskPositionsUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, HighestRiskPositionsUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one HighestRiskPositions.
     * @param {HighestRiskPositionsUpsertArgs} args - Arguments to update or create a HighestRiskPositions.
     * @example
     * // Update or create a HighestRiskPositions
     * const highestRiskPositions = await prisma.highestRiskPositions.upsert({
     *   create: {
     *     // ... data to create a HighestRiskPositions
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the HighestRiskPositions we want to update
     *   }
     * })
    **/
    upsert<T extends HighestRiskPositionsUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, HighestRiskPositionsUpsertArgs<ExtArgs>>
    ): Prisma__HighestRiskPositionsClient<$Types.GetResult<HighestRiskPositionsPayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of HighestRiskPositions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HighestRiskPositionsCountArgs} args - Arguments to filter HighestRiskPositions to count.
     * @example
     * // Count the number of HighestRiskPositions
     * const count = await prisma.highestRiskPositions.count({
     *   where: {
     *     // ... the filter for the HighestRiskPositions we want to count
     *   }
     * })
    **/
    count<T extends HighestRiskPositionsCountArgs>(
      args?: Subset<T, HighestRiskPositionsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], HighestRiskPositionsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a HighestRiskPositions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HighestRiskPositionsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends HighestRiskPositionsAggregateArgs>(args: Subset<T, HighestRiskPositionsAggregateArgs>): Prisma.PrismaPromise<GetHighestRiskPositionsAggregateType<T>>

    /**
     * Group by HighestRiskPositions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HighestRiskPositionsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends HighestRiskPositionsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: HighestRiskPositionsGroupByArgs['orderBy'] }
        : { orderBy?: HighestRiskPositionsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, HighestRiskPositionsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetHighestRiskPositionsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for HighestRiskPositions.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__HighestRiskPositionsClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * HighestRiskPositions base type for findUnique actions
   */
  export type HighestRiskPositionsFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestRiskPositions
     */
    select?: HighestRiskPositionsSelect<ExtArgs> | null
    /**
     * Filter, which HighestRiskPositions to fetch.
     */
    where: HighestRiskPositionsWhereUniqueInput
  }

  /**
   * HighestRiskPositions findUnique
   */
  export interface HighestRiskPositionsFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends HighestRiskPositionsFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * HighestRiskPositions findUniqueOrThrow
   */
  export type HighestRiskPositionsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestRiskPositions
     */
    select?: HighestRiskPositionsSelect<ExtArgs> | null
    /**
     * Filter, which HighestRiskPositions to fetch.
     */
    where: HighestRiskPositionsWhereUniqueInput
  }


  /**
   * HighestRiskPositions base type for findFirst actions
   */
  export type HighestRiskPositionsFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestRiskPositions
     */
    select?: HighestRiskPositionsSelect<ExtArgs> | null
    /**
     * Filter, which HighestRiskPositions to fetch.
     */
    where?: HighestRiskPositionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of HighestRiskPositions to fetch.
     */
    orderBy?: Enumerable<HighestRiskPositionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for HighestRiskPositions.
     */
    cursor?: HighestRiskPositionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` HighestRiskPositions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` HighestRiskPositions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of HighestRiskPositions.
     */
    distinct?: Enumerable<HighestRiskPositionsScalarFieldEnum>
  }

  /**
   * HighestRiskPositions findFirst
   */
  export interface HighestRiskPositionsFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends HighestRiskPositionsFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * HighestRiskPositions findFirstOrThrow
   */
  export type HighestRiskPositionsFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestRiskPositions
     */
    select?: HighestRiskPositionsSelect<ExtArgs> | null
    /**
     * Filter, which HighestRiskPositions to fetch.
     */
    where?: HighestRiskPositionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of HighestRiskPositions to fetch.
     */
    orderBy?: Enumerable<HighestRiskPositionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for HighestRiskPositions.
     */
    cursor?: HighestRiskPositionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` HighestRiskPositions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` HighestRiskPositions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of HighestRiskPositions.
     */
    distinct?: Enumerable<HighestRiskPositionsScalarFieldEnum>
  }


  /**
   * HighestRiskPositions findMany
   */
  export type HighestRiskPositionsFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestRiskPositions
     */
    select?: HighestRiskPositionsSelect<ExtArgs> | null
    /**
     * Filter, which HighestRiskPositions to fetch.
     */
    where?: HighestRiskPositionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of HighestRiskPositions to fetch.
     */
    orderBy?: Enumerable<HighestRiskPositionsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing HighestRiskPositions.
     */
    cursor?: HighestRiskPositionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` HighestRiskPositions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` HighestRiskPositions.
     */
    skip?: number
    distinct?: Enumerable<HighestRiskPositionsScalarFieldEnum>
  }


  /**
   * HighestRiskPositions create
   */
  export type HighestRiskPositionsCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestRiskPositions
     */
    select?: HighestRiskPositionsSelect<ExtArgs> | null
    /**
     * The data needed to create a HighestRiskPositions.
     */
    data: XOR<HighestRiskPositionsCreateInput, HighestRiskPositionsUncheckedCreateInput>
  }


  /**
   * HighestRiskPositions createMany
   */
  export type HighestRiskPositionsCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many HighestRiskPositions.
     */
    data: Enumerable<HighestRiskPositionsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * HighestRiskPositions update
   */
  export type HighestRiskPositionsUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestRiskPositions
     */
    select?: HighestRiskPositionsSelect<ExtArgs> | null
    /**
     * The data needed to update a HighestRiskPositions.
     */
    data: XOR<HighestRiskPositionsUpdateInput, HighestRiskPositionsUncheckedUpdateInput>
    /**
     * Choose, which HighestRiskPositions to update.
     */
    where: HighestRiskPositionsWhereUniqueInput
  }


  /**
   * HighestRiskPositions updateMany
   */
  export type HighestRiskPositionsUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update HighestRiskPositions.
     */
    data: XOR<HighestRiskPositionsUpdateManyMutationInput, HighestRiskPositionsUncheckedUpdateManyInput>
    /**
     * Filter which HighestRiskPositions to update
     */
    where?: HighestRiskPositionsWhereInput
  }


  /**
   * HighestRiskPositions upsert
   */
  export type HighestRiskPositionsUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestRiskPositions
     */
    select?: HighestRiskPositionsSelect<ExtArgs> | null
    /**
     * The filter to search for the HighestRiskPositions to update in case it exists.
     */
    where: HighestRiskPositionsWhereUniqueInput
    /**
     * In case the HighestRiskPositions found by the `where` argument doesn't exist, create a new HighestRiskPositions with this data.
     */
    create: XOR<HighestRiskPositionsCreateInput, HighestRiskPositionsUncheckedCreateInput>
    /**
     * In case the HighestRiskPositions was found with the provided `where` argument, update it with this data.
     */
    update: XOR<HighestRiskPositionsUpdateInput, HighestRiskPositionsUncheckedUpdateInput>
  }


  /**
   * HighestRiskPositions delete
   */
  export type HighestRiskPositionsDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestRiskPositions
     */
    select?: HighestRiskPositionsSelect<ExtArgs> | null
    /**
     * Filter which HighestRiskPositions to delete.
     */
    where: HighestRiskPositionsWhereUniqueInput
  }


  /**
   * HighestRiskPositions deleteMany
   */
  export type HighestRiskPositionsDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which HighestRiskPositions to delete
     */
    where?: HighestRiskPositionsWhereInput
  }


  /**
   * HighestRiskPositions without action
   */
  export type HighestRiskPositionsArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestRiskPositions
     */
    select?: HighestRiskPositionsSelect<ExtArgs> | null
  }



  /**
   * Model HighestMultiplyPnl
   */


  export type AggregateHighestMultiplyPnl = {
    _count: HighestMultiplyPnlCountAggregateOutputType | null
    _avg: HighestMultiplyPnlAvgAggregateOutputType | null
    _sum: HighestMultiplyPnlSumAggregateOutputType | null
    _min: HighestMultiplyPnlMinAggregateOutputType | null
    _max: HighestMultiplyPnlMaxAggregateOutputType | null
  }

  export type HighestMultiplyPnlAvgAggregateOutputType = {
    collateral_value: Decimal | null
    vault_multiple: Decimal | null
    pnl_all: Decimal | null
    pnl_1d: Decimal | null
    pnl_7d: Decimal | null
    pnl_30d: Decimal | null
    pnl_365d: Decimal | null
    pnl_ytd: Decimal | null
    net_profit_all: Decimal | null
    net_profit_1d: Decimal | null
    net_profit_7d: Decimal | null
    net_profit_30d: Decimal | null
    net_profit_365d: Decimal | null
    net_profit_ytd: Decimal | null
  }

  export type HighestMultiplyPnlSumAggregateOutputType = {
    collateral_value: Decimal | null
    vault_multiple: Decimal | null
    pnl_all: Decimal | null
    pnl_1d: Decimal | null
    pnl_7d: Decimal | null
    pnl_30d: Decimal | null
    pnl_365d: Decimal | null
    pnl_ytd: Decimal | null
    net_profit_all: Decimal | null
    net_profit_1d: Decimal | null
    net_profit_7d: Decimal | null
    net_profit_30d: Decimal | null
    net_profit_365d: Decimal | null
    net_profit_ytd: Decimal | null
  }

  export type HighestMultiplyPnlMinAggregateOutputType = {
    protocol_id: string | null
    position_id: string | null
    collateral_type: string | null
    token: string | null
    collateral_value: Decimal | null
    vault_multiple: Decimal | null
    pnl_all: Decimal | null
    pnl_1d: Decimal | null
    pnl_7d: Decimal | null
    pnl_30d: Decimal | null
    pnl_365d: Decimal | null
    pnl_ytd: Decimal | null
    net_profit_all: Decimal | null
    net_profit_1d: Decimal | null
    net_profit_7d: Decimal | null
    net_profit_30d: Decimal | null
    net_profit_365d: Decimal | null
    net_profit_ytd: Decimal | null
    type: VaultType | null
  }

  export type HighestMultiplyPnlMaxAggregateOutputType = {
    protocol_id: string | null
    position_id: string | null
    collateral_type: string | null
    token: string | null
    collateral_value: Decimal | null
    vault_multiple: Decimal | null
    pnl_all: Decimal | null
    pnl_1d: Decimal | null
    pnl_7d: Decimal | null
    pnl_30d: Decimal | null
    pnl_365d: Decimal | null
    pnl_ytd: Decimal | null
    net_profit_all: Decimal | null
    net_profit_1d: Decimal | null
    net_profit_7d: Decimal | null
    net_profit_30d: Decimal | null
    net_profit_365d: Decimal | null
    net_profit_ytd: Decimal | null
    type: VaultType | null
  }

  export type HighestMultiplyPnlCountAggregateOutputType = {
    protocol_id: number
    position_id: number
    collateral_type: number
    token: number
    collateral_value: number
    vault_multiple: number
    pnl_all: number
    pnl_1d: number
    pnl_7d: number
    pnl_30d: number
    pnl_365d: number
    pnl_ytd: number
    net_profit_all: number
    net_profit_1d: number
    net_profit_7d: number
    net_profit_30d: number
    net_profit_365d: number
    net_profit_ytd: number
    last_action: number
    type: number
    _all: number
  }


  export type HighestMultiplyPnlAvgAggregateInputType = {
    collateral_value?: true
    vault_multiple?: true
    pnl_all?: true
    pnl_1d?: true
    pnl_7d?: true
    pnl_30d?: true
    pnl_365d?: true
    pnl_ytd?: true
    net_profit_all?: true
    net_profit_1d?: true
    net_profit_7d?: true
    net_profit_30d?: true
    net_profit_365d?: true
    net_profit_ytd?: true
  }

  export type HighestMultiplyPnlSumAggregateInputType = {
    collateral_value?: true
    vault_multiple?: true
    pnl_all?: true
    pnl_1d?: true
    pnl_7d?: true
    pnl_30d?: true
    pnl_365d?: true
    pnl_ytd?: true
    net_profit_all?: true
    net_profit_1d?: true
    net_profit_7d?: true
    net_profit_30d?: true
    net_profit_365d?: true
    net_profit_ytd?: true
  }

  export type HighestMultiplyPnlMinAggregateInputType = {
    protocol_id?: true
    position_id?: true
    collateral_type?: true
    token?: true
    collateral_value?: true
    vault_multiple?: true
    pnl_all?: true
    pnl_1d?: true
    pnl_7d?: true
    pnl_30d?: true
    pnl_365d?: true
    pnl_ytd?: true
    net_profit_all?: true
    net_profit_1d?: true
    net_profit_7d?: true
    net_profit_30d?: true
    net_profit_365d?: true
    net_profit_ytd?: true
    type?: true
  }

  export type HighestMultiplyPnlMaxAggregateInputType = {
    protocol_id?: true
    position_id?: true
    collateral_type?: true
    token?: true
    collateral_value?: true
    vault_multiple?: true
    pnl_all?: true
    pnl_1d?: true
    pnl_7d?: true
    pnl_30d?: true
    pnl_365d?: true
    pnl_ytd?: true
    net_profit_all?: true
    net_profit_1d?: true
    net_profit_7d?: true
    net_profit_30d?: true
    net_profit_365d?: true
    net_profit_ytd?: true
    type?: true
  }

  export type HighestMultiplyPnlCountAggregateInputType = {
    protocol_id?: true
    position_id?: true
    collateral_type?: true
    token?: true
    collateral_value?: true
    vault_multiple?: true
    pnl_all?: true
    pnl_1d?: true
    pnl_7d?: true
    pnl_30d?: true
    pnl_365d?: true
    pnl_ytd?: true
    net_profit_all?: true
    net_profit_1d?: true
    net_profit_7d?: true
    net_profit_30d?: true
    net_profit_365d?: true
    net_profit_ytd?: true
    last_action?: true
    type?: true
    _all?: true
  }

  export type HighestMultiplyPnlAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which HighestMultiplyPnl to aggregate.
     */
    where?: HighestMultiplyPnlWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of HighestMultiplyPnls to fetch.
     */
    orderBy?: Enumerable<HighestMultiplyPnlOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: HighestMultiplyPnlWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` HighestMultiplyPnls from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` HighestMultiplyPnls.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned HighestMultiplyPnls
    **/
    _count?: true | HighestMultiplyPnlCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: HighestMultiplyPnlAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: HighestMultiplyPnlSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: HighestMultiplyPnlMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: HighestMultiplyPnlMaxAggregateInputType
  }

  export type GetHighestMultiplyPnlAggregateType<T extends HighestMultiplyPnlAggregateArgs> = {
        [P in keyof T & keyof AggregateHighestMultiplyPnl]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateHighestMultiplyPnl[P]>
      : GetScalarType<T[P], AggregateHighestMultiplyPnl[P]>
  }




  export type HighestMultiplyPnlGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: HighestMultiplyPnlWhereInput
    orderBy?: Enumerable<HighestMultiplyPnlOrderByWithAggregationInput>
    by: HighestMultiplyPnlScalarFieldEnum[]
    having?: HighestMultiplyPnlScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: HighestMultiplyPnlCountAggregateInputType | true
    _avg?: HighestMultiplyPnlAvgAggregateInputType
    _sum?: HighestMultiplyPnlSumAggregateInputType
    _min?: HighestMultiplyPnlMinAggregateInputType
    _max?: HighestMultiplyPnlMaxAggregateInputType
  }


  export type HighestMultiplyPnlGroupByOutputType = {
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_value: Decimal
    vault_multiple: Decimal
    pnl_all: Decimal
    pnl_1d: Decimal
    pnl_7d: Decimal
    pnl_30d: Decimal
    pnl_365d: Decimal
    pnl_ytd: Decimal
    net_profit_all: Decimal
    net_profit_1d: Decimal
    net_profit_7d: Decimal
    net_profit_30d: Decimal
    net_profit_365d: Decimal
    net_profit_ytd: Decimal
    last_action: JsonValue
    type: VaultType | null
    _count: HighestMultiplyPnlCountAggregateOutputType | null
    _avg: HighestMultiplyPnlAvgAggregateOutputType | null
    _sum: HighestMultiplyPnlSumAggregateOutputType | null
    _min: HighestMultiplyPnlMinAggregateOutputType | null
    _max: HighestMultiplyPnlMaxAggregateOutputType | null
  }

  type GetHighestMultiplyPnlGroupByPayload<T extends HighestMultiplyPnlGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<HighestMultiplyPnlGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof HighestMultiplyPnlGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], HighestMultiplyPnlGroupByOutputType[P]>
            : GetScalarType<T[P], HighestMultiplyPnlGroupByOutputType[P]>
        }
      >
    >


  export type HighestMultiplyPnlSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    protocol_id?: boolean
    position_id?: boolean
    collateral_type?: boolean
    token?: boolean
    collateral_value?: boolean
    vault_multiple?: boolean
    pnl_all?: boolean
    pnl_1d?: boolean
    pnl_7d?: boolean
    pnl_30d?: boolean
    pnl_365d?: boolean
    pnl_ytd?: boolean
    net_profit_all?: boolean
    net_profit_1d?: boolean
    net_profit_7d?: boolean
    net_profit_30d?: boolean
    net_profit_365d?: boolean
    net_profit_ytd?: boolean
    last_action?: boolean
    type?: boolean
  }, ExtArgs["result"]["highestMultiplyPnl"]>

  export type HighestMultiplyPnlSelectScalar = {
    protocol_id?: boolean
    position_id?: boolean
    collateral_type?: boolean
    token?: boolean
    collateral_value?: boolean
    vault_multiple?: boolean
    pnl_all?: boolean
    pnl_1d?: boolean
    pnl_7d?: boolean
    pnl_30d?: boolean
    pnl_365d?: boolean
    pnl_ytd?: boolean
    net_profit_all?: boolean
    net_profit_1d?: boolean
    net_profit_7d?: boolean
    net_profit_30d?: boolean
    net_profit_365d?: boolean
    net_profit_ytd?: boolean
    last_action?: boolean
    type?: boolean
  }


  type HighestMultiplyPnlGetPayload<S extends boolean | null | undefined | HighestMultiplyPnlArgs> = $Types.GetResult<HighestMultiplyPnlPayload, S>

  type HighestMultiplyPnlCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<HighestMultiplyPnlFindManyArgs, 'select' | 'include'> & {
      select?: HighestMultiplyPnlCountAggregateInputType | true
    }

  export interface HighestMultiplyPnlDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['HighestMultiplyPnl'], meta: { name: 'HighestMultiplyPnl' } }
    /**
     * Find zero or one HighestMultiplyPnl that matches the filter.
     * @param {HighestMultiplyPnlFindUniqueArgs} args - Arguments to find a HighestMultiplyPnl
     * @example
     * // Get one HighestMultiplyPnl
     * const highestMultiplyPnl = await prisma.highestMultiplyPnl.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends HighestMultiplyPnlFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, HighestMultiplyPnlFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'HighestMultiplyPnl'> extends True ? Prisma__HighestMultiplyPnlClient<$Types.GetResult<HighestMultiplyPnlPayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__HighestMultiplyPnlClient<$Types.GetResult<HighestMultiplyPnlPayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one HighestMultiplyPnl that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {HighestMultiplyPnlFindUniqueOrThrowArgs} args - Arguments to find a HighestMultiplyPnl
     * @example
     * // Get one HighestMultiplyPnl
     * const highestMultiplyPnl = await prisma.highestMultiplyPnl.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends HighestMultiplyPnlFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, HighestMultiplyPnlFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__HighestMultiplyPnlClient<$Types.GetResult<HighestMultiplyPnlPayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first HighestMultiplyPnl that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HighestMultiplyPnlFindFirstArgs} args - Arguments to find a HighestMultiplyPnl
     * @example
     * // Get one HighestMultiplyPnl
     * const highestMultiplyPnl = await prisma.highestMultiplyPnl.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends HighestMultiplyPnlFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, HighestMultiplyPnlFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'HighestMultiplyPnl'> extends True ? Prisma__HighestMultiplyPnlClient<$Types.GetResult<HighestMultiplyPnlPayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__HighestMultiplyPnlClient<$Types.GetResult<HighestMultiplyPnlPayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first HighestMultiplyPnl that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HighestMultiplyPnlFindFirstOrThrowArgs} args - Arguments to find a HighestMultiplyPnl
     * @example
     * // Get one HighestMultiplyPnl
     * const highestMultiplyPnl = await prisma.highestMultiplyPnl.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends HighestMultiplyPnlFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, HighestMultiplyPnlFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__HighestMultiplyPnlClient<$Types.GetResult<HighestMultiplyPnlPayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more HighestMultiplyPnls that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HighestMultiplyPnlFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all HighestMultiplyPnls
     * const highestMultiplyPnls = await prisma.highestMultiplyPnl.findMany()
     * 
     * // Get first 10 HighestMultiplyPnls
     * const highestMultiplyPnls = await prisma.highestMultiplyPnl.findMany({ take: 10 })
     * 
     * // Only select the `protocol_id`
     * const highestMultiplyPnlWithProtocol_idOnly = await prisma.highestMultiplyPnl.findMany({ select: { protocol_id: true } })
     * 
    **/
    findMany<T extends HighestMultiplyPnlFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, HighestMultiplyPnlFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<HighestMultiplyPnlPayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a HighestMultiplyPnl.
     * @param {HighestMultiplyPnlCreateArgs} args - Arguments to create a HighestMultiplyPnl.
     * @example
     * // Create one HighestMultiplyPnl
     * const HighestMultiplyPnl = await prisma.highestMultiplyPnl.create({
     *   data: {
     *     // ... data to create a HighestMultiplyPnl
     *   }
     * })
     * 
    **/
    create<T extends HighestMultiplyPnlCreateArgs<ExtArgs>>(
      args: SelectSubset<T, HighestMultiplyPnlCreateArgs<ExtArgs>>
    ): Prisma__HighestMultiplyPnlClient<$Types.GetResult<HighestMultiplyPnlPayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many HighestMultiplyPnls.
     *     @param {HighestMultiplyPnlCreateManyArgs} args - Arguments to create many HighestMultiplyPnls.
     *     @example
     *     // Create many HighestMultiplyPnls
     *     const highestMultiplyPnl = await prisma.highestMultiplyPnl.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends HighestMultiplyPnlCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, HighestMultiplyPnlCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a HighestMultiplyPnl.
     * @param {HighestMultiplyPnlDeleteArgs} args - Arguments to delete one HighestMultiplyPnl.
     * @example
     * // Delete one HighestMultiplyPnl
     * const HighestMultiplyPnl = await prisma.highestMultiplyPnl.delete({
     *   where: {
     *     // ... filter to delete one HighestMultiplyPnl
     *   }
     * })
     * 
    **/
    delete<T extends HighestMultiplyPnlDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, HighestMultiplyPnlDeleteArgs<ExtArgs>>
    ): Prisma__HighestMultiplyPnlClient<$Types.GetResult<HighestMultiplyPnlPayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one HighestMultiplyPnl.
     * @param {HighestMultiplyPnlUpdateArgs} args - Arguments to update one HighestMultiplyPnl.
     * @example
     * // Update one HighestMultiplyPnl
     * const highestMultiplyPnl = await prisma.highestMultiplyPnl.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends HighestMultiplyPnlUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, HighestMultiplyPnlUpdateArgs<ExtArgs>>
    ): Prisma__HighestMultiplyPnlClient<$Types.GetResult<HighestMultiplyPnlPayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more HighestMultiplyPnls.
     * @param {HighestMultiplyPnlDeleteManyArgs} args - Arguments to filter HighestMultiplyPnls to delete.
     * @example
     * // Delete a few HighestMultiplyPnls
     * const { count } = await prisma.highestMultiplyPnl.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends HighestMultiplyPnlDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, HighestMultiplyPnlDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more HighestMultiplyPnls.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HighestMultiplyPnlUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many HighestMultiplyPnls
     * const highestMultiplyPnl = await prisma.highestMultiplyPnl.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends HighestMultiplyPnlUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, HighestMultiplyPnlUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one HighestMultiplyPnl.
     * @param {HighestMultiplyPnlUpsertArgs} args - Arguments to update or create a HighestMultiplyPnl.
     * @example
     * // Update or create a HighestMultiplyPnl
     * const highestMultiplyPnl = await prisma.highestMultiplyPnl.upsert({
     *   create: {
     *     // ... data to create a HighestMultiplyPnl
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the HighestMultiplyPnl we want to update
     *   }
     * })
    **/
    upsert<T extends HighestMultiplyPnlUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, HighestMultiplyPnlUpsertArgs<ExtArgs>>
    ): Prisma__HighestMultiplyPnlClient<$Types.GetResult<HighestMultiplyPnlPayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of HighestMultiplyPnls.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HighestMultiplyPnlCountArgs} args - Arguments to filter HighestMultiplyPnls to count.
     * @example
     * // Count the number of HighestMultiplyPnls
     * const count = await prisma.highestMultiplyPnl.count({
     *   where: {
     *     // ... the filter for the HighestMultiplyPnls we want to count
     *   }
     * })
    **/
    count<T extends HighestMultiplyPnlCountArgs>(
      args?: Subset<T, HighestMultiplyPnlCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], HighestMultiplyPnlCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a HighestMultiplyPnl.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HighestMultiplyPnlAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends HighestMultiplyPnlAggregateArgs>(args: Subset<T, HighestMultiplyPnlAggregateArgs>): Prisma.PrismaPromise<GetHighestMultiplyPnlAggregateType<T>>

    /**
     * Group by HighestMultiplyPnl.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HighestMultiplyPnlGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends HighestMultiplyPnlGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: HighestMultiplyPnlGroupByArgs['orderBy'] }
        : { orderBy?: HighestMultiplyPnlGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, HighestMultiplyPnlGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetHighestMultiplyPnlGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for HighestMultiplyPnl.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__HighestMultiplyPnlClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * HighestMultiplyPnl base type for findUnique actions
   */
  export type HighestMultiplyPnlFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestMultiplyPnl
     */
    select?: HighestMultiplyPnlSelect<ExtArgs> | null
    /**
     * Filter, which HighestMultiplyPnl to fetch.
     */
    where: HighestMultiplyPnlWhereUniqueInput
  }

  /**
   * HighestMultiplyPnl findUnique
   */
  export interface HighestMultiplyPnlFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends HighestMultiplyPnlFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * HighestMultiplyPnl findUniqueOrThrow
   */
  export type HighestMultiplyPnlFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestMultiplyPnl
     */
    select?: HighestMultiplyPnlSelect<ExtArgs> | null
    /**
     * Filter, which HighestMultiplyPnl to fetch.
     */
    where: HighestMultiplyPnlWhereUniqueInput
  }


  /**
   * HighestMultiplyPnl base type for findFirst actions
   */
  export type HighestMultiplyPnlFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestMultiplyPnl
     */
    select?: HighestMultiplyPnlSelect<ExtArgs> | null
    /**
     * Filter, which HighestMultiplyPnl to fetch.
     */
    where?: HighestMultiplyPnlWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of HighestMultiplyPnls to fetch.
     */
    orderBy?: Enumerable<HighestMultiplyPnlOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for HighestMultiplyPnls.
     */
    cursor?: HighestMultiplyPnlWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` HighestMultiplyPnls from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` HighestMultiplyPnls.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of HighestMultiplyPnls.
     */
    distinct?: Enumerable<HighestMultiplyPnlScalarFieldEnum>
  }

  /**
   * HighestMultiplyPnl findFirst
   */
  export interface HighestMultiplyPnlFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends HighestMultiplyPnlFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * HighestMultiplyPnl findFirstOrThrow
   */
  export type HighestMultiplyPnlFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestMultiplyPnl
     */
    select?: HighestMultiplyPnlSelect<ExtArgs> | null
    /**
     * Filter, which HighestMultiplyPnl to fetch.
     */
    where?: HighestMultiplyPnlWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of HighestMultiplyPnls to fetch.
     */
    orderBy?: Enumerable<HighestMultiplyPnlOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for HighestMultiplyPnls.
     */
    cursor?: HighestMultiplyPnlWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` HighestMultiplyPnls from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` HighestMultiplyPnls.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of HighestMultiplyPnls.
     */
    distinct?: Enumerable<HighestMultiplyPnlScalarFieldEnum>
  }


  /**
   * HighestMultiplyPnl findMany
   */
  export type HighestMultiplyPnlFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestMultiplyPnl
     */
    select?: HighestMultiplyPnlSelect<ExtArgs> | null
    /**
     * Filter, which HighestMultiplyPnls to fetch.
     */
    where?: HighestMultiplyPnlWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of HighestMultiplyPnls to fetch.
     */
    orderBy?: Enumerable<HighestMultiplyPnlOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing HighestMultiplyPnls.
     */
    cursor?: HighestMultiplyPnlWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` HighestMultiplyPnls from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` HighestMultiplyPnls.
     */
    skip?: number
    distinct?: Enumerable<HighestMultiplyPnlScalarFieldEnum>
  }


  /**
   * HighestMultiplyPnl create
   */
  export type HighestMultiplyPnlCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestMultiplyPnl
     */
    select?: HighestMultiplyPnlSelect<ExtArgs> | null
    /**
     * The data needed to create a HighestMultiplyPnl.
     */
    data: XOR<HighestMultiplyPnlCreateInput, HighestMultiplyPnlUncheckedCreateInput>
  }


  /**
   * HighestMultiplyPnl createMany
   */
  export type HighestMultiplyPnlCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many HighestMultiplyPnls.
     */
    data: Enumerable<HighestMultiplyPnlCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * HighestMultiplyPnl update
   */
  export type HighestMultiplyPnlUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestMultiplyPnl
     */
    select?: HighestMultiplyPnlSelect<ExtArgs> | null
    /**
     * The data needed to update a HighestMultiplyPnl.
     */
    data: XOR<HighestMultiplyPnlUpdateInput, HighestMultiplyPnlUncheckedUpdateInput>
    /**
     * Choose, which HighestMultiplyPnl to update.
     */
    where: HighestMultiplyPnlWhereUniqueInput
  }


  /**
   * HighestMultiplyPnl updateMany
   */
  export type HighestMultiplyPnlUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update HighestMultiplyPnls.
     */
    data: XOR<HighestMultiplyPnlUpdateManyMutationInput, HighestMultiplyPnlUncheckedUpdateManyInput>
    /**
     * Filter which HighestMultiplyPnls to update
     */
    where?: HighestMultiplyPnlWhereInput
  }


  /**
   * HighestMultiplyPnl upsert
   */
  export type HighestMultiplyPnlUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestMultiplyPnl
     */
    select?: HighestMultiplyPnlSelect<ExtArgs> | null
    /**
     * The filter to search for the HighestMultiplyPnl to update in case it exists.
     */
    where: HighestMultiplyPnlWhereUniqueInput
    /**
     * In case the HighestMultiplyPnl found by the `where` argument doesn't exist, create a new HighestMultiplyPnl with this data.
     */
    create: XOR<HighestMultiplyPnlCreateInput, HighestMultiplyPnlUncheckedCreateInput>
    /**
     * In case the HighestMultiplyPnl was found with the provided `where` argument, update it with this data.
     */
    update: XOR<HighestMultiplyPnlUpdateInput, HighestMultiplyPnlUncheckedUpdateInput>
  }


  /**
   * HighestMultiplyPnl delete
   */
  export type HighestMultiplyPnlDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestMultiplyPnl
     */
    select?: HighestMultiplyPnlSelect<ExtArgs> | null
    /**
     * Filter which HighestMultiplyPnl to delete.
     */
    where: HighestMultiplyPnlWhereUniqueInput
  }


  /**
   * HighestMultiplyPnl deleteMany
   */
  export type HighestMultiplyPnlDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which HighestMultiplyPnls to delete
     */
    where?: HighestMultiplyPnlWhereInput
  }


  /**
   * HighestMultiplyPnl without action
   */
  export type HighestMultiplyPnlArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HighestMultiplyPnl
     */
    select?: HighestMultiplyPnlSelect<ExtArgs> | null
  }



  /**
   * Model MostYieldEarned
   */


  export type AggregateMostYieldEarned = {
    _count: MostYieldEarnedCountAggregateOutputType | null
    _avg: MostYieldEarnedAvgAggregateOutputType | null
    _sum: MostYieldEarnedSumAggregateOutputType | null
    _min: MostYieldEarnedMinAggregateOutputType | null
    _max: MostYieldEarnedMaxAggregateOutputType | null
  }

  export type MostYieldEarnedAvgAggregateOutputType = {
    collateral_value: Decimal | null
    net_value: Decimal | null
    pnl_all: Decimal | null
    pnl_1d: Decimal | null
    pnl_7d: Decimal | null
    pnl_30d: Decimal | null
    pnl_365d: Decimal | null
    pnl_ytd: Decimal | null
    yield_30d: Decimal | null
  }

  export type MostYieldEarnedSumAggregateOutputType = {
    collateral_value: Decimal | null
    net_value: Decimal | null
    pnl_all: Decimal | null
    pnl_1d: Decimal | null
    pnl_7d: Decimal | null
    pnl_30d: Decimal | null
    pnl_365d: Decimal | null
    pnl_ytd: Decimal | null
    yield_30d: Decimal | null
  }

  export type MostYieldEarnedMinAggregateOutputType = {
    protocol_id: string | null
    position_id: string | null
    collateral_type: string | null
    token: string | null
    collateral_value: Decimal | null
    net_value: Decimal | null
    pnl_all: Decimal | null
    pnl_1d: Decimal | null
    pnl_7d: Decimal | null
    pnl_30d: Decimal | null
    pnl_365d: Decimal | null
    pnl_ytd: Decimal | null
    yield_30d: Decimal | null
    type: VaultType | null
  }

  export type MostYieldEarnedMaxAggregateOutputType = {
    protocol_id: string | null
    position_id: string | null
    collateral_type: string | null
    token: string | null
    collateral_value: Decimal | null
    net_value: Decimal | null
    pnl_all: Decimal | null
    pnl_1d: Decimal | null
    pnl_7d: Decimal | null
    pnl_30d: Decimal | null
    pnl_365d: Decimal | null
    pnl_ytd: Decimal | null
    yield_30d: Decimal | null
    type: VaultType | null
  }

  export type MostYieldEarnedCountAggregateOutputType = {
    protocol_id: number
    position_id: number
    collateral_type: number
    token: number
    collateral_value: number
    net_value: number
    pnl_all: number
    pnl_1d: number
    pnl_7d: number
    pnl_30d: number
    pnl_365d: number
    pnl_ytd: number
    yield_30d: number
    last_action: number
    type: number
    _all: number
  }


  export type MostYieldEarnedAvgAggregateInputType = {
    collateral_value?: true
    net_value?: true
    pnl_all?: true
    pnl_1d?: true
    pnl_7d?: true
    pnl_30d?: true
    pnl_365d?: true
    pnl_ytd?: true
    yield_30d?: true
  }

  export type MostYieldEarnedSumAggregateInputType = {
    collateral_value?: true
    net_value?: true
    pnl_all?: true
    pnl_1d?: true
    pnl_7d?: true
    pnl_30d?: true
    pnl_365d?: true
    pnl_ytd?: true
    yield_30d?: true
  }

  export type MostYieldEarnedMinAggregateInputType = {
    protocol_id?: true
    position_id?: true
    collateral_type?: true
    token?: true
    collateral_value?: true
    net_value?: true
    pnl_all?: true
    pnl_1d?: true
    pnl_7d?: true
    pnl_30d?: true
    pnl_365d?: true
    pnl_ytd?: true
    yield_30d?: true
    type?: true
  }

  export type MostYieldEarnedMaxAggregateInputType = {
    protocol_id?: true
    position_id?: true
    collateral_type?: true
    token?: true
    collateral_value?: true
    net_value?: true
    pnl_all?: true
    pnl_1d?: true
    pnl_7d?: true
    pnl_30d?: true
    pnl_365d?: true
    pnl_ytd?: true
    yield_30d?: true
    type?: true
  }

  export type MostYieldEarnedCountAggregateInputType = {
    protocol_id?: true
    position_id?: true
    collateral_type?: true
    token?: true
    collateral_value?: true
    net_value?: true
    pnl_all?: true
    pnl_1d?: true
    pnl_7d?: true
    pnl_30d?: true
    pnl_365d?: true
    pnl_ytd?: true
    yield_30d?: true
    last_action?: true
    type?: true
    _all?: true
  }

  export type MostYieldEarnedAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which MostYieldEarned to aggregate.
     */
    where?: MostYieldEarnedWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MostYieldEarneds to fetch.
     */
    orderBy?: Enumerable<MostYieldEarnedOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: MostYieldEarnedWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MostYieldEarneds from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MostYieldEarneds.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned MostYieldEarneds
    **/
    _count?: true | MostYieldEarnedCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: MostYieldEarnedAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: MostYieldEarnedSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: MostYieldEarnedMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: MostYieldEarnedMaxAggregateInputType
  }

  export type GetMostYieldEarnedAggregateType<T extends MostYieldEarnedAggregateArgs> = {
        [P in keyof T & keyof AggregateMostYieldEarned]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMostYieldEarned[P]>
      : GetScalarType<T[P], AggregateMostYieldEarned[P]>
  }




  export type MostYieldEarnedGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: MostYieldEarnedWhereInput
    orderBy?: Enumerable<MostYieldEarnedOrderByWithAggregationInput>
    by: MostYieldEarnedScalarFieldEnum[]
    having?: MostYieldEarnedScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: MostYieldEarnedCountAggregateInputType | true
    _avg?: MostYieldEarnedAvgAggregateInputType
    _sum?: MostYieldEarnedSumAggregateInputType
    _min?: MostYieldEarnedMinAggregateInputType
    _max?: MostYieldEarnedMaxAggregateInputType
  }


  export type MostYieldEarnedGroupByOutputType = {
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_value: Decimal
    net_value: Decimal
    pnl_all: Decimal
    pnl_1d: Decimal
    pnl_7d: Decimal
    pnl_30d: Decimal
    pnl_365d: Decimal
    pnl_ytd: Decimal
    yield_30d: Decimal
    last_action: JsonValue
    type: VaultType | null
    _count: MostYieldEarnedCountAggregateOutputType | null
    _avg: MostYieldEarnedAvgAggregateOutputType | null
    _sum: MostYieldEarnedSumAggregateOutputType | null
    _min: MostYieldEarnedMinAggregateOutputType | null
    _max: MostYieldEarnedMaxAggregateOutputType | null
  }

  type GetMostYieldEarnedGroupByPayload<T extends MostYieldEarnedGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<MostYieldEarnedGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof MostYieldEarnedGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], MostYieldEarnedGroupByOutputType[P]>
            : GetScalarType<T[P], MostYieldEarnedGroupByOutputType[P]>
        }
      >
    >


  export type MostYieldEarnedSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    protocol_id?: boolean
    position_id?: boolean
    collateral_type?: boolean
    token?: boolean
    collateral_value?: boolean
    net_value?: boolean
    pnl_all?: boolean
    pnl_1d?: boolean
    pnl_7d?: boolean
    pnl_30d?: boolean
    pnl_365d?: boolean
    pnl_ytd?: boolean
    yield_30d?: boolean
    last_action?: boolean
    type?: boolean
  }, ExtArgs["result"]["mostYieldEarned"]>

  export type MostYieldEarnedSelectScalar = {
    protocol_id?: boolean
    position_id?: boolean
    collateral_type?: boolean
    token?: boolean
    collateral_value?: boolean
    net_value?: boolean
    pnl_all?: boolean
    pnl_1d?: boolean
    pnl_7d?: boolean
    pnl_30d?: boolean
    pnl_365d?: boolean
    pnl_ytd?: boolean
    yield_30d?: boolean
    last_action?: boolean
    type?: boolean
  }


  type MostYieldEarnedGetPayload<S extends boolean | null | undefined | MostYieldEarnedArgs> = $Types.GetResult<MostYieldEarnedPayload, S>

  type MostYieldEarnedCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<MostYieldEarnedFindManyArgs, 'select' | 'include'> & {
      select?: MostYieldEarnedCountAggregateInputType | true
    }

  export interface MostYieldEarnedDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['MostYieldEarned'], meta: { name: 'MostYieldEarned' } }
    /**
     * Find zero or one MostYieldEarned that matches the filter.
     * @param {MostYieldEarnedFindUniqueArgs} args - Arguments to find a MostYieldEarned
     * @example
     * // Get one MostYieldEarned
     * const mostYieldEarned = await prisma.mostYieldEarned.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends MostYieldEarnedFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, MostYieldEarnedFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'MostYieldEarned'> extends True ? Prisma__MostYieldEarnedClient<$Types.GetResult<MostYieldEarnedPayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__MostYieldEarnedClient<$Types.GetResult<MostYieldEarnedPayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one MostYieldEarned that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {MostYieldEarnedFindUniqueOrThrowArgs} args - Arguments to find a MostYieldEarned
     * @example
     * // Get one MostYieldEarned
     * const mostYieldEarned = await prisma.mostYieldEarned.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends MostYieldEarnedFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, MostYieldEarnedFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__MostYieldEarnedClient<$Types.GetResult<MostYieldEarnedPayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first MostYieldEarned that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MostYieldEarnedFindFirstArgs} args - Arguments to find a MostYieldEarned
     * @example
     * // Get one MostYieldEarned
     * const mostYieldEarned = await prisma.mostYieldEarned.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends MostYieldEarnedFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, MostYieldEarnedFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'MostYieldEarned'> extends True ? Prisma__MostYieldEarnedClient<$Types.GetResult<MostYieldEarnedPayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__MostYieldEarnedClient<$Types.GetResult<MostYieldEarnedPayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first MostYieldEarned that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MostYieldEarnedFindFirstOrThrowArgs} args - Arguments to find a MostYieldEarned
     * @example
     * // Get one MostYieldEarned
     * const mostYieldEarned = await prisma.mostYieldEarned.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends MostYieldEarnedFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, MostYieldEarnedFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__MostYieldEarnedClient<$Types.GetResult<MostYieldEarnedPayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more MostYieldEarneds that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MostYieldEarnedFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all MostYieldEarneds
     * const mostYieldEarneds = await prisma.mostYieldEarned.findMany()
     * 
     * // Get first 10 MostYieldEarneds
     * const mostYieldEarneds = await prisma.mostYieldEarned.findMany({ take: 10 })
     * 
     * // Only select the `protocol_id`
     * const mostYieldEarnedWithProtocol_idOnly = await prisma.mostYieldEarned.findMany({ select: { protocol_id: true } })
     * 
    **/
    findMany<T extends MostYieldEarnedFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, MostYieldEarnedFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<MostYieldEarnedPayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a MostYieldEarned.
     * @param {MostYieldEarnedCreateArgs} args - Arguments to create a MostYieldEarned.
     * @example
     * // Create one MostYieldEarned
     * const MostYieldEarned = await prisma.mostYieldEarned.create({
     *   data: {
     *     // ... data to create a MostYieldEarned
     *   }
     * })
     * 
    **/
    create<T extends MostYieldEarnedCreateArgs<ExtArgs>>(
      args: SelectSubset<T, MostYieldEarnedCreateArgs<ExtArgs>>
    ): Prisma__MostYieldEarnedClient<$Types.GetResult<MostYieldEarnedPayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many MostYieldEarneds.
     *     @param {MostYieldEarnedCreateManyArgs} args - Arguments to create many MostYieldEarneds.
     *     @example
     *     // Create many MostYieldEarneds
     *     const mostYieldEarned = await prisma.mostYieldEarned.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends MostYieldEarnedCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, MostYieldEarnedCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a MostYieldEarned.
     * @param {MostYieldEarnedDeleteArgs} args - Arguments to delete one MostYieldEarned.
     * @example
     * // Delete one MostYieldEarned
     * const MostYieldEarned = await prisma.mostYieldEarned.delete({
     *   where: {
     *     // ... filter to delete one MostYieldEarned
     *   }
     * })
     * 
    **/
    delete<T extends MostYieldEarnedDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, MostYieldEarnedDeleteArgs<ExtArgs>>
    ): Prisma__MostYieldEarnedClient<$Types.GetResult<MostYieldEarnedPayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one MostYieldEarned.
     * @param {MostYieldEarnedUpdateArgs} args - Arguments to update one MostYieldEarned.
     * @example
     * // Update one MostYieldEarned
     * const mostYieldEarned = await prisma.mostYieldEarned.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends MostYieldEarnedUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, MostYieldEarnedUpdateArgs<ExtArgs>>
    ): Prisma__MostYieldEarnedClient<$Types.GetResult<MostYieldEarnedPayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more MostYieldEarneds.
     * @param {MostYieldEarnedDeleteManyArgs} args - Arguments to filter MostYieldEarneds to delete.
     * @example
     * // Delete a few MostYieldEarneds
     * const { count } = await prisma.mostYieldEarned.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends MostYieldEarnedDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, MostYieldEarnedDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more MostYieldEarneds.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MostYieldEarnedUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many MostYieldEarneds
     * const mostYieldEarned = await prisma.mostYieldEarned.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends MostYieldEarnedUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, MostYieldEarnedUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one MostYieldEarned.
     * @param {MostYieldEarnedUpsertArgs} args - Arguments to update or create a MostYieldEarned.
     * @example
     * // Update or create a MostYieldEarned
     * const mostYieldEarned = await prisma.mostYieldEarned.upsert({
     *   create: {
     *     // ... data to create a MostYieldEarned
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the MostYieldEarned we want to update
     *   }
     * })
    **/
    upsert<T extends MostYieldEarnedUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, MostYieldEarnedUpsertArgs<ExtArgs>>
    ): Prisma__MostYieldEarnedClient<$Types.GetResult<MostYieldEarnedPayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of MostYieldEarneds.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MostYieldEarnedCountArgs} args - Arguments to filter MostYieldEarneds to count.
     * @example
     * // Count the number of MostYieldEarneds
     * const count = await prisma.mostYieldEarned.count({
     *   where: {
     *     // ... the filter for the MostYieldEarneds we want to count
     *   }
     * })
    **/
    count<T extends MostYieldEarnedCountArgs>(
      args?: Subset<T, MostYieldEarnedCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], MostYieldEarnedCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a MostYieldEarned.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MostYieldEarnedAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends MostYieldEarnedAggregateArgs>(args: Subset<T, MostYieldEarnedAggregateArgs>): Prisma.PrismaPromise<GetMostYieldEarnedAggregateType<T>>

    /**
     * Group by MostYieldEarned.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MostYieldEarnedGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends MostYieldEarnedGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: MostYieldEarnedGroupByArgs['orderBy'] }
        : { orderBy?: MostYieldEarnedGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, MostYieldEarnedGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMostYieldEarnedGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for MostYieldEarned.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__MostYieldEarnedClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * MostYieldEarned base type for findUnique actions
   */
  export type MostYieldEarnedFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MostYieldEarned
     */
    select?: MostYieldEarnedSelect<ExtArgs> | null
    /**
     * Filter, which MostYieldEarned to fetch.
     */
    where: MostYieldEarnedWhereUniqueInput
  }

  /**
   * MostYieldEarned findUnique
   */
  export interface MostYieldEarnedFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends MostYieldEarnedFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * MostYieldEarned findUniqueOrThrow
   */
  export type MostYieldEarnedFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MostYieldEarned
     */
    select?: MostYieldEarnedSelect<ExtArgs> | null
    /**
     * Filter, which MostYieldEarned to fetch.
     */
    where: MostYieldEarnedWhereUniqueInput
  }


  /**
   * MostYieldEarned base type for findFirst actions
   */
  export type MostYieldEarnedFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MostYieldEarned
     */
    select?: MostYieldEarnedSelect<ExtArgs> | null
    /**
     * Filter, which MostYieldEarned to fetch.
     */
    where?: MostYieldEarnedWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MostYieldEarneds to fetch.
     */
    orderBy?: Enumerable<MostYieldEarnedOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MostYieldEarneds.
     */
    cursor?: MostYieldEarnedWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MostYieldEarneds from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MostYieldEarneds.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MostYieldEarneds.
     */
    distinct?: Enumerable<MostYieldEarnedScalarFieldEnum>
  }

  /**
   * MostYieldEarned findFirst
   */
  export interface MostYieldEarnedFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends MostYieldEarnedFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * MostYieldEarned findFirstOrThrow
   */
  export type MostYieldEarnedFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MostYieldEarned
     */
    select?: MostYieldEarnedSelect<ExtArgs> | null
    /**
     * Filter, which MostYieldEarned to fetch.
     */
    where?: MostYieldEarnedWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MostYieldEarneds to fetch.
     */
    orderBy?: Enumerable<MostYieldEarnedOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MostYieldEarneds.
     */
    cursor?: MostYieldEarnedWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MostYieldEarneds from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MostYieldEarneds.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MostYieldEarneds.
     */
    distinct?: Enumerable<MostYieldEarnedScalarFieldEnum>
  }


  /**
   * MostYieldEarned findMany
   */
  export type MostYieldEarnedFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MostYieldEarned
     */
    select?: MostYieldEarnedSelect<ExtArgs> | null
    /**
     * Filter, which MostYieldEarneds to fetch.
     */
    where?: MostYieldEarnedWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MostYieldEarneds to fetch.
     */
    orderBy?: Enumerable<MostYieldEarnedOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing MostYieldEarneds.
     */
    cursor?: MostYieldEarnedWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MostYieldEarneds from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MostYieldEarneds.
     */
    skip?: number
    distinct?: Enumerable<MostYieldEarnedScalarFieldEnum>
  }


  /**
   * MostYieldEarned create
   */
  export type MostYieldEarnedCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MostYieldEarned
     */
    select?: MostYieldEarnedSelect<ExtArgs> | null
    /**
     * The data needed to create a MostYieldEarned.
     */
    data: XOR<MostYieldEarnedCreateInput, MostYieldEarnedUncheckedCreateInput>
  }


  /**
   * MostYieldEarned createMany
   */
  export type MostYieldEarnedCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many MostYieldEarneds.
     */
    data: Enumerable<MostYieldEarnedCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * MostYieldEarned update
   */
  export type MostYieldEarnedUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MostYieldEarned
     */
    select?: MostYieldEarnedSelect<ExtArgs> | null
    /**
     * The data needed to update a MostYieldEarned.
     */
    data: XOR<MostYieldEarnedUpdateInput, MostYieldEarnedUncheckedUpdateInput>
    /**
     * Choose, which MostYieldEarned to update.
     */
    where: MostYieldEarnedWhereUniqueInput
  }


  /**
   * MostYieldEarned updateMany
   */
  export type MostYieldEarnedUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update MostYieldEarneds.
     */
    data: XOR<MostYieldEarnedUpdateManyMutationInput, MostYieldEarnedUncheckedUpdateManyInput>
    /**
     * Filter which MostYieldEarneds to update
     */
    where?: MostYieldEarnedWhereInput
  }


  /**
   * MostYieldEarned upsert
   */
  export type MostYieldEarnedUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MostYieldEarned
     */
    select?: MostYieldEarnedSelect<ExtArgs> | null
    /**
     * The filter to search for the MostYieldEarned to update in case it exists.
     */
    where: MostYieldEarnedWhereUniqueInput
    /**
     * In case the MostYieldEarned found by the `where` argument doesn't exist, create a new MostYieldEarned with this data.
     */
    create: XOR<MostYieldEarnedCreateInput, MostYieldEarnedUncheckedCreateInput>
    /**
     * In case the MostYieldEarned was found with the provided `where` argument, update it with this data.
     */
    update: XOR<MostYieldEarnedUpdateInput, MostYieldEarnedUncheckedUpdateInput>
  }


  /**
   * MostYieldEarned delete
   */
  export type MostYieldEarnedDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MostYieldEarned
     */
    select?: MostYieldEarnedSelect<ExtArgs> | null
    /**
     * Filter which MostYieldEarned to delete.
     */
    where: MostYieldEarnedWhereUniqueInput
  }


  /**
   * MostYieldEarned deleteMany
   */
  export type MostYieldEarnedDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which MostYieldEarneds to delete
     */
    where?: MostYieldEarnedWhereInput
  }


  /**
   * MostYieldEarned without action
   */
  export type MostYieldEarnedArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MostYieldEarned
     */
    select?: MostYieldEarnedSelect<ExtArgs> | null
  }



  /**
   * Model LargestDebt
   */


  export type AggregateLargestDebt = {
    _count: LargestDebtCountAggregateOutputType | null
    _avg: LargestDebtAvgAggregateOutputType | null
    _sum: LargestDebtSumAggregateOutputType | null
    _min: LargestDebtMinAggregateOutputType | null
    _max: LargestDebtMaxAggregateOutputType | null
  }

  export type LargestDebtAvgAggregateOutputType = {
    collateral_value: Decimal | null
    liquidation_proximity: Decimal | null
    vault_debt: Decimal | null
    coll_ratio: Decimal | null
  }

  export type LargestDebtSumAggregateOutputType = {
    collateral_value: Decimal | null
    liquidation_proximity: Decimal | null
    vault_debt: Decimal | null
    coll_ratio: Decimal | null
  }

  export type LargestDebtMinAggregateOutputType = {
    protocol_id: string | null
    position_id: string | null
    collateral_type: string | null
    token: string | null
    collateral_value: Decimal | null
    liquidation_proximity: Decimal | null
    vault_debt: Decimal | null
    coll_ratio: Decimal | null
    type: VaultType | null
  }

  export type LargestDebtMaxAggregateOutputType = {
    protocol_id: string | null
    position_id: string | null
    collateral_type: string | null
    token: string | null
    collateral_value: Decimal | null
    liquidation_proximity: Decimal | null
    vault_debt: Decimal | null
    coll_ratio: Decimal | null
    type: VaultType | null
  }

  export type LargestDebtCountAggregateOutputType = {
    protocol_id: number
    position_id: number
    collateral_type: number
    token: number
    collateral_value: number
    liquidation_proximity: number
    vault_debt: number
    coll_ratio: number
    last_action: number
    type: number
    _all: number
  }


  export type LargestDebtAvgAggregateInputType = {
    collateral_value?: true
    liquidation_proximity?: true
    vault_debt?: true
    coll_ratio?: true
  }

  export type LargestDebtSumAggregateInputType = {
    collateral_value?: true
    liquidation_proximity?: true
    vault_debt?: true
    coll_ratio?: true
  }

  export type LargestDebtMinAggregateInputType = {
    protocol_id?: true
    position_id?: true
    collateral_type?: true
    token?: true
    collateral_value?: true
    liquidation_proximity?: true
    vault_debt?: true
    coll_ratio?: true
    type?: true
  }

  export type LargestDebtMaxAggregateInputType = {
    protocol_id?: true
    position_id?: true
    collateral_type?: true
    token?: true
    collateral_value?: true
    liquidation_proximity?: true
    vault_debt?: true
    coll_ratio?: true
    type?: true
  }

  export type LargestDebtCountAggregateInputType = {
    protocol_id?: true
    position_id?: true
    collateral_type?: true
    token?: true
    collateral_value?: true
    liquidation_proximity?: true
    vault_debt?: true
    coll_ratio?: true
    last_action?: true
    type?: true
    _all?: true
  }

  export type LargestDebtAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which LargestDebt to aggregate.
     */
    where?: LargestDebtWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of LargestDebts to fetch.
     */
    orderBy?: Enumerable<LargestDebtOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: LargestDebtWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` LargestDebts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` LargestDebts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned LargestDebts
    **/
    _count?: true | LargestDebtCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: LargestDebtAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: LargestDebtSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: LargestDebtMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: LargestDebtMaxAggregateInputType
  }

  export type GetLargestDebtAggregateType<T extends LargestDebtAggregateArgs> = {
        [P in keyof T & keyof AggregateLargestDebt]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateLargestDebt[P]>
      : GetScalarType<T[P], AggregateLargestDebt[P]>
  }




  export type LargestDebtGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: LargestDebtWhereInput
    orderBy?: Enumerable<LargestDebtOrderByWithAggregationInput>
    by: LargestDebtScalarFieldEnum[]
    having?: LargestDebtScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: LargestDebtCountAggregateInputType | true
    _avg?: LargestDebtAvgAggregateInputType
    _sum?: LargestDebtSumAggregateInputType
    _min?: LargestDebtMinAggregateInputType
    _max?: LargestDebtMaxAggregateInputType
  }


  export type LargestDebtGroupByOutputType = {
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_value: Decimal
    liquidation_proximity: Decimal
    vault_debt: Decimal
    coll_ratio: Decimal
    last_action: JsonValue
    type: VaultType | null
    _count: LargestDebtCountAggregateOutputType | null
    _avg: LargestDebtAvgAggregateOutputType | null
    _sum: LargestDebtSumAggregateOutputType | null
    _min: LargestDebtMinAggregateOutputType | null
    _max: LargestDebtMaxAggregateOutputType | null
  }

  type GetLargestDebtGroupByPayload<T extends LargestDebtGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<LargestDebtGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof LargestDebtGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], LargestDebtGroupByOutputType[P]>
            : GetScalarType<T[P], LargestDebtGroupByOutputType[P]>
        }
      >
    >


  export type LargestDebtSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    protocol_id?: boolean
    position_id?: boolean
    collateral_type?: boolean
    token?: boolean
    collateral_value?: boolean
    liquidation_proximity?: boolean
    vault_debt?: boolean
    coll_ratio?: boolean
    last_action?: boolean
    type?: boolean
  }, ExtArgs["result"]["largestDebt"]>

  export type LargestDebtSelectScalar = {
    protocol_id?: boolean
    position_id?: boolean
    collateral_type?: boolean
    token?: boolean
    collateral_value?: boolean
    liquidation_proximity?: boolean
    vault_debt?: boolean
    coll_ratio?: boolean
    last_action?: boolean
    type?: boolean
  }


  type LargestDebtGetPayload<S extends boolean | null | undefined | LargestDebtArgs> = $Types.GetResult<LargestDebtPayload, S>

  type LargestDebtCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<LargestDebtFindManyArgs, 'select' | 'include'> & {
      select?: LargestDebtCountAggregateInputType | true
    }

  export interface LargestDebtDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['LargestDebt'], meta: { name: 'LargestDebt' } }
    /**
     * Find zero or one LargestDebt that matches the filter.
     * @param {LargestDebtFindUniqueArgs} args - Arguments to find a LargestDebt
     * @example
     * // Get one LargestDebt
     * const largestDebt = await prisma.largestDebt.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends LargestDebtFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, LargestDebtFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'LargestDebt'> extends True ? Prisma__LargestDebtClient<$Types.GetResult<LargestDebtPayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__LargestDebtClient<$Types.GetResult<LargestDebtPayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one LargestDebt that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {LargestDebtFindUniqueOrThrowArgs} args - Arguments to find a LargestDebt
     * @example
     * // Get one LargestDebt
     * const largestDebt = await prisma.largestDebt.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends LargestDebtFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, LargestDebtFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__LargestDebtClient<$Types.GetResult<LargestDebtPayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first LargestDebt that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LargestDebtFindFirstArgs} args - Arguments to find a LargestDebt
     * @example
     * // Get one LargestDebt
     * const largestDebt = await prisma.largestDebt.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends LargestDebtFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, LargestDebtFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'LargestDebt'> extends True ? Prisma__LargestDebtClient<$Types.GetResult<LargestDebtPayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__LargestDebtClient<$Types.GetResult<LargestDebtPayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first LargestDebt that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LargestDebtFindFirstOrThrowArgs} args - Arguments to find a LargestDebt
     * @example
     * // Get one LargestDebt
     * const largestDebt = await prisma.largestDebt.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends LargestDebtFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, LargestDebtFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__LargestDebtClient<$Types.GetResult<LargestDebtPayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more LargestDebts that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LargestDebtFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all LargestDebts
     * const largestDebts = await prisma.largestDebt.findMany()
     * 
     * // Get first 10 LargestDebts
     * const largestDebts = await prisma.largestDebt.findMany({ take: 10 })
     * 
     * // Only select the `protocol_id`
     * const largestDebtWithProtocol_idOnly = await prisma.largestDebt.findMany({ select: { protocol_id: true } })
     * 
    **/
    findMany<T extends LargestDebtFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, LargestDebtFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<LargestDebtPayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a LargestDebt.
     * @param {LargestDebtCreateArgs} args - Arguments to create a LargestDebt.
     * @example
     * // Create one LargestDebt
     * const LargestDebt = await prisma.largestDebt.create({
     *   data: {
     *     // ... data to create a LargestDebt
     *   }
     * })
     * 
    **/
    create<T extends LargestDebtCreateArgs<ExtArgs>>(
      args: SelectSubset<T, LargestDebtCreateArgs<ExtArgs>>
    ): Prisma__LargestDebtClient<$Types.GetResult<LargestDebtPayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many LargestDebts.
     *     @param {LargestDebtCreateManyArgs} args - Arguments to create many LargestDebts.
     *     @example
     *     // Create many LargestDebts
     *     const largestDebt = await prisma.largestDebt.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends LargestDebtCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, LargestDebtCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a LargestDebt.
     * @param {LargestDebtDeleteArgs} args - Arguments to delete one LargestDebt.
     * @example
     * // Delete one LargestDebt
     * const LargestDebt = await prisma.largestDebt.delete({
     *   where: {
     *     // ... filter to delete one LargestDebt
     *   }
     * })
     * 
    **/
    delete<T extends LargestDebtDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, LargestDebtDeleteArgs<ExtArgs>>
    ): Prisma__LargestDebtClient<$Types.GetResult<LargestDebtPayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one LargestDebt.
     * @param {LargestDebtUpdateArgs} args - Arguments to update one LargestDebt.
     * @example
     * // Update one LargestDebt
     * const largestDebt = await prisma.largestDebt.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends LargestDebtUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, LargestDebtUpdateArgs<ExtArgs>>
    ): Prisma__LargestDebtClient<$Types.GetResult<LargestDebtPayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more LargestDebts.
     * @param {LargestDebtDeleteManyArgs} args - Arguments to filter LargestDebts to delete.
     * @example
     * // Delete a few LargestDebts
     * const { count } = await prisma.largestDebt.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends LargestDebtDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, LargestDebtDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more LargestDebts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LargestDebtUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many LargestDebts
     * const largestDebt = await prisma.largestDebt.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends LargestDebtUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, LargestDebtUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one LargestDebt.
     * @param {LargestDebtUpsertArgs} args - Arguments to update or create a LargestDebt.
     * @example
     * // Update or create a LargestDebt
     * const largestDebt = await prisma.largestDebt.upsert({
     *   create: {
     *     // ... data to create a LargestDebt
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the LargestDebt we want to update
     *   }
     * })
    **/
    upsert<T extends LargestDebtUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, LargestDebtUpsertArgs<ExtArgs>>
    ): Prisma__LargestDebtClient<$Types.GetResult<LargestDebtPayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of LargestDebts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LargestDebtCountArgs} args - Arguments to filter LargestDebts to count.
     * @example
     * // Count the number of LargestDebts
     * const count = await prisma.largestDebt.count({
     *   where: {
     *     // ... the filter for the LargestDebts we want to count
     *   }
     * })
    **/
    count<T extends LargestDebtCountArgs>(
      args?: Subset<T, LargestDebtCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], LargestDebtCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a LargestDebt.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LargestDebtAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends LargestDebtAggregateArgs>(args: Subset<T, LargestDebtAggregateArgs>): Prisma.PrismaPromise<GetLargestDebtAggregateType<T>>

    /**
     * Group by LargestDebt.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LargestDebtGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends LargestDebtGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: LargestDebtGroupByArgs['orderBy'] }
        : { orderBy?: LargestDebtGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, LargestDebtGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetLargestDebtGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for LargestDebt.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__LargestDebtClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * LargestDebt base type for findUnique actions
   */
  export type LargestDebtFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LargestDebt
     */
    select?: LargestDebtSelect<ExtArgs> | null
    /**
     * Filter, which LargestDebt to fetch.
     */
    where: LargestDebtWhereUniqueInput
  }

  /**
   * LargestDebt findUnique
   */
  export interface LargestDebtFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends LargestDebtFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * LargestDebt findUniqueOrThrow
   */
  export type LargestDebtFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LargestDebt
     */
    select?: LargestDebtSelect<ExtArgs> | null
    /**
     * Filter, which LargestDebt to fetch.
     */
    where: LargestDebtWhereUniqueInput
  }


  /**
   * LargestDebt base type for findFirst actions
   */
  export type LargestDebtFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LargestDebt
     */
    select?: LargestDebtSelect<ExtArgs> | null
    /**
     * Filter, which LargestDebt to fetch.
     */
    where?: LargestDebtWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of LargestDebts to fetch.
     */
    orderBy?: Enumerable<LargestDebtOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for LargestDebts.
     */
    cursor?: LargestDebtWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` LargestDebts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` LargestDebts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of LargestDebts.
     */
    distinct?: Enumerable<LargestDebtScalarFieldEnum>
  }

  /**
   * LargestDebt findFirst
   */
  export interface LargestDebtFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends LargestDebtFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * LargestDebt findFirstOrThrow
   */
  export type LargestDebtFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LargestDebt
     */
    select?: LargestDebtSelect<ExtArgs> | null
    /**
     * Filter, which LargestDebt to fetch.
     */
    where?: LargestDebtWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of LargestDebts to fetch.
     */
    orderBy?: Enumerable<LargestDebtOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for LargestDebts.
     */
    cursor?: LargestDebtWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` LargestDebts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` LargestDebts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of LargestDebts.
     */
    distinct?: Enumerable<LargestDebtScalarFieldEnum>
  }


  /**
   * LargestDebt findMany
   */
  export type LargestDebtFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LargestDebt
     */
    select?: LargestDebtSelect<ExtArgs> | null
    /**
     * Filter, which LargestDebts to fetch.
     */
    where?: LargestDebtWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of LargestDebts to fetch.
     */
    orderBy?: Enumerable<LargestDebtOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing LargestDebts.
     */
    cursor?: LargestDebtWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` LargestDebts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` LargestDebts.
     */
    skip?: number
    distinct?: Enumerable<LargestDebtScalarFieldEnum>
  }


  /**
   * LargestDebt create
   */
  export type LargestDebtCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LargestDebt
     */
    select?: LargestDebtSelect<ExtArgs> | null
    /**
     * The data needed to create a LargestDebt.
     */
    data: XOR<LargestDebtCreateInput, LargestDebtUncheckedCreateInput>
  }


  /**
   * LargestDebt createMany
   */
  export type LargestDebtCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many LargestDebts.
     */
    data: Enumerable<LargestDebtCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * LargestDebt update
   */
  export type LargestDebtUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LargestDebt
     */
    select?: LargestDebtSelect<ExtArgs> | null
    /**
     * The data needed to update a LargestDebt.
     */
    data: XOR<LargestDebtUpdateInput, LargestDebtUncheckedUpdateInput>
    /**
     * Choose, which LargestDebt to update.
     */
    where: LargestDebtWhereUniqueInput
  }


  /**
   * LargestDebt updateMany
   */
  export type LargestDebtUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update LargestDebts.
     */
    data: XOR<LargestDebtUpdateManyMutationInput, LargestDebtUncheckedUpdateManyInput>
    /**
     * Filter which LargestDebts to update
     */
    where?: LargestDebtWhereInput
  }


  /**
   * LargestDebt upsert
   */
  export type LargestDebtUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LargestDebt
     */
    select?: LargestDebtSelect<ExtArgs> | null
    /**
     * The filter to search for the LargestDebt to update in case it exists.
     */
    where: LargestDebtWhereUniqueInput
    /**
     * In case the LargestDebt found by the `where` argument doesn't exist, create a new LargestDebt with this data.
     */
    create: XOR<LargestDebtCreateInput, LargestDebtUncheckedCreateInput>
    /**
     * In case the LargestDebt was found with the provided `where` argument, update it with this data.
     */
    update: XOR<LargestDebtUpdateInput, LargestDebtUncheckedUpdateInput>
  }


  /**
   * LargestDebt delete
   */
  export type LargestDebtDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LargestDebt
     */
    select?: LargestDebtSelect<ExtArgs> | null
    /**
     * Filter which LargestDebt to delete.
     */
    where: LargestDebtWhereUniqueInput
  }


  /**
   * LargestDebt deleteMany
   */
  export type LargestDebtDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which LargestDebts to delete
     */
    where?: LargestDebtWhereInput
  }


  /**
   * LargestDebt without action
   */
  export type LargestDebtArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LargestDebt
     */
    select?: LargestDebtSelect<ExtArgs> | null
  }



  /**
   * Model UsersWhoFollowVaults
   */


  export type AggregateUsersWhoFollowVaults = {
    _count: UsersWhoFollowVaultsCountAggregateOutputType | null
    _avg: UsersWhoFollowVaultsAvgAggregateOutputType | null
    _sum: UsersWhoFollowVaultsSumAggregateOutputType | null
    _min: UsersWhoFollowVaultsMinAggregateOutputType | null
    _max: UsersWhoFollowVaultsMaxAggregateOutputType | null
  }

  export type UsersWhoFollowVaultsAvgAggregateOutputType = {
    vault_id: number | null
    vault_chain_id: number | null
  }

  export type UsersWhoFollowVaultsSumAggregateOutputType = {
    vault_id: number | null
    vault_chain_id: number | null
  }

  export type UsersWhoFollowVaultsMinAggregateOutputType = {
    user_address: string | null
    vault_id: number | null
    vault_chain_id: number | null
    protocol: Protocol | null
  }

  export type UsersWhoFollowVaultsMaxAggregateOutputType = {
    user_address: string | null
    vault_id: number | null
    vault_chain_id: number | null
    protocol: Protocol | null
  }

  export type UsersWhoFollowVaultsCountAggregateOutputType = {
    user_address: number
    vault_id: number
    vault_chain_id: number
    protocol: number
    _all: number
  }


  export type UsersWhoFollowVaultsAvgAggregateInputType = {
    vault_id?: true
    vault_chain_id?: true
  }

  export type UsersWhoFollowVaultsSumAggregateInputType = {
    vault_id?: true
    vault_chain_id?: true
  }

  export type UsersWhoFollowVaultsMinAggregateInputType = {
    user_address?: true
    vault_id?: true
    vault_chain_id?: true
    protocol?: true
  }

  export type UsersWhoFollowVaultsMaxAggregateInputType = {
    user_address?: true
    vault_id?: true
    vault_chain_id?: true
    protocol?: true
  }

  export type UsersWhoFollowVaultsCountAggregateInputType = {
    user_address?: true
    vault_id?: true
    vault_chain_id?: true
    protocol?: true
    _all?: true
  }

  export type UsersWhoFollowVaultsAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which UsersWhoFollowVaults to aggregate.
     */
    where?: UsersWhoFollowVaultsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UsersWhoFollowVaults to fetch.
     */
    orderBy?: Enumerable<UsersWhoFollowVaultsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UsersWhoFollowVaultsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UsersWhoFollowVaults from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UsersWhoFollowVaults.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned UsersWhoFollowVaults
    **/
    _count?: true | UsersWhoFollowVaultsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: UsersWhoFollowVaultsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: UsersWhoFollowVaultsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UsersWhoFollowVaultsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UsersWhoFollowVaultsMaxAggregateInputType
  }

  export type GetUsersWhoFollowVaultsAggregateType<T extends UsersWhoFollowVaultsAggregateArgs> = {
        [P in keyof T & keyof AggregateUsersWhoFollowVaults]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUsersWhoFollowVaults[P]>
      : GetScalarType<T[P], AggregateUsersWhoFollowVaults[P]>
  }




  export type UsersWhoFollowVaultsGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: UsersWhoFollowVaultsWhereInput
    orderBy?: Enumerable<UsersWhoFollowVaultsOrderByWithAggregationInput>
    by: UsersWhoFollowVaultsScalarFieldEnum[]
    having?: UsersWhoFollowVaultsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UsersWhoFollowVaultsCountAggregateInputType | true
    _avg?: UsersWhoFollowVaultsAvgAggregateInputType
    _sum?: UsersWhoFollowVaultsSumAggregateInputType
    _min?: UsersWhoFollowVaultsMinAggregateInputType
    _max?: UsersWhoFollowVaultsMaxAggregateInputType
  }


  export type UsersWhoFollowVaultsGroupByOutputType = {
    user_address: string
    vault_id: number
    vault_chain_id: number
    protocol: Protocol
    _count: UsersWhoFollowVaultsCountAggregateOutputType | null
    _avg: UsersWhoFollowVaultsAvgAggregateOutputType | null
    _sum: UsersWhoFollowVaultsSumAggregateOutputType | null
    _min: UsersWhoFollowVaultsMinAggregateOutputType | null
    _max: UsersWhoFollowVaultsMaxAggregateOutputType | null
  }

  type GetUsersWhoFollowVaultsGroupByPayload<T extends UsersWhoFollowVaultsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<UsersWhoFollowVaultsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UsersWhoFollowVaultsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UsersWhoFollowVaultsGroupByOutputType[P]>
            : GetScalarType<T[P], UsersWhoFollowVaultsGroupByOutputType[P]>
        }
      >
    >


  export type UsersWhoFollowVaultsSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    user_address?: boolean
    vault_id?: boolean
    vault_chain_id?: boolean
    protocol?: boolean
  }, ExtArgs["result"]["usersWhoFollowVaults"]>

  export type UsersWhoFollowVaultsSelectScalar = {
    user_address?: boolean
    vault_id?: boolean
    vault_chain_id?: boolean
    protocol?: boolean
  }


  type UsersWhoFollowVaultsGetPayload<S extends boolean | null | undefined | UsersWhoFollowVaultsArgs> = $Types.GetResult<UsersWhoFollowVaultsPayload, S>

  type UsersWhoFollowVaultsCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<UsersWhoFollowVaultsFindManyArgs, 'select' | 'include'> & {
      select?: UsersWhoFollowVaultsCountAggregateInputType | true
    }

  export interface UsersWhoFollowVaultsDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['UsersWhoFollowVaults'], meta: { name: 'UsersWhoFollowVaults' } }
    /**
     * Find zero or one UsersWhoFollowVaults that matches the filter.
     * @param {UsersWhoFollowVaultsFindUniqueArgs} args - Arguments to find a UsersWhoFollowVaults
     * @example
     * // Get one UsersWhoFollowVaults
     * const usersWhoFollowVaults = await prisma.usersWhoFollowVaults.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends UsersWhoFollowVaultsFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, UsersWhoFollowVaultsFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'UsersWhoFollowVaults'> extends True ? Prisma__UsersWhoFollowVaultsClient<$Types.GetResult<UsersWhoFollowVaultsPayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__UsersWhoFollowVaultsClient<$Types.GetResult<UsersWhoFollowVaultsPayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one UsersWhoFollowVaults that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {UsersWhoFollowVaultsFindUniqueOrThrowArgs} args - Arguments to find a UsersWhoFollowVaults
     * @example
     * // Get one UsersWhoFollowVaults
     * const usersWhoFollowVaults = await prisma.usersWhoFollowVaults.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends UsersWhoFollowVaultsFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, UsersWhoFollowVaultsFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__UsersWhoFollowVaultsClient<$Types.GetResult<UsersWhoFollowVaultsPayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first UsersWhoFollowVaults that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsersWhoFollowVaultsFindFirstArgs} args - Arguments to find a UsersWhoFollowVaults
     * @example
     * // Get one UsersWhoFollowVaults
     * const usersWhoFollowVaults = await prisma.usersWhoFollowVaults.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends UsersWhoFollowVaultsFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, UsersWhoFollowVaultsFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'UsersWhoFollowVaults'> extends True ? Prisma__UsersWhoFollowVaultsClient<$Types.GetResult<UsersWhoFollowVaultsPayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__UsersWhoFollowVaultsClient<$Types.GetResult<UsersWhoFollowVaultsPayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first UsersWhoFollowVaults that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsersWhoFollowVaultsFindFirstOrThrowArgs} args - Arguments to find a UsersWhoFollowVaults
     * @example
     * // Get one UsersWhoFollowVaults
     * const usersWhoFollowVaults = await prisma.usersWhoFollowVaults.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends UsersWhoFollowVaultsFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, UsersWhoFollowVaultsFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__UsersWhoFollowVaultsClient<$Types.GetResult<UsersWhoFollowVaultsPayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more UsersWhoFollowVaults that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsersWhoFollowVaultsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all UsersWhoFollowVaults
     * const usersWhoFollowVaults = await prisma.usersWhoFollowVaults.findMany()
     * 
     * // Get first 10 UsersWhoFollowVaults
     * const usersWhoFollowVaults = await prisma.usersWhoFollowVaults.findMany({ take: 10 })
     * 
     * // Only select the `user_address`
     * const usersWhoFollowVaultsWithUser_addressOnly = await prisma.usersWhoFollowVaults.findMany({ select: { user_address: true } })
     * 
    **/
    findMany<T extends UsersWhoFollowVaultsFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, UsersWhoFollowVaultsFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<UsersWhoFollowVaultsPayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a UsersWhoFollowVaults.
     * @param {UsersWhoFollowVaultsCreateArgs} args - Arguments to create a UsersWhoFollowVaults.
     * @example
     * // Create one UsersWhoFollowVaults
     * const UsersWhoFollowVaults = await prisma.usersWhoFollowVaults.create({
     *   data: {
     *     // ... data to create a UsersWhoFollowVaults
     *   }
     * })
     * 
    **/
    create<T extends UsersWhoFollowVaultsCreateArgs<ExtArgs>>(
      args: SelectSubset<T, UsersWhoFollowVaultsCreateArgs<ExtArgs>>
    ): Prisma__UsersWhoFollowVaultsClient<$Types.GetResult<UsersWhoFollowVaultsPayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many UsersWhoFollowVaults.
     *     @param {UsersWhoFollowVaultsCreateManyArgs} args - Arguments to create many UsersWhoFollowVaults.
     *     @example
     *     // Create many UsersWhoFollowVaults
     *     const usersWhoFollowVaults = await prisma.usersWhoFollowVaults.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends UsersWhoFollowVaultsCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, UsersWhoFollowVaultsCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a UsersWhoFollowVaults.
     * @param {UsersWhoFollowVaultsDeleteArgs} args - Arguments to delete one UsersWhoFollowVaults.
     * @example
     * // Delete one UsersWhoFollowVaults
     * const UsersWhoFollowVaults = await prisma.usersWhoFollowVaults.delete({
     *   where: {
     *     // ... filter to delete one UsersWhoFollowVaults
     *   }
     * })
     * 
    **/
    delete<T extends UsersWhoFollowVaultsDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, UsersWhoFollowVaultsDeleteArgs<ExtArgs>>
    ): Prisma__UsersWhoFollowVaultsClient<$Types.GetResult<UsersWhoFollowVaultsPayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one UsersWhoFollowVaults.
     * @param {UsersWhoFollowVaultsUpdateArgs} args - Arguments to update one UsersWhoFollowVaults.
     * @example
     * // Update one UsersWhoFollowVaults
     * const usersWhoFollowVaults = await prisma.usersWhoFollowVaults.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends UsersWhoFollowVaultsUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, UsersWhoFollowVaultsUpdateArgs<ExtArgs>>
    ): Prisma__UsersWhoFollowVaultsClient<$Types.GetResult<UsersWhoFollowVaultsPayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more UsersWhoFollowVaults.
     * @param {UsersWhoFollowVaultsDeleteManyArgs} args - Arguments to filter UsersWhoFollowVaults to delete.
     * @example
     * // Delete a few UsersWhoFollowVaults
     * const { count } = await prisma.usersWhoFollowVaults.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends UsersWhoFollowVaultsDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, UsersWhoFollowVaultsDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more UsersWhoFollowVaults.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsersWhoFollowVaultsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many UsersWhoFollowVaults
     * const usersWhoFollowVaults = await prisma.usersWhoFollowVaults.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends UsersWhoFollowVaultsUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, UsersWhoFollowVaultsUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one UsersWhoFollowVaults.
     * @param {UsersWhoFollowVaultsUpsertArgs} args - Arguments to update or create a UsersWhoFollowVaults.
     * @example
     * // Update or create a UsersWhoFollowVaults
     * const usersWhoFollowVaults = await prisma.usersWhoFollowVaults.upsert({
     *   create: {
     *     // ... data to create a UsersWhoFollowVaults
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the UsersWhoFollowVaults we want to update
     *   }
     * })
    **/
    upsert<T extends UsersWhoFollowVaultsUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, UsersWhoFollowVaultsUpsertArgs<ExtArgs>>
    ): Prisma__UsersWhoFollowVaultsClient<$Types.GetResult<UsersWhoFollowVaultsPayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of UsersWhoFollowVaults.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsersWhoFollowVaultsCountArgs} args - Arguments to filter UsersWhoFollowVaults to count.
     * @example
     * // Count the number of UsersWhoFollowVaults
     * const count = await prisma.usersWhoFollowVaults.count({
     *   where: {
     *     // ... the filter for the UsersWhoFollowVaults we want to count
     *   }
     * })
    **/
    count<T extends UsersWhoFollowVaultsCountArgs>(
      args?: Subset<T, UsersWhoFollowVaultsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UsersWhoFollowVaultsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a UsersWhoFollowVaults.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsersWhoFollowVaultsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UsersWhoFollowVaultsAggregateArgs>(args: Subset<T, UsersWhoFollowVaultsAggregateArgs>): Prisma.PrismaPromise<GetUsersWhoFollowVaultsAggregateType<T>>

    /**
     * Group by UsersWhoFollowVaults.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsersWhoFollowVaultsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UsersWhoFollowVaultsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UsersWhoFollowVaultsGroupByArgs['orderBy'] }
        : { orderBy?: UsersWhoFollowVaultsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UsersWhoFollowVaultsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUsersWhoFollowVaultsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for UsersWhoFollowVaults.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__UsersWhoFollowVaultsClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * UsersWhoFollowVaults base type for findUnique actions
   */
  export type UsersWhoFollowVaultsFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UsersWhoFollowVaults
     */
    select?: UsersWhoFollowVaultsSelect<ExtArgs> | null
    /**
     * Filter, which UsersWhoFollowVaults to fetch.
     */
    where: UsersWhoFollowVaultsWhereUniqueInput
  }

  /**
   * UsersWhoFollowVaults findUnique
   */
  export interface UsersWhoFollowVaultsFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends UsersWhoFollowVaultsFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * UsersWhoFollowVaults findUniqueOrThrow
   */
  export type UsersWhoFollowVaultsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UsersWhoFollowVaults
     */
    select?: UsersWhoFollowVaultsSelect<ExtArgs> | null
    /**
     * Filter, which UsersWhoFollowVaults to fetch.
     */
    where: UsersWhoFollowVaultsWhereUniqueInput
  }


  /**
   * UsersWhoFollowVaults base type for findFirst actions
   */
  export type UsersWhoFollowVaultsFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UsersWhoFollowVaults
     */
    select?: UsersWhoFollowVaultsSelect<ExtArgs> | null
    /**
     * Filter, which UsersWhoFollowVaults to fetch.
     */
    where?: UsersWhoFollowVaultsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UsersWhoFollowVaults to fetch.
     */
    orderBy?: Enumerable<UsersWhoFollowVaultsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for UsersWhoFollowVaults.
     */
    cursor?: UsersWhoFollowVaultsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UsersWhoFollowVaults from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UsersWhoFollowVaults.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of UsersWhoFollowVaults.
     */
    distinct?: Enumerable<UsersWhoFollowVaultsScalarFieldEnum>
  }

  /**
   * UsersWhoFollowVaults findFirst
   */
  export interface UsersWhoFollowVaultsFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends UsersWhoFollowVaultsFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * UsersWhoFollowVaults findFirstOrThrow
   */
  export type UsersWhoFollowVaultsFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UsersWhoFollowVaults
     */
    select?: UsersWhoFollowVaultsSelect<ExtArgs> | null
    /**
     * Filter, which UsersWhoFollowVaults to fetch.
     */
    where?: UsersWhoFollowVaultsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UsersWhoFollowVaults to fetch.
     */
    orderBy?: Enumerable<UsersWhoFollowVaultsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for UsersWhoFollowVaults.
     */
    cursor?: UsersWhoFollowVaultsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UsersWhoFollowVaults from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UsersWhoFollowVaults.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of UsersWhoFollowVaults.
     */
    distinct?: Enumerable<UsersWhoFollowVaultsScalarFieldEnum>
  }


  /**
   * UsersWhoFollowVaults findMany
   */
  export type UsersWhoFollowVaultsFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UsersWhoFollowVaults
     */
    select?: UsersWhoFollowVaultsSelect<ExtArgs> | null
    /**
     * Filter, which UsersWhoFollowVaults to fetch.
     */
    where?: UsersWhoFollowVaultsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UsersWhoFollowVaults to fetch.
     */
    orderBy?: Enumerable<UsersWhoFollowVaultsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing UsersWhoFollowVaults.
     */
    cursor?: UsersWhoFollowVaultsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UsersWhoFollowVaults from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UsersWhoFollowVaults.
     */
    skip?: number
    distinct?: Enumerable<UsersWhoFollowVaultsScalarFieldEnum>
  }


  /**
   * UsersWhoFollowVaults create
   */
  export type UsersWhoFollowVaultsCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UsersWhoFollowVaults
     */
    select?: UsersWhoFollowVaultsSelect<ExtArgs> | null
    /**
     * The data needed to create a UsersWhoFollowVaults.
     */
    data: XOR<UsersWhoFollowVaultsCreateInput, UsersWhoFollowVaultsUncheckedCreateInput>
  }


  /**
   * UsersWhoFollowVaults createMany
   */
  export type UsersWhoFollowVaultsCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many UsersWhoFollowVaults.
     */
    data: Enumerable<UsersWhoFollowVaultsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * UsersWhoFollowVaults update
   */
  export type UsersWhoFollowVaultsUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UsersWhoFollowVaults
     */
    select?: UsersWhoFollowVaultsSelect<ExtArgs> | null
    /**
     * The data needed to update a UsersWhoFollowVaults.
     */
    data: XOR<UsersWhoFollowVaultsUpdateInput, UsersWhoFollowVaultsUncheckedUpdateInput>
    /**
     * Choose, which UsersWhoFollowVaults to update.
     */
    where: UsersWhoFollowVaultsWhereUniqueInput
  }


  /**
   * UsersWhoFollowVaults updateMany
   */
  export type UsersWhoFollowVaultsUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update UsersWhoFollowVaults.
     */
    data: XOR<UsersWhoFollowVaultsUpdateManyMutationInput, UsersWhoFollowVaultsUncheckedUpdateManyInput>
    /**
     * Filter which UsersWhoFollowVaults to update
     */
    where?: UsersWhoFollowVaultsWhereInput
  }


  /**
   * UsersWhoFollowVaults upsert
   */
  export type UsersWhoFollowVaultsUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UsersWhoFollowVaults
     */
    select?: UsersWhoFollowVaultsSelect<ExtArgs> | null
    /**
     * The filter to search for the UsersWhoFollowVaults to update in case it exists.
     */
    where: UsersWhoFollowVaultsWhereUniqueInput
    /**
     * In case the UsersWhoFollowVaults found by the `where` argument doesn't exist, create a new UsersWhoFollowVaults with this data.
     */
    create: XOR<UsersWhoFollowVaultsCreateInput, UsersWhoFollowVaultsUncheckedCreateInput>
    /**
     * In case the UsersWhoFollowVaults was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UsersWhoFollowVaultsUpdateInput, UsersWhoFollowVaultsUncheckedUpdateInput>
  }


  /**
   * UsersWhoFollowVaults delete
   */
  export type UsersWhoFollowVaultsDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UsersWhoFollowVaults
     */
    select?: UsersWhoFollowVaultsSelect<ExtArgs> | null
    /**
     * Filter which UsersWhoFollowVaults to delete.
     */
    where: UsersWhoFollowVaultsWhereUniqueInput
  }


  /**
   * UsersWhoFollowVaults deleteMany
   */
  export type UsersWhoFollowVaultsDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which UsersWhoFollowVaults to delete
     */
    where?: UsersWhoFollowVaultsWhereInput
  }


  /**
   * UsersWhoFollowVaults without action
   */
  export type UsersWhoFollowVaultsArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UsersWhoFollowVaults
     */
    select?: UsersWhoFollowVaultsSelect<ExtArgs> | null
  }



  /**
   * Model ProductHubItems
   */


  export type AggregateProductHubItems = {
    _count: ProductHubItemsCountAggregateOutputType | null
    _min: ProductHubItemsMinAggregateOutputType | null
    _max: ProductHubItemsMaxAggregateOutputType | null
  }

  export type ProductHubItemsMinAggregateOutputType = {
    id: string | null
    label: string | null
    network: NetworkNames | null
    primaryToken: string | null
    primaryTokenGroup: string | null
    protocol: Protocol | null
    secondaryToken: string | null
    secondaryTokenGroup: string | null
    weeklyNetApy: string | null
    depositToken: string | null
    earnStrategy: string | null
    fee: string | null
    liquidity: string | null
    managementType: ProductHubManagementSimple | null
    maxLtv: string | null
    maxMultiply: string | null
    multiplyStrategy: string | null
    multiplyStrategyType: ProductHubStrategy | null
    reverseTokens: boolean | null
    updatedAt: Date | null
  }

  export type ProductHubItemsMaxAggregateOutputType = {
    id: string | null
    label: string | null
    network: NetworkNames | null
    primaryToken: string | null
    primaryTokenGroup: string | null
    protocol: Protocol | null
    secondaryToken: string | null
    secondaryTokenGroup: string | null
    weeklyNetApy: string | null
    depositToken: string | null
    earnStrategy: string | null
    fee: string | null
    liquidity: string | null
    managementType: ProductHubManagementSimple | null
    maxLtv: string | null
    maxMultiply: string | null
    multiplyStrategy: string | null
    multiplyStrategyType: ProductHubStrategy | null
    reverseTokens: boolean | null
    updatedAt: Date | null
  }

  export type ProductHubItemsCountAggregateOutputType = {
    id: number
    label: number
    network: number
    primaryToken: number
    primaryTokenGroup: number
    product: number
    protocol: number
    secondaryToken: number
    secondaryTokenGroup: number
    weeklyNetApy: number
    depositToken: number
    earnStrategy: number
    fee: number
    liquidity: number
    managementType: number
    maxLtv: number
    maxMultiply: number
    multiplyStrategy: number
    multiplyStrategyType: number
    reverseTokens: number
    updatedAt: number
    _all: number
  }


  export type ProductHubItemsMinAggregateInputType = {
    id?: true
    label?: true
    network?: true
    primaryToken?: true
    primaryTokenGroup?: true
    protocol?: true
    secondaryToken?: true
    secondaryTokenGroup?: true
    weeklyNetApy?: true
    depositToken?: true
    earnStrategy?: true
    fee?: true
    liquidity?: true
    managementType?: true
    maxLtv?: true
    maxMultiply?: true
    multiplyStrategy?: true
    multiplyStrategyType?: true
    reverseTokens?: true
    updatedAt?: true
  }

  export type ProductHubItemsMaxAggregateInputType = {
    id?: true
    label?: true
    network?: true
    primaryToken?: true
    primaryTokenGroup?: true
    protocol?: true
    secondaryToken?: true
    secondaryTokenGroup?: true
    weeklyNetApy?: true
    depositToken?: true
    earnStrategy?: true
    fee?: true
    liquidity?: true
    managementType?: true
    maxLtv?: true
    maxMultiply?: true
    multiplyStrategy?: true
    multiplyStrategyType?: true
    reverseTokens?: true
    updatedAt?: true
  }

  export type ProductHubItemsCountAggregateInputType = {
    id?: true
    label?: true
    network?: true
    primaryToken?: true
    primaryTokenGroup?: true
    product?: true
    protocol?: true
    secondaryToken?: true
    secondaryTokenGroup?: true
    weeklyNetApy?: true
    depositToken?: true
    earnStrategy?: true
    fee?: true
    liquidity?: true
    managementType?: true
    maxLtv?: true
    maxMultiply?: true
    multiplyStrategy?: true
    multiplyStrategyType?: true
    reverseTokens?: true
    updatedAt?: true
    _all?: true
  }

  export type ProductHubItemsAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which ProductHubItems to aggregate.
     */
    where?: ProductHubItemsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ProductHubItems to fetch.
     */
    orderBy?: Enumerable<ProductHubItemsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ProductHubItemsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ProductHubItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ProductHubItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned ProductHubItems
    **/
    _count?: true | ProductHubItemsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ProductHubItemsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ProductHubItemsMaxAggregateInputType
  }

  export type GetProductHubItemsAggregateType<T extends ProductHubItemsAggregateArgs> = {
        [P in keyof T & keyof AggregateProductHubItems]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateProductHubItems[P]>
      : GetScalarType<T[P], AggregateProductHubItems[P]>
  }




  export type ProductHubItemsGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: ProductHubItemsWhereInput
    orderBy?: Enumerable<ProductHubItemsOrderByWithAggregationInput>
    by: ProductHubItemsScalarFieldEnum[]
    having?: ProductHubItemsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ProductHubItemsCountAggregateInputType | true
    _min?: ProductHubItemsMinAggregateInputType
    _max?: ProductHubItemsMaxAggregateInputType
  }


  export type ProductHubItemsGroupByOutputType = {
    id: string
    label: string
    network: NetworkNames
    primaryToken: string
    primaryTokenGroup: string | null
    product: Product[]
    protocol: Protocol
    secondaryToken: string
    secondaryTokenGroup: string | null
    weeklyNetApy: string | null
    depositToken: string | null
    earnStrategy: string | null
    fee: string | null
    liquidity: string | null
    managementType: ProductHubManagementSimple | null
    maxLtv: string | null
    maxMultiply: string | null
    multiplyStrategy: string | null
    multiplyStrategyType: ProductHubStrategy | null
    reverseTokens: boolean | null
    updatedAt: Date
    _count: ProductHubItemsCountAggregateOutputType | null
    _min: ProductHubItemsMinAggregateOutputType | null
    _max: ProductHubItemsMaxAggregateOutputType | null
  }

  type GetProductHubItemsGroupByPayload<T extends ProductHubItemsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<ProductHubItemsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ProductHubItemsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ProductHubItemsGroupByOutputType[P]>
            : GetScalarType<T[P], ProductHubItemsGroupByOutputType[P]>
        }
      >
    >


  export type ProductHubItemsSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    label?: boolean
    network?: boolean
    primaryToken?: boolean
    primaryTokenGroup?: boolean
    product?: boolean
    protocol?: boolean
    secondaryToken?: boolean
    secondaryTokenGroup?: boolean
    weeklyNetApy?: boolean
    depositToken?: boolean
    earnStrategy?: boolean
    fee?: boolean
    liquidity?: boolean
    managementType?: boolean
    maxLtv?: boolean
    maxMultiply?: boolean
    multiplyStrategy?: boolean
    multiplyStrategyType?: boolean
    reverseTokens?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["productHubItems"]>

  export type ProductHubItemsSelectScalar = {
    id?: boolean
    label?: boolean
    network?: boolean
    primaryToken?: boolean
    primaryTokenGroup?: boolean
    product?: boolean
    protocol?: boolean
    secondaryToken?: boolean
    secondaryTokenGroup?: boolean
    weeklyNetApy?: boolean
    depositToken?: boolean
    earnStrategy?: boolean
    fee?: boolean
    liquidity?: boolean
    managementType?: boolean
    maxLtv?: boolean
    maxMultiply?: boolean
    multiplyStrategy?: boolean
    multiplyStrategyType?: boolean
    reverseTokens?: boolean
    updatedAt?: boolean
  }


  type ProductHubItemsGetPayload<S extends boolean | null | undefined | ProductHubItemsArgs> = $Types.GetResult<ProductHubItemsPayload, S>

  type ProductHubItemsCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<ProductHubItemsFindManyArgs, 'select' | 'include'> & {
      select?: ProductHubItemsCountAggregateInputType | true
    }

  export interface ProductHubItemsDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['ProductHubItems'], meta: { name: 'ProductHubItems' } }
    /**
     * Find zero or one ProductHubItems that matches the filter.
     * @param {ProductHubItemsFindUniqueArgs} args - Arguments to find a ProductHubItems
     * @example
     * // Get one ProductHubItems
     * const productHubItems = await prisma.productHubItems.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends ProductHubItemsFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, ProductHubItemsFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'ProductHubItems'> extends True ? Prisma__ProductHubItemsClient<$Types.GetResult<ProductHubItemsPayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__ProductHubItemsClient<$Types.GetResult<ProductHubItemsPayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one ProductHubItems that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {ProductHubItemsFindUniqueOrThrowArgs} args - Arguments to find a ProductHubItems
     * @example
     * // Get one ProductHubItems
     * const productHubItems = await prisma.productHubItems.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends ProductHubItemsFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, ProductHubItemsFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__ProductHubItemsClient<$Types.GetResult<ProductHubItemsPayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first ProductHubItems that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductHubItemsFindFirstArgs} args - Arguments to find a ProductHubItems
     * @example
     * // Get one ProductHubItems
     * const productHubItems = await prisma.productHubItems.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends ProductHubItemsFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, ProductHubItemsFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'ProductHubItems'> extends True ? Prisma__ProductHubItemsClient<$Types.GetResult<ProductHubItemsPayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__ProductHubItemsClient<$Types.GetResult<ProductHubItemsPayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first ProductHubItems that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductHubItemsFindFirstOrThrowArgs} args - Arguments to find a ProductHubItems
     * @example
     * // Get one ProductHubItems
     * const productHubItems = await prisma.productHubItems.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends ProductHubItemsFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, ProductHubItemsFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__ProductHubItemsClient<$Types.GetResult<ProductHubItemsPayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more ProductHubItems that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductHubItemsFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all ProductHubItems
     * const productHubItems = await prisma.productHubItems.findMany()
     * 
     * // Get first 10 ProductHubItems
     * const productHubItems = await prisma.productHubItems.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const productHubItemsWithIdOnly = await prisma.productHubItems.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends ProductHubItemsFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ProductHubItemsFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<ProductHubItemsPayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a ProductHubItems.
     * @param {ProductHubItemsCreateArgs} args - Arguments to create a ProductHubItems.
     * @example
     * // Create one ProductHubItems
     * const ProductHubItems = await prisma.productHubItems.create({
     *   data: {
     *     // ... data to create a ProductHubItems
     *   }
     * })
     * 
    **/
    create<T extends ProductHubItemsCreateArgs<ExtArgs>>(
      args: SelectSubset<T, ProductHubItemsCreateArgs<ExtArgs>>
    ): Prisma__ProductHubItemsClient<$Types.GetResult<ProductHubItemsPayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many ProductHubItems.
     *     @param {ProductHubItemsCreateManyArgs} args - Arguments to create many ProductHubItems.
     *     @example
     *     // Create many ProductHubItems
     *     const productHubItems = await prisma.productHubItems.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends ProductHubItemsCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ProductHubItemsCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a ProductHubItems.
     * @param {ProductHubItemsDeleteArgs} args - Arguments to delete one ProductHubItems.
     * @example
     * // Delete one ProductHubItems
     * const ProductHubItems = await prisma.productHubItems.delete({
     *   where: {
     *     // ... filter to delete one ProductHubItems
     *   }
     * })
     * 
    **/
    delete<T extends ProductHubItemsDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, ProductHubItemsDeleteArgs<ExtArgs>>
    ): Prisma__ProductHubItemsClient<$Types.GetResult<ProductHubItemsPayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one ProductHubItems.
     * @param {ProductHubItemsUpdateArgs} args - Arguments to update one ProductHubItems.
     * @example
     * // Update one ProductHubItems
     * const productHubItems = await prisma.productHubItems.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends ProductHubItemsUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, ProductHubItemsUpdateArgs<ExtArgs>>
    ): Prisma__ProductHubItemsClient<$Types.GetResult<ProductHubItemsPayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more ProductHubItems.
     * @param {ProductHubItemsDeleteManyArgs} args - Arguments to filter ProductHubItems to delete.
     * @example
     * // Delete a few ProductHubItems
     * const { count } = await prisma.productHubItems.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends ProductHubItemsDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, ProductHubItemsDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ProductHubItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductHubItemsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many ProductHubItems
     * const productHubItems = await prisma.productHubItems.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends ProductHubItemsUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, ProductHubItemsUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one ProductHubItems.
     * @param {ProductHubItemsUpsertArgs} args - Arguments to update or create a ProductHubItems.
     * @example
     * // Update or create a ProductHubItems
     * const productHubItems = await prisma.productHubItems.upsert({
     *   create: {
     *     // ... data to create a ProductHubItems
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the ProductHubItems we want to update
     *   }
     * })
    **/
    upsert<T extends ProductHubItemsUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, ProductHubItemsUpsertArgs<ExtArgs>>
    ): Prisma__ProductHubItemsClient<$Types.GetResult<ProductHubItemsPayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of ProductHubItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductHubItemsCountArgs} args - Arguments to filter ProductHubItems to count.
     * @example
     * // Count the number of ProductHubItems
     * const count = await prisma.productHubItems.count({
     *   where: {
     *     // ... the filter for the ProductHubItems we want to count
     *   }
     * })
    **/
    count<T extends ProductHubItemsCountArgs>(
      args?: Subset<T, ProductHubItemsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ProductHubItemsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a ProductHubItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductHubItemsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ProductHubItemsAggregateArgs>(args: Subset<T, ProductHubItemsAggregateArgs>): Prisma.PrismaPromise<GetProductHubItemsAggregateType<T>>

    /**
     * Group by ProductHubItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductHubItemsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ProductHubItemsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ProductHubItemsGroupByArgs['orderBy'] }
        : { orderBy?: ProductHubItemsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ProductHubItemsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetProductHubItemsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for ProductHubItems.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__ProductHubItemsClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * ProductHubItems base type for findUnique actions
   */
  export type ProductHubItemsFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProductHubItems
     */
    select?: ProductHubItemsSelect<ExtArgs> | null
    /**
     * Filter, which ProductHubItems to fetch.
     */
    where: ProductHubItemsWhereUniqueInput
  }

  /**
   * ProductHubItems findUnique
   */
  export interface ProductHubItemsFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends ProductHubItemsFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * ProductHubItems findUniqueOrThrow
   */
  export type ProductHubItemsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProductHubItems
     */
    select?: ProductHubItemsSelect<ExtArgs> | null
    /**
     * Filter, which ProductHubItems to fetch.
     */
    where: ProductHubItemsWhereUniqueInput
  }


  /**
   * ProductHubItems base type for findFirst actions
   */
  export type ProductHubItemsFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProductHubItems
     */
    select?: ProductHubItemsSelect<ExtArgs> | null
    /**
     * Filter, which ProductHubItems to fetch.
     */
    where?: ProductHubItemsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ProductHubItems to fetch.
     */
    orderBy?: Enumerable<ProductHubItemsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ProductHubItems.
     */
    cursor?: ProductHubItemsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ProductHubItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ProductHubItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ProductHubItems.
     */
    distinct?: Enumerable<ProductHubItemsScalarFieldEnum>
  }

  /**
   * ProductHubItems findFirst
   */
  export interface ProductHubItemsFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends ProductHubItemsFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * ProductHubItems findFirstOrThrow
   */
  export type ProductHubItemsFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProductHubItems
     */
    select?: ProductHubItemsSelect<ExtArgs> | null
    /**
     * Filter, which ProductHubItems to fetch.
     */
    where?: ProductHubItemsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ProductHubItems to fetch.
     */
    orderBy?: Enumerable<ProductHubItemsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ProductHubItems.
     */
    cursor?: ProductHubItemsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ProductHubItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ProductHubItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ProductHubItems.
     */
    distinct?: Enumerable<ProductHubItemsScalarFieldEnum>
  }


  /**
   * ProductHubItems findMany
   */
  export type ProductHubItemsFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProductHubItems
     */
    select?: ProductHubItemsSelect<ExtArgs> | null
    /**
     * Filter, which ProductHubItems to fetch.
     */
    where?: ProductHubItemsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ProductHubItems to fetch.
     */
    orderBy?: Enumerable<ProductHubItemsOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing ProductHubItems.
     */
    cursor?: ProductHubItemsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ProductHubItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ProductHubItems.
     */
    skip?: number
    distinct?: Enumerable<ProductHubItemsScalarFieldEnum>
  }


  /**
   * ProductHubItems create
   */
  export type ProductHubItemsCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProductHubItems
     */
    select?: ProductHubItemsSelect<ExtArgs> | null
    /**
     * The data needed to create a ProductHubItems.
     */
    data: XOR<ProductHubItemsCreateInput, ProductHubItemsUncheckedCreateInput>
  }


  /**
   * ProductHubItems createMany
   */
  export type ProductHubItemsCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many ProductHubItems.
     */
    data: Enumerable<ProductHubItemsCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * ProductHubItems update
   */
  export type ProductHubItemsUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProductHubItems
     */
    select?: ProductHubItemsSelect<ExtArgs> | null
    /**
     * The data needed to update a ProductHubItems.
     */
    data: XOR<ProductHubItemsUpdateInput, ProductHubItemsUncheckedUpdateInput>
    /**
     * Choose, which ProductHubItems to update.
     */
    where: ProductHubItemsWhereUniqueInput
  }


  /**
   * ProductHubItems updateMany
   */
  export type ProductHubItemsUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update ProductHubItems.
     */
    data: XOR<ProductHubItemsUpdateManyMutationInput, ProductHubItemsUncheckedUpdateManyInput>
    /**
     * Filter which ProductHubItems to update
     */
    where?: ProductHubItemsWhereInput
  }


  /**
   * ProductHubItems upsert
   */
  export type ProductHubItemsUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProductHubItems
     */
    select?: ProductHubItemsSelect<ExtArgs> | null
    /**
     * The filter to search for the ProductHubItems to update in case it exists.
     */
    where: ProductHubItemsWhereUniqueInput
    /**
     * In case the ProductHubItems found by the `where` argument doesn't exist, create a new ProductHubItems with this data.
     */
    create: XOR<ProductHubItemsCreateInput, ProductHubItemsUncheckedCreateInput>
    /**
     * In case the ProductHubItems was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ProductHubItemsUpdateInput, ProductHubItemsUncheckedUpdateInput>
  }


  /**
   * ProductHubItems delete
   */
  export type ProductHubItemsDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProductHubItems
     */
    select?: ProductHubItemsSelect<ExtArgs> | null
    /**
     * Filter which ProductHubItems to delete.
     */
    where: ProductHubItemsWhereUniqueInput
  }


  /**
   * ProductHubItems deleteMany
   */
  export type ProductHubItemsDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which ProductHubItems to delete
     */
    where?: ProductHubItemsWhereInput
  }


  /**
   * ProductHubItems without action
   */
  export type ProductHubItemsArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProductHubItems
     */
    select?: ProductHubItemsSelect<ExtArgs> | null
  }



  /**
   * Model AjnaRewardsWeeklyClaim
   */


  export type AggregateAjnaRewardsWeeklyClaim = {
    _count: AjnaRewardsWeeklyClaimCountAggregateOutputType | null
    _avg: AjnaRewardsWeeklyClaimAvgAggregateOutputType | null
    _sum: AjnaRewardsWeeklyClaimSumAggregateOutputType | null
    _min: AjnaRewardsWeeklyClaimMinAggregateOutputType | null
    _max: AjnaRewardsWeeklyClaimMaxAggregateOutputType | null
  }

  export type AjnaRewardsWeeklyClaimAvgAggregateOutputType = {
    id: number | null
    chain_id: number | null
    week_number: number | null
  }

  export type AjnaRewardsWeeklyClaimSumAggregateOutputType = {
    id: number | null
    chain_id: number | null
    week_number: number | null
  }

  export type AjnaRewardsWeeklyClaimMinAggregateOutputType = {
    id: number | null
    timestamp: Date | null
    chain_id: number | null
    user_address: string | null
    amount: string | null
    week_number: number | null
  }

  export type AjnaRewardsWeeklyClaimMaxAggregateOutputType = {
    id: number | null
    timestamp: Date | null
    chain_id: number | null
    user_address: string | null
    amount: string | null
    week_number: number | null
  }

  export type AjnaRewardsWeeklyClaimCountAggregateOutputType = {
    id: number
    timestamp: number
    chain_id: number
    user_address: number
    amount: number
    week_number: number
    proof: number
    _all: number
  }


  export type AjnaRewardsWeeklyClaimAvgAggregateInputType = {
    id?: true
    chain_id?: true
    week_number?: true
  }

  export type AjnaRewardsWeeklyClaimSumAggregateInputType = {
    id?: true
    chain_id?: true
    week_number?: true
  }

  export type AjnaRewardsWeeklyClaimMinAggregateInputType = {
    id?: true
    timestamp?: true
    chain_id?: true
    user_address?: true
    amount?: true
    week_number?: true
  }

  export type AjnaRewardsWeeklyClaimMaxAggregateInputType = {
    id?: true
    timestamp?: true
    chain_id?: true
    user_address?: true
    amount?: true
    week_number?: true
  }

  export type AjnaRewardsWeeklyClaimCountAggregateInputType = {
    id?: true
    timestamp?: true
    chain_id?: true
    user_address?: true
    amount?: true
    week_number?: true
    proof?: true
    _all?: true
  }

  export type AjnaRewardsWeeklyClaimAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which AjnaRewardsWeeklyClaim to aggregate.
     */
    where?: AjnaRewardsWeeklyClaimWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AjnaRewardsWeeklyClaims to fetch.
     */
    orderBy?: Enumerable<AjnaRewardsWeeklyClaimOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AjnaRewardsWeeklyClaimWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AjnaRewardsWeeklyClaims from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AjnaRewardsWeeklyClaims.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned AjnaRewardsWeeklyClaims
    **/
    _count?: true | AjnaRewardsWeeklyClaimCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: AjnaRewardsWeeklyClaimAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: AjnaRewardsWeeklyClaimSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AjnaRewardsWeeklyClaimMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AjnaRewardsWeeklyClaimMaxAggregateInputType
  }

  export type GetAjnaRewardsWeeklyClaimAggregateType<T extends AjnaRewardsWeeklyClaimAggregateArgs> = {
        [P in keyof T & keyof AggregateAjnaRewardsWeeklyClaim]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAjnaRewardsWeeklyClaim[P]>
      : GetScalarType<T[P], AggregateAjnaRewardsWeeklyClaim[P]>
  }




  export type AjnaRewardsWeeklyClaimGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: AjnaRewardsWeeklyClaimWhereInput
    orderBy?: Enumerable<AjnaRewardsWeeklyClaimOrderByWithAggregationInput>
    by: AjnaRewardsWeeklyClaimScalarFieldEnum[]
    having?: AjnaRewardsWeeklyClaimScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AjnaRewardsWeeklyClaimCountAggregateInputType | true
    _avg?: AjnaRewardsWeeklyClaimAvgAggregateInputType
    _sum?: AjnaRewardsWeeklyClaimSumAggregateInputType
    _min?: AjnaRewardsWeeklyClaimMinAggregateInputType
    _max?: AjnaRewardsWeeklyClaimMaxAggregateInputType
  }


  export type AjnaRewardsWeeklyClaimGroupByOutputType = {
    id: number
    timestamp: Date
    chain_id: number
    user_address: string
    amount: string
    week_number: number
    proof: string[]
    _count: AjnaRewardsWeeklyClaimCountAggregateOutputType | null
    _avg: AjnaRewardsWeeklyClaimAvgAggregateOutputType | null
    _sum: AjnaRewardsWeeklyClaimSumAggregateOutputType | null
    _min: AjnaRewardsWeeklyClaimMinAggregateOutputType | null
    _max: AjnaRewardsWeeklyClaimMaxAggregateOutputType | null
  }

  type GetAjnaRewardsWeeklyClaimGroupByPayload<T extends AjnaRewardsWeeklyClaimGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<AjnaRewardsWeeklyClaimGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AjnaRewardsWeeklyClaimGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AjnaRewardsWeeklyClaimGroupByOutputType[P]>
            : GetScalarType<T[P], AjnaRewardsWeeklyClaimGroupByOutputType[P]>
        }
      >
    >


  export type AjnaRewardsWeeklyClaimSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    timestamp?: boolean
    chain_id?: boolean
    user_address?: boolean
    amount?: boolean
    week_number?: boolean
    proof?: boolean
  }, ExtArgs["result"]["ajnaRewardsWeeklyClaim"]>

  export type AjnaRewardsWeeklyClaimSelectScalar = {
    id?: boolean
    timestamp?: boolean
    chain_id?: boolean
    user_address?: boolean
    amount?: boolean
    week_number?: boolean
    proof?: boolean
  }


  type AjnaRewardsWeeklyClaimGetPayload<S extends boolean | null | undefined | AjnaRewardsWeeklyClaimArgs> = $Types.GetResult<AjnaRewardsWeeklyClaimPayload, S>

  type AjnaRewardsWeeklyClaimCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<AjnaRewardsWeeklyClaimFindManyArgs, 'select' | 'include'> & {
      select?: AjnaRewardsWeeklyClaimCountAggregateInputType | true
    }

  export interface AjnaRewardsWeeklyClaimDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['AjnaRewardsWeeklyClaim'], meta: { name: 'AjnaRewardsWeeklyClaim' } }
    /**
     * Find zero or one AjnaRewardsWeeklyClaim that matches the filter.
     * @param {AjnaRewardsWeeklyClaimFindUniqueArgs} args - Arguments to find a AjnaRewardsWeeklyClaim
     * @example
     * // Get one AjnaRewardsWeeklyClaim
     * const ajnaRewardsWeeklyClaim = await prisma.ajnaRewardsWeeklyClaim.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends AjnaRewardsWeeklyClaimFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, AjnaRewardsWeeklyClaimFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'AjnaRewardsWeeklyClaim'> extends True ? Prisma__AjnaRewardsWeeklyClaimClient<$Types.GetResult<AjnaRewardsWeeklyClaimPayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__AjnaRewardsWeeklyClaimClient<$Types.GetResult<AjnaRewardsWeeklyClaimPayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one AjnaRewardsWeeklyClaim that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {AjnaRewardsWeeklyClaimFindUniqueOrThrowArgs} args - Arguments to find a AjnaRewardsWeeklyClaim
     * @example
     * // Get one AjnaRewardsWeeklyClaim
     * const ajnaRewardsWeeklyClaim = await prisma.ajnaRewardsWeeklyClaim.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends AjnaRewardsWeeklyClaimFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, AjnaRewardsWeeklyClaimFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__AjnaRewardsWeeklyClaimClient<$Types.GetResult<AjnaRewardsWeeklyClaimPayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first AjnaRewardsWeeklyClaim that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsWeeklyClaimFindFirstArgs} args - Arguments to find a AjnaRewardsWeeklyClaim
     * @example
     * // Get one AjnaRewardsWeeklyClaim
     * const ajnaRewardsWeeklyClaim = await prisma.ajnaRewardsWeeklyClaim.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends AjnaRewardsWeeklyClaimFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, AjnaRewardsWeeklyClaimFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'AjnaRewardsWeeklyClaim'> extends True ? Prisma__AjnaRewardsWeeklyClaimClient<$Types.GetResult<AjnaRewardsWeeklyClaimPayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__AjnaRewardsWeeklyClaimClient<$Types.GetResult<AjnaRewardsWeeklyClaimPayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first AjnaRewardsWeeklyClaim that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsWeeklyClaimFindFirstOrThrowArgs} args - Arguments to find a AjnaRewardsWeeklyClaim
     * @example
     * // Get one AjnaRewardsWeeklyClaim
     * const ajnaRewardsWeeklyClaim = await prisma.ajnaRewardsWeeklyClaim.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends AjnaRewardsWeeklyClaimFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, AjnaRewardsWeeklyClaimFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__AjnaRewardsWeeklyClaimClient<$Types.GetResult<AjnaRewardsWeeklyClaimPayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more AjnaRewardsWeeklyClaims that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsWeeklyClaimFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all AjnaRewardsWeeklyClaims
     * const ajnaRewardsWeeklyClaims = await prisma.ajnaRewardsWeeklyClaim.findMany()
     * 
     * // Get first 10 AjnaRewardsWeeklyClaims
     * const ajnaRewardsWeeklyClaims = await prisma.ajnaRewardsWeeklyClaim.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const ajnaRewardsWeeklyClaimWithIdOnly = await prisma.ajnaRewardsWeeklyClaim.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends AjnaRewardsWeeklyClaimFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, AjnaRewardsWeeklyClaimFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<AjnaRewardsWeeklyClaimPayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a AjnaRewardsWeeklyClaim.
     * @param {AjnaRewardsWeeklyClaimCreateArgs} args - Arguments to create a AjnaRewardsWeeklyClaim.
     * @example
     * // Create one AjnaRewardsWeeklyClaim
     * const AjnaRewardsWeeklyClaim = await prisma.ajnaRewardsWeeklyClaim.create({
     *   data: {
     *     // ... data to create a AjnaRewardsWeeklyClaim
     *   }
     * })
     * 
    **/
    create<T extends AjnaRewardsWeeklyClaimCreateArgs<ExtArgs>>(
      args: SelectSubset<T, AjnaRewardsWeeklyClaimCreateArgs<ExtArgs>>
    ): Prisma__AjnaRewardsWeeklyClaimClient<$Types.GetResult<AjnaRewardsWeeklyClaimPayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many AjnaRewardsWeeklyClaims.
     *     @param {AjnaRewardsWeeklyClaimCreateManyArgs} args - Arguments to create many AjnaRewardsWeeklyClaims.
     *     @example
     *     // Create many AjnaRewardsWeeklyClaims
     *     const ajnaRewardsWeeklyClaim = await prisma.ajnaRewardsWeeklyClaim.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends AjnaRewardsWeeklyClaimCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, AjnaRewardsWeeklyClaimCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a AjnaRewardsWeeklyClaim.
     * @param {AjnaRewardsWeeklyClaimDeleteArgs} args - Arguments to delete one AjnaRewardsWeeklyClaim.
     * @example
     * // Delete one AjnaRewardsWeeklyClaim
     * const AjnaRewardsWeeklyClaim = await prisma.ajnaRewardsWeeklyClaim.delete({
     *   where: {
     *     // ... filter to delete one AjnaRewardsWeeklyClaim
     *   }
     * })
     * 
    **/
    delete<T extends AjnaRewardsWeeklyClaimDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, AjnaRewardsWeeklyClaimDeleteArgs<ExtArgs>>
    ): Prisma__AjnaRewardsWeeklyClaimClient<$Types.GetResult<AjnaRewardsWeeklyClaimPayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one AjnaRewardsWeeklyClaim.
     * @param {AjnaRewardsWeeklyClaimUpdateArgs} args - Arguments to update one AjnaRewardsWeeklyClaim.
     * @example
     * // Update one AjnaRewardsWeeklyClaim
     * const ajnaRewardsWeeklyClaim = await prisma.ajnaRewardsWeeklyClaim.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends AjnaRewardsWeeklyClaimUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, AjnaRewardsWeeklyClaimUpdateArgs<ExtArgs>>
    ): Prisma__AjnaRewardsWeeklyClaimClient<$Types.GetResult<AjnaRewardsWeeklyClaimPayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more AjnaRewardsWeeklyClaims.
     * @param {AjnaRewardsWeeklyClaimDeleteManyArgs} args - Arguments to filter AjnaRewardsWeeklyClaims to delete.
     * @example
     * // Delete a few AjnaRewardsWeeklyClaims
     * const { count } = await prisma.ajnaRewardsWeeklyClaim.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends AjnaRewardsWeeklyClaimDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, AjnaRewardsWeeklyClaimDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AjnaRewardsWeeklyClaims.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsWeeklyClaimUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many AjnaRewardsWeeklyClaims
     * const ajnaRewardsWeeklyClaim = await prisma.ajnaRewardsWeeklyClaim.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends AjnaRewardsWeeklyClaimUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, AjnaRewardsWeeklyClaimUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one AjnaRewardsWeeklyClaim.
     * @param {AjnaRewardsWeeklyClaimUpsertArgs} args - Arguments to update or create a AjnaRewardsWeeklyClaim.
     * @example
     * // Update or create a AjnaRewardsWeeklyClaim
     * const ajnaRewardsWeeklyClaim = await prisma.ajnaRewardsWeeklyClaim.upsert({
     *   create: {
     *     // ... data to create a AjnaRewardsWeeklyClaim
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the AjnaRewardsWeeklyClaim we want to update
     *   }
     * })
    **/
    upsert<T extends AjnaRewardsWeeklyClaimUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, AjnaRewardsWeeklyClaimUpsertArgs<ExtArgs>>
    ): Prisma__AjnaRewardsWeeklyClaimClient<$Types.GetResult<AjnaRewardsWeeklyClaimPayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of AjnaRewardsWeeklyClaims.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsWeeklyClaimCountArgs} args - Arguments to filter AjnaRewardsWeeklyClaims to count.
     * @example
     * // Count the number of AjnaRewardsWeeklyClaims
     * const count = await prisma.ajnaRewardsWeeklyClaim.count({
     *   where: {
     *     // ... the filter for the AjnaRewardsWeeklyClaims we want to count
     *   }
     * })
    **/
    count<T extends AjnaRewardsWeeklyClaimCountArgs>(
      args?: Subset<T, AjnaRewardsWeeklyClaimCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AjnaRewardsWeeklyClaimCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a AjnaRewardsWeeklyClaim.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsWeeklyClaimAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AjnaRewardsWeeklyClaimAggregateArgs>(args: Subset<T, AjnaRewardsWeeklyClaimAggregateArgs>): Prisma.PrismaPromise<GetAjnaRewardsWeeklyClaimAggregateType<T>>

    /**
     * Group by AjnaRewardsWeeklyClaim.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsWeeklyClaimGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AjnaRewardsWeeklyClaimGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AjnaRewardsWeeklyClaimGroupByArgs['orderBy'] }
        : { orderBy?: AjnaRewardsWeeklyClaimGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AjnaRewardsWeeklyClaimGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAjnaRewardsWeeklyClaimGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for AjnaRewardsWeeklyClaim.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__AjnaRewardsWeeklyClaimClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * AjnaRewardsWeeklyClaim base type for findUnique actions
   */
  export type AjnaRewardsWeeklyClaimFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsWeeklyClaim
     */
    select?: AjnaRewardsWeeklyClaimSelect<ExtArgs> | null
    /**
     * Filter, which AjnaRewardsWeeklyClaim to fetch.
     */
    where: AjnaRewardsWeeklyClaimWhereUniqueInput
  }

  /**
   * AjnaRewardsWeeklyClaim findUnique
   */
  export interface AjnaRewardsWeeklyClaimFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends AjnaRewardsWeeklyClaimFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * AjnaRewardsWeeklyClaim findUniqueOrThrow
   */
  export type AjnaRewardsWeeklyClaimFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsWeeklyClaim
     */
    select?: AjnaRewardsWeeklyClaimSelect<ExtArgs> | null
    /**
     * Filter, which AjnaRewardsWeeklyClaim to fetch.
     */
    where: AjnaRewardsWeeklyClaimWhereUniqueInput
  }


  /**
   * AjnaRewardsWeeklyClaim base type for findFirst actions
   */
  export type AjnaRewardsWeeklyClaimFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsWeeklyClaim
     */
    select?: AjnaRewardsWeeklyClaimSelect<ExtArgs> | null
    /**
     * Filter, which AjnaRewardsWeeklyClaim to fetch.
     */
    where?: AjnaRewardsWeeklyClaimWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AjnaRewardsWeeklyClaims to fetch.
     */
    orderBy?: Enumerable<AjnaRewardsWeeklyClaimOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AjnaRewardsWeeklyClaims.
     */
    cursor?: AjnaRewardsWeeklyClaimWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AjnaRewardsWeeklyClaims from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AjnaRewardsWeeklyClaims.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AjnaRewardsWeeklyClaims.
     */
    distinct?: Enumerable<AjnaRewardsWeeklyClaimScalarFieldEnum>
  }

  /**
   * AjnaRewardsWeeklyClaim findFirst
   */
  export interface AjnaRewardsWeeklyClaimFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends AjnaRewardsWeeklyClaimFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * AjnaRewardsWeeklyClaim findFirstOrThrow
   */
  export type AjnaRewardsWeeklyClaimFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsWeeklyClaim
     */
    select?: AjnaRewardsWeeklyClaimSelect<ExtArgs> | null
    /**
     * Filter, which AjnaRewardsWeeklyClaim to fetch.
     */
    where?: AjnaRewardsWeeklyClaimWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AjnaRewardsWeeklyClaims to fetch.
     */
    orderBy?: Enumerable<AjnaRewardsWeeklyClaimOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AjnaRewardsWeeklyClaims.
     */
    cursor?: AjnaRewardsWeeklyClaimWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AjnaRewardsWeeklyClaims from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AjnaRewardsWeeklyClaims.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AjnaRewardsWeeklyClaims.
     */
    distinct?: Enumerable<AjnaRewardsWeeklyClaimScalarFieldEnum>
  }


  /**
   * AjnaRewardsWeeklyClaim findMany
   */
  export type AjnaRewardsWeeklyClaimFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsWeeklyClaim
     */
    select?: AjnaRewardsWeeklyClaimSelect<ExtArgs> | null
    /**
     * Filter, which AjnaRewardsWeeklyClaims to fetch.
     */
    where?: AjnaRewardsWeeklyClaimWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AjnaRewardsWeeklyClaims to fetch.
     */
    orderBy?: Enumerable<AjnaRewardsWeeklyClaimOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing AjnaRewardsWeeklyClaims.
     */
    cursor?: AjnaRewardsWeeklyClaimWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AjnaRewardsWeeklyClaims from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AjnaRewardsWeeklyClaims.
     */
    skip?: number
    distinct?: Enumerable<AjnaRewardsWeeklyClaimScalarFieldEnum>
  }


  /**
   * AjnaRewardsWeeklyClaim create
   */
  export type AjnaRewardsWeeklyClaimCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsWeeklyClaim
     */
    select?: AjnaRewardsWeeklyClaimSelect<ExtArgs> | null
    /**
     * The data needed to create a AjnaRewardsWeeklyClaim.
     */
    data: XOR<AjnaRewardsWeeklyClaimCreateInput, AjnaRewardsWeeklyClaimUncheckedCreateInput>
  }


  /**
   * AjnaRewardsWeeklyClaim createMany
   */
  export type AjnaRewardsWeeklyClaimCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many AjnaRewardsWeeklyClaims.
     */
    data: Enumerable<AjnaRewardsWeeklyClaimCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * AjnaRewardsWeeklyClaim update
   */
  export type AjnaRewardsWeeklyClaimUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsWeeklyClaim
     */
    select?: AjnaRewardsWeeklyClaimSelect<ExtArgs> | null
    /**
     * The data needed to update a AjnaRewardsWeeklyClaim.
     */
    data: XOR<AjnaRewardsWeeklyClaimUpdateInput, AjnaRewardsWeeklyClaimUncheckedUpdateInput>
    /**
     * Choose, which AjnaRewardsWeeklyClaim to update.
     */
    where: AjnaRewardsWeeklyClaimWhereUniqueInput
  }


  /**
   * AjnaRewardsWeeklyClaim updateMany
   */
  export type AjnaRewardsWeeklyClaimUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update AjnaRewardsWeeklyClaims.
     */
    data: XOR<AjnaRewardsWeeklyClaimUpdateManyMutationInput, AjnaRewardsWeeklyClaimUncheckedUpdateManyInput>
    /**
     * Filter which AjnaRewardsWeeklyClaims to update
     */
    where?: AjnaRewardsWeeklyClaimWhereInput
  }


  /**
   * AjnaRewardsWeeklyClaim upsert
   */
  export type AjnaRewardsWeeklyClaimUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsWeeklyClaim
     */
    select?: AjnaRewardsWeeklyClaimSelect<ExtArgs> | null
    /**
     * The filter to search for the AjnaRewardsWeeklyClaim to update in case it exists.
     */
    where: AjnaRewardsWeeklyClaimWhereUniqueInput
    /**
     * In case the AjnaRewardsWeeklyClaim found by the `where` argument doesn't exist, create a new AjnaRewardsWeeklyClaim with this data.
     */
    create: XOR<AjnaRewardsWeeklyClaimCreateInput, AjnaRewardsWeeklyClaimUncheckedCreateInput>
    /**
     * In case the AjnaRewardsWeeklyClaim was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AjnaRewardsWeeklyClaimUpdateInput, AjnaRewardsWeeklyClaimUncheckedUpdateInput>
  }


  /**
   * AjnaRewardsWeeklyClaim delete
   */
  export type AjnaRewardsWeeklyClaimDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsWeeklyClaim
     */
    select?: AjnaRewardsWeeklyClaimSelect<ExtArgs> | null
    /**
     * Filter which AjnaRewardsWeeklyClaim to delete.
     */
    where: AjnaRewardsWeeklyClaimWhereUniqueInput
  }


  /**
   * AjnaRewardsWeeklyClaim deleteMany
   */
  export type AjnaRewardsWeeklyClaimDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which AjnaRewardsWeeklyClaims to delete
     */
    where?: AjnaRewardsWeeklyClaimWhereInput
  }


  /**
   * AjnaRewardsWeeklyClaim without action
   */
  export type AjnaRewardsWeeklyClaimArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsWeeklyClaim
     */
    select?: AjnaRewardsWeeklyClaimSelect<ExtArgs> | null
  }



  /**
   * Model AjnaRewardsDailyClaim
   */


  export type AggregateAjnaRewardsDailyClaim = {
    _count: AjnaRewardsDailyClaimCountAggregateOutputType | null
    _avg: AjnaRewardsDailyClaimAvgAggregateOutputType | null
    _sum: AjnaRewardsDailyClaimSumAggregateOutputType | null
    _min: AjnaRewardsDailyClaimMinAggregateOutputType | null
    _max: AjnaRewardsDailyClaimMaxAggregateOutputType | null
  }

  export type AjnaRewardsDailyClaimAvgAggregateOutputType = {
    id: number | null
    chain_id: number | null
    week_number: number | null
    day_number: number | null
  }

  export type AjnaRewardsDailyClaimSumAggregateOutputType = {
    id: number | null
    chain_id: number | null
    week_number: number | null
    day_number: number | null
  }

  export type AjnaRewardsDailyClaimMinAggregateOutputType = {
    id: number | null
    timestamp: Date | null
    chain_id: number | null
    user_address: string | null
    amount: string | null
    week_number: number | null
    day_number: number | null
  }

  export type AjnaRewardsDailyClaimMaxAggregateOutputType = {
    id: number | null
    timestamp: Date | null
    chain_id: number | null
    user_address: string | null
    amount: string | null
    week_number: number | null
    day_number: number | null
  }

  export type AjnaRewardsDailyClaimCountAggregateOutputType = {
    id: number
    timestamp: number
    chain_id: number
    user_address: number
    amount: number
    week_number: number
    day_number: number
    _all: number
  }


  export type AjnaRewardsDailyClaimAvgAggregateInputType = {
    id?: true
    chain_id?: true
    week_number?: true
    day_number?: true
  }

  export type AjnaRewardsDailyClaimSumAggregateInputType = {
    id?: true
    chain_id?: true
    week_number?: true
    day_number?: true
  }

  export type AjnaRewardsDailyClaimMinAggregateInputType = {
    id?: true
    timestamp?: true
    chain_id?: true
    user_address?: true
    amount?: true
    week_number?: true
    day_number?: true
  }

  export type AjnaRewardsDailyClaimMaxAggregateInputType = {
    id?: true
    timestamp?: true
    chain_id?: true
    user_address?: true
    amount?: true
    week_number?: true
    day_number?: true
  }

  export type AjnaRewardsDailyClaimCountAggregateInputType = {
    id?: true
    timestamp?: true
    chain_id?: true
    user_address?: true
    amount?: true
    week_number?: true
    day_number?: true
    _all?: true
  }

  export type AjnaRewardsDailyClaimAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which AjnaRewardsDailyClaim to aggregate.
     */
    where?: AjnaRewardsDailyClaimWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AjnaRewardsDailyClaims to fetch.
     */
    orderBy?: Enumerable<AjnaRewardsDailyClaimOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AjnaRewardsDailyClaimWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AjnaRewardsDailyClaims from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AjnaRewardsDailyClaims.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned AjnaRewardsDailyClaims
    **/
    _count?: true | AjnaRewardsDailyClaimCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: AjnaRewardsDailyClaimAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: AjnaRewardsDailyClaimSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AjnaRewardsDailyClaimMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AjnaRewardsDailyClaimMaxAggregateInputType
  }

  export type GetAjnaRewardsDailyClaimAggregateType<T extends AjnaRewardsDailyClaimAggregateArgs> = {
        [P in keyof T & keyof AggregateAjnaRewardsDailyClaim]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAjnaRewardsDailyClaim[P]>
      : GetScalarType<T[P], AggregateAjnaRewardsDailyClaim[P]>
  }




  export type AjnaRewardsDailyClaimGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: AjnaRewardsDailyClaimWhereInput
    orderBy?: Enumerable<AjnaRewardsDailyClaimOrderByWithAggregationInput>
    by: AjnaRewardsDailyClaimScalarFieldEnum[]
    having?: AjnaRewardsDailyClaimScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AjnaRewardsDailyClaimCountAggregateInputType | true
    _avg?: AjnaRewardsDailyClaimAvgAggregateInputType
    _sum?: AjnaRewardsDailyClaimSumAggregateInputType
    _min?: AjnaRewardsDailyClaimMinAggregateInputType
    _max?: AjnaRewardsDailyClaimMaxAggregateInputType
  }


  export type AjnaRewardsDailyClaimGroupByOutputType = {
    id: number
    timestamp: Date
    chain_id: number
    user_address: string
    amount: string
    week_number: number
    day_number: number
    _count: AjnaRewardsDailyClaimCountAggregateOutputType | null
    _avg: AjnaRewardsDailyClaimAvgAggregateOutputType | null
    _sum: AjnaRewardsDailyClaimSumAggregateOutputType | null
    _min: AjnaRewardsDailyClaimMinAggregateOutputType | null
    _max: AjnaRewardsDailyClaimMaxAggregateOutputType | null
  }

  type GetAjnaRewardsDailyClaimGroupByPayload<T extends AjnaRewardsDailyClaimGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<AjnaRewardsDailyClaimGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AjnaRewardsDailyClaimGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AjnaRewardsDailyClaimGroupByOutputType[P]>
            : GetScalarType<T[P], AjnaRewardsDailyClaimGroupByOutputType[P]>
        }
      >
    >


  export type AjnaRewardsDailyClaimSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    timestamp?: boolean
    chain_id?: boolean
    user_address?: boolean
    amount?: boolean
    week_number?: boolean
    day_number?: boolean
  }, ExtArgs["result"]["ajnaRewardsDailyClaim"]>

  export type AjnaRewardsDailyClaimSelectScalar = {
    id?: boolean
    timestamp?: boolean
    chain_id?: boolean
    user_address?: boolean
    amount?: boolean
    week_number?: boolean
    day_number?: boolean
  }


  type AjnaRewardsDailyClaimGetPayload<S extends boolean | null | undefined | AjnaRewardsDailyClaimArgs> = $Types.GetResult<AjnaRewardsDailyClaimPayload, S>

  type AjnaRewardsDailyClaimCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<AjnaRewardsDailyClaimFindManyArgs, 'select' | 'include'> & {
      select?: AjnaRewardsDailyClaimCountAggregateInputType | true
    }

  export interface AjnaRewardsDailyClaimDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['AjnaRewardsDailyClaim'], meta: { name: 'AjnaRewardsDailyClaim' } }
    /**
     * Find zero or one AjnaRewardsDailyClaim that matches the filter.
     * @param {AjnaRewardsDailyClaimFindUniqueArgs} args - Arguments to find a AjnaRewardsDailyClaim
     * @example
     * // Get one AjnaRewardsDailyClaim
     * const ajnaRewardsDailyClaim = await prisma.ajnaRewardsDailyClaim.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends AjnaRewardsDailyClaimFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, AjnaRewardsDailyClaimFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'AjnaRewardsDailyClaim'> extends True ? Prisma__AjnaRewardsDailyClaimClient<$Types.GetResult<AjnaRewardsDailyClaimPayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__AjnaRewardsDailyClaimClient<$Types.GetResult<AjnaRewardsDailyClaimPayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one AjnaRewardsDailyClaim that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {AjnaRewardsDailyClaimFindUniqueOrThrowArgs} args - Arguments to find a AjnaRewardsDailyClaim
     * @example
     * // Get one AjnaRewardsDailyClaim
     * const ajnaRewardsDailyClaim = await prisma.ajnaRewardsDailyClaim.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends AjnaRewardsDailyClaimFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, AjnaRewardsDailyClaimFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__AjnaRewardsDailyClaimClient<$Types.GetResult<AjnaRewardsDailyClaimPayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first AjnaRewardsDailyClaim that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsDailyClaimFindFirstArgs} args - Arguments to find a AjnaRewardsDailyClaim
     * @example
     * // Get one AjnaRewardsDailyClaim
     * const ajnaRewardsDailyClaim = await prisma.ajnaRewardsDailyClaim.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends AjnaRewardsDailyClaimFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, AjnaRewardsDailyClaimFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'AjnaRewardsDailyClaim'> extends True ? Prisma__AjnaRewardsDailyClaimClient<$Types.GetResult<AjnaRewardsDailyClaimPayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__AjnaRewardsDailyClaimClient<$Types.GetResult<AjnaRewardsDailyClaimPayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first AjnaRewardsDailyClaim that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsDailyClaimFindFirstOrThrowArgs} args - Arguments to find a AjnaRewardsDailyClaim
     * @example
     * // Get one AjnaRewardsDailyClaim
     * const ajnaRewardsDailyClaim = await prisma.ajnaRewardsDailyClaim.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends AjnaRewardsDailyClaimFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, AjnaRewardsDailyClaimFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__AjnaRewardsDailyClaimClient<$Types.GetResult<AjnaRewardsDailyClaimPayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more AjnaRewardsDailyClaims that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsDailyClaimFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all AjnaRewardsDailyClaims
     * const ajnaRewardsDailyClaims = await prisma.ajnaRewardsDailyClaim.findMany()
     * 
     * // Get first 10 AjnaRewardsDailyClaims
     * const ajnaRewardsDailyClaims = await prisma.ajnaRewardsDailyClaim.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const ajnaRewardsDailyClaimWithIdOnly = await prisma.ajnaRewardsDailyClaim.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends AjnaRewardsDailyClaimFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, AjnaRewardsDailyClaimFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<AjnaRewardsDailyClaimPayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a AjnaRewardsDailyClaim.
     * @param {AjnaRewardsDailyClaimCreateArgs} args - Arguments to create a AjnaRewardsDailyClaim.
     * @example
     * // Create one AjnaRewardsDailyClaim
     * const AjnaRewardsDailyClaim = await prisma.ajnaRewardsDailyClaim.create({
     *   data: {
     *     // ... data to create a AjnaRewardsDailyClaim
     *   }
     * })
     * 
    **/
    create<T extends AjnaRewardsDailyClaimCreateArgs<ExtArgs>>(
      args: SelectSubset<T, AjnaRewardsDailyClaimCreateArgs<ExtArgs>>
    ): Prisma__AjnaRewardsDailyClaimClient<$Types.GetResult<AjnaRewardsDailyClaimPayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many AjnaRewardsDailyClaims.
     *     @param {AjnaRewardsDailyClaimCreateManyArgs} args - Arguments to create many AjnaRewardsDailyClaims.
     *     @example
     *     // Create many AjnaRewardsDailyClaims
     *     const ajnaRewardsDailyClaim = await prisma.ajnaRewardsDailyClaim.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends AjnaRewardsDailyClaimCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, AjnaRewardsDailyClaimCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a AjnaRewardsDailyClaim.
     * @param {AjnaRewardsDailyClaimDeleteArgs} args - Arguments to delete one AjnaRewardsDailyClaim.
     * @example
     * // Delete one AjnaRewardsDailyClaim
     * const AjnaRewardsDailyClaim = await prisma.ajnaRewardsDailyClaim.delete({
     *   where: {
     *     // ... filter to delete one AjnaRewardsDailyClaim
     *   }
     * })
     * 
    **/
    delete<T extends AjnaRewardsDailyClaimDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, AjnaRewardsDailyClaimDeleteArgs<ExtArgs>>
    ): Prisma__AjnaRewardsDailyClaimClient<$Types.GetResult<AjnaRewardsDailyClaimPayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one AjnaRewardsDailyClaim.
     * @param {AjnaRewardsDailyClaimUpdateArgs} args - Arguments to update one AjnaRewardsDailyClaim.
     * @example
     * // Update one AjnaRewardsDailyClaim
     * const ajnaRewardsDailyClaim = await prisma.ajnaRewardsDailyClaim.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends AjnaRewardsDailyClaimUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, AjnaRewardsDailyClaimUpdateArgs<ExtArgs>>
    ): Prisma__AjnaRewardsDailyClaimClient<$Types.GetResult<AjnaRewardsDailyClaimPayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more AjnaRewardsDailyClaims.
     * @param {AjnaRewardsDailyClaimDeleteManyArgs} args - Arguments to filter AjnaRewardsDailyClaims to delete.
     * @example
     * // Delete a few AjnaRewardsDailyClaims
     * const { count } = await prisma.ajnaRewardsDailyClaim.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends AjnaRewardsDailyClaimDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, AjnaRewardsDailyClaimDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AjnaRewardsDailyClaims.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsDailyClaimUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many AjnaRewardsDailyClaims
     * const ajnaRewardsDailyClaim = await prisma.ajnaRewardsDailyClaim.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends AjnaRewardsDailyClaimUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, AjnaRewardsDailyClaimUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one AjnaRewardsDailyClaim.
     * @param {AjnaRewardsDailyClaimUpsertArgs} args - Arguments to update or create a AjnaRewardsDailyClaim.
     * @example
     * // Update or create a AjnaRewardsDailyClaim
     * const ajnaRewardsDailyClaim = await prisma.ajnaRewardsDailyClaim.upsert({
     *   create: {
     *     // ... data to create a AjnaRewardsDailyClaim
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the AjnaRewardsDailyClaim we want to update
     *   }
     * })
    **/
    upsert<T extends AjnaRewardsDailyClaimUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, AjnaRewardsDailyClaimUpsertArgs<ExtArgs>>
    ): Prisma__AjnaRewardsDailyClaimClient<$Types.GetResult<AjnaRewardsDailyClaimPayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of AjnaRewardsDailyClaims.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsDailyClaimCountArgs} args - Arguments to filter AjnaRewardsDailyClaims to count.
     * @example
     * // Count the number of AjnaRewardsDailyClaims
     * const count = await prisma.ajnaRewardsDailyClaim.count({
     *   where: {
     *     // ... the filter for the AjnaRewardsDailyClaims we want to count
     *   }
     * })
    **/
    count<T extends AjnaRewardsDailyClaimCountArgs>(
      args?: Subset<T, AjnaRewardsDailyClaimCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AjnaRewardsDailyClaimCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a AjnaRewardsDailyClaim.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsDailyClaimAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AjnaRewardsDailyClaimAggregateArgs>(args: Subset<T, AjnaRewardsDailyClaimAggregateArgs>): Prisma.PrismaPromise<GetAjnaRewardsDailyClaimAggregateType<T>>

    /**
     * Group by AjnaRewardsDailyClaim.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsDailyClaimGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AjnaRewardsDailyClaimGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AjnaRewardsDailyClaimGroupByArgs['orderBy'] }
        : { orderBy?: AjnaRewardsDailyClaimGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AjnaRewardsDailyClaimGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAjnaRewardsDailyClaimGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for AjnaRewardsDailyClaim.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__AjnaRewardsDailyClaimClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * AjnaRewardsDailyClaim base type for findUnique actions
   */
  export type AjnaRewardsDailyClaimFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsDailyClaim
     */
    select?: AjnaRewardsDailyClaimSelect<ExtArgs> | null
    /**
     * Filter, which AjnaRewardsDailyClaim to fetch.
     */
    where: AjnaRewardsDailyClaimWhereUniqueInput
  }

  /**
   * AjnaRewardsDailyClaim findUnique
   */
  export interface AjnaRewardsDailyClaimFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends AjnaRewardsDailyClaimFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * AjnaRewardsDailyClaim findUniqueOrThrow
   */
  export type AjnaRewardsDailyClaimFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsDailyClaim
     */
    select?: AjnaRewardsDailyClaimSelect<ExtArgs> | null
    /**
     * Filter, which AjnaRewardsDailyClaim to fetch.
     */
    where: AjnaRewardsDailyClaimWhereUniqueInput
  }


  /**
   * AjnaRewardsDailyClaim base type for findFirst actions
   */
  export type AjnaRewardsDailyClaimFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsDailyClaim
     */
    select?: AjnaRewardsDailyClaimSelect<ExtArgs> | null
    /**
     * Filter, which AjnaRewardsDailyClaim to fetch.
     */
    where?: AjnaRewardsDailyClaimWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AjnaRewardsDailyClaims to fetch.
     */
    orderBy?: Enumerable<AjnaRewardsDailyClaimOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AjnaRewardsDailyClaims.
     */
    cursor?: AjnaRewardsDailyClaimWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AjnaRewardsDailyClaims from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AjnaRewardsDailyClaims.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AjnaRewardsDailyClaims.
     */
    distinct?: Enumerable<AjnaRewardsDailyClaimScalarFieldEnum>
  }

  /**
   * AjnaRewardsDailyClaim findFirst
   */
  export interface AjnaRewardsDailyClaimFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends AjnaRewardsDailyClaimFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * AjnaRewardsDailyClaim findFirstOrThrow
   */
  export type AjnaRewardsDailyClaimFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsDailyClaim
     */
    select?: AjnaRewardsDailyClaimSelect<ExtArgs> | null
    /**
     * Filter, which AjnaRewardsDailyClaim to fetch.
     */
    where?: AjnaRewardsDailyClaimWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AjnaRewardsDailyClaims to fetch.
     */
    orderBy?: Enumerable<AjnaRewardsDailyClaimOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AjnaRewardsDailyClaims.
     */
    cursor?: AjnaRewardsDailyClaimWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AjnaRewardsDailyClaims from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AjnaRewardsDailyClaims.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AjnaRewardsDailyClaims.
     */
    distinct?: Enumerable<AjnaRewardsDailyClaimScalarFieldEnum>
  }


  /**
   * AjnaRewardsDailyClaim findMany
   */
  export type AjnaRewardsDailyClaimFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsDailyClaim
     */
    select?: AjnaRewardsDailyClaimSelect<ExtArgs> | null
    /**
     * Filter, which AjnaRewardsDailyClaims to fetch.
     */
    where?: AjnaRewardsDailyClaimWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AjnaRewardsDailyClaims to fetch.
     */
    orderBy?: Enumerable<AjnaRewardsDailyClaimOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing AjnaRewardsDailyClaims.
     */
    cursor?: AjnaRewardsDailyClaimWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AjnaRewardsDailyClaims from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AjnaRewardsDailyClaims.
     */
    skip?: number
    distinct?: Enumerable<AjnaRewardsDailyClaimScalarFieldEnum>
  }


  /**
   * AjnaRewardsDailyClaim create
   */
  export type AjnaRewardsDailyClaimCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsDailyClaim
     */
    select?: AjnaRewardsDailyClaimSelect<ExtArgs> | null
    /**
     * The data needed to create a AjnaRewardsDailyClaim.
     */
    data: XOR<AjnaRewardsDailyClaimCreateInput, AjnaRewardsDailyClaimUncheckedCreateInput>
  }


  /**
   * AjnaRewardsDailyClaim createMany
   */
  export type AjnaRewardsDailyClaimCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many AjnaRewardsDailyClaims.
     */
    data: Enumerable<AjnaRewardsDailyClaimCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * AjnaRewardsDailyClaim update
   */
  export type AjnaRewardsDailyClaimUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsDailyClaim
     */
    select?: AjnaRewardsDailyClaimSelect<ExtArgs> | null
    /**
     * The data needed to update a AjnaRewardsDailyClaim.
     */
    data: XOR<AjnaRewardsDailyClaimUpdateInput, AjnaRewardsDailyClaimUncheckedUpdateInput>
    /**
     * Choose, which AjnaRewardsDailyClaim to update.
     */
    where: AjnaRewardsDailyClaimWhereUniqueInput
  }


  /**
   * AjnaRewardsDailyClaim updateMany
   */
  export type AjnaRewardsDailyClaimUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update AjnaRewardsDailyClaims.
     */
    data: XOR<AjnaRewardsDailyClaimUpdateManyMutationInput, AjnaRewardsDailyClaimUncheckedUpdateManyInput>
    /**
     * Filter which AjnaRewardsDailyClaims to update
     */
    where?: AjnaRewardsDailyClaimWhereInput
  }


  /**
   * AjnaRewardsDailyClaim upsert
   */
  export type AjnaRewardsDailyClaimUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsDailyClaim
     */
    select?: AjnaRewardsDailyClaimSelect<ExtArgs> | null
    /**
     * The filter to search for the AjnaRewardsDailyClaim to update in case it exists.
     */
    where: AjnaRewardsDailyClaimWhereUniqueInput
    /**
     * In case the AjnaRewardsDailyClaim found by the `where` argument doesn't exist, create a new AjnaRewardsDailyClaim with this data.
     */
    create: XOR<AjnaRewardsDailyClaimCreateInput, AjnaRewardsDailyClaimUncheckedCreateInput>
    /**
     * In case the AjnaRewardsDailyClaim was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AjnaRewardsDailyClaimUpdateInput, AjnaRewardsDailyClaimUncheckedUpdateInput>
  }


  /**
   * AjnaRewardsDailyClaim delete
   */
  export type AjnaRewardsDailyClaimDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsDailyClaim
     */
    select?: AjnaRewardsDailyClaimSelect<ExtArgs> | null
    /**
     * Filter which AjnaRewardsDailyClaim to delete.
     */
    where: AjnaRewardsDailyClaimWhereUniqueInput
  }


  /**
   * AjnaRewardsDailyClaim deleteMany
   */
  export type AjnaRewardsDailyClaimDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which AjnaRewardsDailyClaims to delete
     */
    where?: AjnaRewardsDailyClaimWhereInput
  }


  /**
   * AjnaRewardsDailyClaim without action
   */
  export type AjnaRewardsDailyClaimArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsDailyClaim
     */
    select?: AjnaRewardsDailyClaimSelect<ExtArgs> | null
  }



  /**
   * Model AjnaRewardsMerkleTree
   */


  export type AggregateAjnaRewardsMerkleTree = {
    _count: AjnaRewardsMerkleTreeCountAggregateOutputType | null
    _avg: AjnaRewardsMerkleTreeAvgAggregateOutputType | null
    _sum: AjnaRewardsMerkleTreeSumAggregateOutputType | null
    _min: AjnaRewardsMerkleTreeMinAggregateOutputType | null
    _max: AjnaRewardsMerkleTreeMaxAggregateOutputType | null
  }

  export type AjnaRewardsMerkleTreeAvgAggregateOutputType = {
    id: number | null
    chain_id: number | null
    week_number: number | null
  }

  export type AjnaRewardsMerkleTreeSumAggregateOutputType = {
    id: number | null
    chain_id: number | null
    week_number: number | null
  }

  export type AjnaRewardsMerkleTreeMinAggregateOutputType = {
    id: number | null
    timestamp: Date | null
    chain_id: number | null
    week_number: number | null
    tree_root: string | null
    tx_processed: boolean | null
  }

  export type AjnaRewardsMerkleTreeMaxAggregateOutputType = {
    id: number | null
    timestamp: Date | null
    chain_id: number | null
    week_number: number | null
    tree_root: string | null
    tx_processed: boolean | null
  }

  export type AjnaRewardsMerkleTreeCountAggregateOutputType = {
    id: number
    timestamp: number
    chain_id: number
    week_number: number
    tree_root: number
    tx_processed: number
    _all: number
  }


  export type AjnaRewardsMerkleTreeAvgAggregateInputType = {
    id?: true
    chain_id?: true
    week_number?: true
  }

  export type AjnaRewardsMerkleTreeSumAggregateInputType = {
    id?: true
    chain_id?: true
    week_number?: true
  }

  export type AjnaRewardsMerkleTreeMinAggregateInputType = {
    id?: true
    timestamp?: true
    chain_id?: true
    week_number?: true
    tree_root?: true
    tx_processed?: true
  }

  export type AjnaRewardsMerkleTreeMaxAggregateInputType = {
    id?: true
    timestamp?: true
    chain_id?: true
    week_number?: true
    tree_root?: true
    tx_processed?: true
  }

  export type AjnaRewardsMerkleTreeCountAggregateInputType = {
    id?: true
    timestamp?: true
    chain_id?: true
    week_number?: true
    tree_root?: true
    tx_processed?: true
    _all?: true
  }

  export type AjnaRewardsMerkleTreeAggregateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which AjnaRewardsMerkleTree to aggregate.
     */
    where?: AjnaRewardsMerkleTreeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AjnaRewardsMerkleTrees to fetch.
     */
    orderBy?: Enumerable<AjnaRewardsMerkleTreeOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AjnaRewardsMerkleTreeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AjnaRewardsMerkleTrees from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AjnaRewardsMerkleTrees.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned AjnaRewardsMerkleTrees
    **/
    _count?: true | AjnaRewardsMerkleTreeCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: AjnaRewardsMerkleTreeAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: AjnaRewardsMerkleTreeSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AjnaRewardsMerkleTreeMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AjnaRewardsMerkleTreeMaxAggregateInputType
  }

  export type GetAjnaRewardsMerkleTreeAggregateType<T extends AjnaRewardsMerkleTreeAggregateArgs> = {
        [P in keyof T & keyof AggregateAjnaRewardsMerkleTree]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAjnaRewardsMerkleTree[P]>
      : GetScalarType<T[P], AggregateAjnaRewardsMerkleTree[P]>
  }




  export type AjnaRewardsMerkleTreeGroupByArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    where?: AjnaRewardsMerkleTreeWhereInput
    orderBy?: Enumerable<AjnaRewardsMerkleTreeOrderByWithAggregationInput>
    by: AjnaRewardsMerkleTreeScalarFieldEnum[]
    having?: AjnaRewardsMerkleTreeScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AjnaRewardsMerkleTreeCountAggregateInputType | true
    _avg?: AjnaRewardsMerkleTreeAvgAggregateInputType
    _sum?: AjnaRewardsMerkleTreeSumAggregateInputType
    _min?: AjnaRewardsMerkleTreeMinAggregateInputType
    _max?: AjnaRewardsMerkleTreeMaxAggregateInputType
  }


  export type AjnaRewardsMerkleTreeGroupByOutputType = {
    id: number
    timestamp: Date
    chain_id: number
    week_number: number
    tree_root: string
    tx_processed: boolean
    _count: AjnaRewardsMerkleTreeCountAggregateOutputType | null
    _avg: AjnaRewardsMerkleTreeAvgAggregateOutputType | null
    _sum: AjnaRewardsMerkleTreeSumAggregateOutputType | null
    _min: AjnaRewardsMerkleTreeMinAggregateOutputType | null
    _max: AjnaRewardsMerkleTreeMaxAggregateOutputType | null
  }

  type GetAjnaRewardsMerkleTreeGroupByPayload<T extends AjnaRewardsMerkleTreeGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickArray<AjnaRewardsMerkleTreeGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AjnaRewardsMerkleTreeGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AjnaRewardsMerkleTreeGroupByOutputType[P]>
            : GetScalarType<T[P], AjnaRewardsMerkleTreeGroupByOutputType[P]>
        }
      >
    >


  export type AjnaRewardsMerkleTreeSelect<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    timestamp?: boolean
    chain_id?: boolean
    week_number?: boolean
    tree_root?: boolean
    tx_processed?: boolean
  }, ExtArgs["result"]["ajnaRewardsMerkleTree"]>

  export type AjnaRewardsMerkleTreeSelectScalar = {
    id?: boolean
    timestamp?: boolean
    chain_id?: boolean
    week_number?: boolean
    tree_root?: boolean
    tx_processed?: boolean
  }


  type AjnaRewardsMerkleTreeGetPayload<S extends boolean | null | undefined | AjnaRewardsMerkleTreeArgs> = $Types.GetResult<AjnaRewardsMerkleTreePayload, S>

  type AjnaRewardsMerkleTreeCountArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = 
    Omit<AjnaRewardsMerkleTreeFindManyArgs, 'select' | 'include'> & {
      select?: AjnaRewardsMerkleTreeCountAggregateInputType | true
    }

  export interface AjnaRewardsMerkleTreeDelegate<GlobalRejectSettings extends Prisma.RejectOnNotFound | Prisma.RejectPerOperation | false | undefined, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['AjnaRewardsMerkleTree'], meta: { name: 'AjnaRewardsMerkleTree' } }
    /**
     * Find zero or one AjnaRewardsMerkleTree that matches the filter.
     * @param {AjnaRewardsMerkleTreeFindUniqueArgs} args - Arguments to find a AjnaRewardsMerkleTree
     * @example
     * // Get one AjnaRewardsMerkleTree
     * const ajnaRewardsMerkleTree = await prisma.ajnaRewardsMerkleTree.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUnique<T extends AjnaRewardsMerkleTreeFindUniqueArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args: SelectSubset<T, AjnaRewardsMerkleTreeFindUniqueArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findUnique', 'AjnaRewardsMerkleTree'> extends True ? Prisma__AjnaRewardsMerkleTreeClient<$Types.GetResult<AjnaRewardsMerkleTreePayload<ExtArgs>, T, 'findUnique', never>, never, ExtArgs> : Prisma__AjnaRewardsMerkleTreeClient<$Types.GetResult<AjnaRewardsMerkleTreePayload<ExtArgs>, T, 'findUnique', never> | null, null, ExtArgs>

    /**
     * Find one AjnaRewardsMerkleTree that matches the filter or throw an error  with `error.code='P2025'` 
     *     if no matches were found.
     * @param {AjnaRewardsMerkleTreeFindUniqueOrThrowArgs} args - Arguments to find a AjnaRewardsMerkleTree
     * @example
     * // Get one AjnaRewardsMerkleTree
     * const ajnaRewardsMerkleTree = await prisma.ajnaRewardsMerkleTree.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findUniqueOrThrow<T extends AjnaRewardsMerkleTreeFindUniqueOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, AjnaRewardsMerkleTreeFindUniqueOrThrowArgs<ExtArgs>>
    ): Prisma__AjnaRewardsMerkleTreeClient<$Types.GetResult<AjnaRewardsMerkleTreePayload<ExtArgs>, T, 'findUniqueOrThrow', never>, never, ExtArgs>

    /**
     * Find the first AjnaRewardsMerkleTree that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsMerkleTreeFindFirstArgs} args - Arguments to find a AjnaRewardsMerkleTree
     * @example
     * // Get one AjnaRewardsMerkleTree
     * const ajnaRewardsMerkleTree = await prisma.ajnaRewardsMerkleTree.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirst<T extends AjnaRewardsMerkleTreeFindFirstArgs<ExtArgs>, LocalRejectSettings = T["rejectOnNotFound"] extends RejectOnNotFound ? T['rejectOnNotFound'] : undefined>(
      args?: SelectSubset<T, AjnaRewardsMerkleTreeFindFirstArgs<ExtArgs>>
    ): HasReject<GlobalRejectSettings, LocalRejectSettings, 'findFirst', 'AjnaRewardsMerkleTree'> extends True ? Prisma__AjnaRewardsMerkleTreeClient<$Types.GetResult<AjnaRewardsMerkleTreePayload<ExtArgs>, T, 'findFirst', never>, never, ExtArgs> : Prisma__AjnaRewardsMerkleTreeClient<$Types.GetResult<AjnaRewardsMerkleTreePayload<ExtArgs>, T, 'findFirst', never> | null, null, ExtArgs>

    /**
     * Find the first AjnaRewardsMerkleTree that matches the filter or
     * throw `NotFoundError` if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsMerkleTreeFindFirstOrThrowArgs} args - Arguments to find a AjnaRewardsMerkleTree
     * @example
     * // Get one AjnaRewardsMerkleTree
     * const ajnaRewardsMerkleTree = await prisma.ajnaRewardsMerkleTree.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
    **/
    findFirstOrThrow<T extends AjnaRewardsMerkleTreeFindFirstOrThrowArgs<ExtArgs>>(
      args?: SelectSubset<T, AjnaRewardsMerkleTreeFindFirstOrThrowArgs<ExtArgs>>
    ): Prisma__AjnaRewardsMerkleTreeClient<$Types.GetResult<AjnaRewardsMerkleTreePayload<ExtArgs>, T, 'findFirstOrThrow', never>, never, ExtArgs>

    /**
     * Find zero or more AjnaRewardsMerkleTrees that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsMerkleTreeFindManyArgs=} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all AjnaRewardsMerkleTrees
     * const ajnaRewardsMerkleTrees = await prisma.ajnaRewardsMerkleTree.findMany()
     * 
     * // Get first 10 AjnaRewardsMerkleTrees
     * const ajnaRewardsMerkleTrees = await prisma.ajnaRewardsMerkleTree.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const ajnaRewardsMerkleTreeWithIdOnly = await prisma.ajnaRewardsMerkleTree.findMany({ select: { id: true } })
     * 
    **/
    findMany<T extends AjnaRewardsMerkleTreeFindManyArgs<ExtArgs>>(
      args?: SelectSubset<T, AjnaRewardsMerkleTreeFindManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<$Types.GetResult<AjnaRewardsMerkleTreePayload<ExtArgs>, T, 'findMany', never>>

    /**
     * Create a AjnaRewardsMerkleTree.
     * @param {AjnaRewardsMerkleTreeCreateArgs} args - Arguments to create a AjnaRewardsMerkleTree.
     * @example
     * // Create one AjnaRewardsMerkleTree
     * const AjnaRewardsMerkleTree = await prisma.ajnaRewardsMerkleTree.create({
     *   data: {
     *     // ... data to create a AjnaRewardsMerkleTree
     *   }
     * })
     * 
    **/
    create<T extends AjnaRewardsMerkleTreeCreateArgs<ExtArgs>>(
      args: SelectSubset<T, AjnaRewardsMerkleTreeCreateArgs<ExtArgs>>
    ): Prisma__AjnaRewardsMerkleTreeClient<$Types.GetResult<AjnaRewardsMerkleTreePayload<ExtArgs>, T, 'create', never>, never, ExtArgs>

    /**
     * Create many AjnaRewardsMerkleTrees.
     *     @param {AjnaRewardsMerkleTreeCreateManyArgs} args - Arguments to create many AjnaRewardsMerkleTrees.
     *     @example
     *     // Create many AjnaRewardsMerkleTrees
     *     const ajnaRewardsMerkleTree = await prisma.ajnaRewardsMerkleTree.createMany({
     *       data: {
     *         // ... provide data here
     *       }
     *     })
     *     
    **/
    createMany<T extends AjnaRewardsMerkleTreeCreateManyArgs<ExtArgs>>(
      args?: SelectSubset<T, AjnaRewardsMerkleTreeCreateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a AjnaRewardsMerkleTree.
     * @param {AjnaRewardsMerkleTreeDeleteArgs} args - Arguments to delete one AjnaRewardsMerkleTree.
     * @example
     * // Delete one AjnaRewardsMerkleTree
     * const AjnaRewardsMerkleTree = await prisma.ajnaRewardsMerkleTree.delete({
     *   where: {
     *     // ... filter to delete one AjnaRewardsMerkleTree
     *   }
     * })
     * 
    **/
    delete<T extends AjnaRewardsMerkleTreeDeleteArgs<ExtArgs>>(
      args: SelectSubset<T, AjnaRewardsMerkleTreeDeleteArgs<ExtArgs>>
    ): Prisma__AjnaRewardsMerkleTreeClient<$Types.GetResult<AjnaRewardsMerkleTreePayload<ExtArgs>, T, 'delete', never>, never, ExtArgs>

    /**
     * Update one AjnaRewardsMerkleTree.
     * @param {AjnaRewardsMerkleTreeUpdateArgs} args - Arguments to update one AjnaRewardsMerkleTree.
     * @example
     * // Update one AjnaRewardsMerkleTree
     * const ajnaRewardsMerkleTree = await prisma.ajnaRewardsMerkleTree.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    update<T extends AjnaRewardsMerkleTreeUpdateArgs<ExtArgs>>(
      args: SelectSubset<T, AjnaRewardsMerkleTreeUpdateArgs<ExtArgs>>
    ): Prisma__AjnaRewardsMerkleTreeClient<$Types.GetResult<AjnaRewardsMerkleTreePayload<ExtArgs>, T, 'update', never>, never, ExtArgs>

    /**
     * Delete zero or more AjnaRewardsMerkleTrees.
     * @param {AjnaRewardsMerkleTreeDeleteManyArgs} args - Arguments to filter AjnaRewardsMerkleTrees to delete.
     * @example
     * // Delete a few AjnaRewardsMerkleTrees
     * const { count } = await prisma.ajnaRewardsMerkleTree.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
    **/
    deleteMany<T extends AjnaRewardsMerkleTreeDeleteManyArgs<ExtArgs>>(
      args?: SelectSubset<T, AjnaRewardsMerkleTreeDeleteManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AjnaRewardsMerkleTrees.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsMerkleTreeUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many AjnaRewardsMerkleTrees
     * const ajnaRewardsMerkleTree = await prisma.ajnaRewardsMerkleTree.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
    **/
    updateMany<T extends AjnaRewardsMerkleTreeUpdateManyArgs<ExtArgs>>(
      args: SelectSubset<T, AjnaRewardsMerkleTreeUpdateManyArgs<ExtArgs>>
    ): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one AjnaRewardsMerkleTree.
     * @param {AjnaRewardsMerkleTreeUpsertArgs} args - Arguments to update or create a AjnaRewardsMerkleTree.
     * @example
     * // Update or create a AjnaRewardsMerkleTree
     * const ajnaRewardsMerkleTree = await prisma.ajnaRewardsMerkleTree.upsert({
     *   create: {
     *     // ... data to create a AjnaRewardsMerkleTree
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the AjnaRewardsMerkleTree we want to update
     *   }
     * })
    **/
    upsert<T extends AjnaRewardsMerkleTreeUpsertArgs<ExtArgs>>(
      args: SelectSubset<T, AjnaRewardsMerkleTreeUpsertArgs<ExtArgs>>
    ): Prisma__AjnaRewardsMerkleTreeClient<$Types.GetResult<AjnaRewardsMerkleTreePayload<ExtArgs>, T, 'upsert', never>, never, ExtArgs>

    /**
     * Count the number of AjnaRewardsMerkleTrees.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsMerkleTreeCountArgs} args - Arguments to filter AjnaRewardsMerkleTrees to count.
     * @example
     * // Count the number of AjnaRewardsMerkleTrees
     * const count = await prisma.ajnaRewardsMerkleTree.count({
     *   where: {
     *     // ... the filter for the AjnaRewardsMerkleTrees we want to count
     *   }
     * })
    **/
    count<T extends AjnaRewardsMerkleTreeCountArgs>(
      args?: Subset<T, AjnaRewardsMerkleTreeCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AjnaRewardsMerkleTreeCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a AjnaRewardsMerkleTree.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsMerkleTreeAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AjnaRewardsMerkleTreeAggregateArgs>(args: Subset<T, AjnaRewardsMerkleTreeAggregateArgs>): Prisma.PrismaPromise<GetAjnaRewardsMerkleTreeAggregateType<T>>

    /**
     * Group by AjnaRewardsMerkleTree.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AjnaRewardsMerkleTreeGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AjnaRewardsMerkleTreeGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AjnaRewardsMerkleTreeGroupByArgs['orderBy'] }
        : { orderBy?: AjnaRewardsMerkleTreeGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends TupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AjnaRewardsMerkleTreeGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAjnaRewardsMerkleTreeGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>

  }

  /**
   * The delegate class that acts as a "Promise-like" for AjnaRewardsMerkleTree.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export class Prisma__AjnaRewardsMerkleTreeClient<T, Null = never, ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> implements Prisma.PrismaPromise<T> {
    private readonly _dmmf;
    private readonly _queryType;
    private readonly _rootField;
    private readonly _clientMethod;
    private readonly _args;
    private readonly _dataPath;
    private readonly _errorFormat;
    private readonly _measurePerformance?;
    private _isList;
    private _callsite;
    private _requestPromise?;
    readonly [Symbol.toStringTag]: 'PrismaPromise';
    constructor(_dmmf: runtime.DMMFClass, _queryType: 'query' | 'mutation', _rootField: string, _clientMethod: string, _args: any, _dataPath: string[], _errorFormat: ErrorFormat, _measurePerformance?: boolean | undefined, _isList?: boolean);


    private get _document();
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
  }



  // Custom InputTypes

  /**
   * AjnaRewardsMerkleTree base type for findUnique actions
   */
  export type AjnaRewardsMerkleTreeFindUniqueArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsMerkleTree
     */
    select?: AjnaRewardsMerkleTreeSelect<ExtArgs> | null
    /**
     * Filter, which AjnaRewardsMerkleTree to fetch.
     */
    where: AjnaRewardsMerkleTreeWhereUniqueInput
  }

  /**
   * AjnaRewardsMerkleTree findUnique
   */
  export interface AjnaRewardsMerkleTreeFindUniqueArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends AjnaRewardsMerkleTreeFindUniqueArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findUniqueOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * AjnaRewardsMerkleTree findUniqueOrThrow
   */
  export type AjnaRewardsMerkleTreeFindUniqueOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsMerkleTree
     */
    select?: AjnaRewardsMerkleTreeSelect<ExtArgs> | null
    /**
     * Filter, which AjnaRewardsMerkleTree to fetch.
     */
    where: AjnaRewardsMerkleTreeWhereUniqueInput
  }


  /**
   * AjnaRewardsMerkleTree base type for findFirst actions
   */
  export type AjnaRewardsMerkleTreeFindFirstArgsBase<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsMerkleTree
     */
    select?: AjnaRewardsMerkleTreeSelect<ExtArgs> | null
    /**
     * Filter, which AjnaRewardsMerkleTree to fetch.
     */
    where?: AjnaRewardsMerkleTreeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AjnaRewardsMerkleTrees to fetch.
     */
    orderBy?: Enumerable<AjnaRewardsMerkleTreeOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AjnaRewardsMerkleTrees.
     */
    cursor?: AjnaRewardsMerkleTreeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AjnaRewardsMerkleTrees from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AjnaRewardsMerkleTrees.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AjnaRewardsMerkleTrees.
     */
    distinct?: Enumerable<AjnaRewardsMerkleTreeScalarFieldEnum>
  }

  /**
   * AjnaRewardsMerkleTree findFirst
   */
  export interface AjnaRewardsMerkleTreeFindFirstArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> extends AjnaRewardsMerkleTreeFindFirstArgsBase<ExtArgs> {
   /**
    * Throw an Error if query returns no results
    * @deprecated since 4.0.0: use `findFirstOrThrow` method instead
    */
    rejectOnNotFound?: RejectOnNotFound
  }
      

  /**
   * AjnaRewardsMerkleTree findFirstOrThrow
   */
  export type AjnaRewardsMerkleTreeFindFirstOrThrowArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsMerkleTree
     */
    select?: AjnaRewardsMerkleTreeSelect<ExtArgs> | null
    /**
     * Filter, which AjnaRewardsMerkleTree to fetch.
     */
    where?: AjnaRewardsMerkleTreeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AjnaRewardsMerkleTrees to fetch.
     */
    orderBy?: Enumerable<AjnaRewardsMerkleTreeOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AjnaRewardsMerkleTrees.
     */
    cursor?: AjnaRewardsMerkleTreeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AjnaRewardsMerkleTrees from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AjnaRewardsMerkleTrees.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AjnaRewardsMerkleTrees.
     */
    distinct?: Enumerable<AjnaRewardsMerkleTreeScalarFieldEnum>
  }


  /**
   * AjnaRewardsMerkleTree findMany
   */
  export type AjnaRewardsMerkleTreeFindManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsMerkleTree
     */
    select?: AjnaRewardsMerkleTreeSelect<ExtArgs> | null
    /**
     * Filter, which AjnaRewardsMerkleTrees to fetch.
     */
    where?: AjnaRewardsMerkleTreeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AjnaRewardsMerkleTrees to fetch.
     */
    orderBy?: Enumerable<AjnaRewardsMerkleTreeOrderByWithRelationInput>
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing AjnaRewardsMerkleTrees.
     */
    cursor?: AjnaRewardsMerkleTreeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AjnaRewardsMerkleTrees from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AjnaRewardsMerkleTrees.
     */
    skip?: number
    distinct?: Enumerable<AjnaRewardsMerkleTreeScalarFieldEnum>
  }


  /**
   * AjnaRewardsMerkleTree create
   */
  export type AjnaRewardsMerkleTreeCreateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsMerkleTree
     */
    select?: AjnaRewardsMerkleTreeSelect<ExtArgs> | null
    /**
     * The data needed to create a AjnaRewardsMerkleTree.
     */
    data: XOR<AjnaRewardsMerkleTreeCreateInput, AjnaRewardsMerkleTreeUncheckedCreateInput>
  }


  /**
   * AjnaRewardsMerkleTree createMany
   */
  export type AjnaRewardsMerkleTreeCreateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many AjnaRewardsMerkleTrees.
     */
    data: Enumerable<AjnaRewardsMerkleTreeCreateManyInput>
    skipDuplicates?: boolean
  }


  /**
   * AjnaRewardsMerkleTree update
   */
  export type AjnaRewardsMerkleTreeUpdateArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsMerkleTree
     */
    select?: AjnaRewardsMerkleTreeSelect<ExtArgs> | null
    /**
     * The data needed to update a AjnaRewardsMerkleTree.
     */
    data: XOR<AjnaRewardsMerkleTreeUpdateInput, AjnaRewardsMerkleTreeUncheckedUpdateInput>
    /**
     * Choose, which AjnaRewardsMerkleTree to update.
     */
    where: AjnaRewardsMerkleTreeWhereUniqueInput
  }


  /**
   * AjnaRewardsMerkleTree updateMany
   */
  export type AjnaRewardsMerkleTreeUpdateManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * The data used to update AjnaRewardsMerkleTrees.
     */
    data: XOR<AjnaRewardsMerkleTreeUpdateManyMutationInput, AjnaRewardsMerkleTreeUncheckedUpdateManyInput>
    /**
     * Filter which AjnaRewardsMerkleTrees to update
     */
    where?: AjnaRewardsMerkleTreeWhereInput
  }


  /**
   * AjnaRewardsMerkleTree upsert
   */
  export type AjnaRewardsMerkleTreeUpsertArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsMerkleTree
     */
    select?: AjnaRewardsMerkleTreeSelect<ExtArgs> | null
    /**
     * The filter to search for the AjnaRewardsMerkleTree to update in case it exists.
     */
    where: AjnaRewardsMerkleTreeWhereUniqueInput
    /**
     * In case the AjnaRewardsMerkleTree found by the `where` argument doesn't exist, create a new AjnaRewardsMerkleTree with this data.
     */
    create: XOR<AjnaRewardsMerkleTreeCreateInput, AjnaRewardsMerkleTreeUncheckedCreateInput>
    /**
     * In case the AjnaRewardsMerkleTree was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AjnaRewardsMerkleTreeUpdateInput, AjnaRewardsMerkleTreeUncheckedUpdateInput>
  }


  /**
   * AjnaRewardsMerkleTree delete
   */
  export type AjnaRewardsMerkleTreeDeleteArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsMerkleTree
     */
    select?: AjnaRewardsMerkleTreeSelect<ExtArgs> | null
    /**
     * Filter which AjnaRewardsMerkleTree to delete.
     */
    where: AjnaRewardsMerkleTreeWhereUniqueInput
  }


  /**
   * AjnaRewardsMerkleTree deleteMany
   */
  export type AjnaRewardsMerkleTreeDeleteManyArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Filter which AjnaRewardsMerkleTrees to delete
     */
    where?: AjnaRewardsMerkleTreeWhereInput
  }


  /**
   * AjnaRewardsMerkleTree without action
   */
  export type AjnaRewardsMerkleTreeArgs<ExtArgs extends $Extensions.Args = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AjnaRewardsMerkleTree
     */
    select?: AjnaRewardsMerkleTreeSelect<ExtArgs> | null
  }



  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const MigrationsScalarFieldEnum: {
    id: 'id',
    name: 'name',
    hash: 'hash',
    executed_at: 'executed_at'
  };

  export type MigrationsScalarFieldEnum = (typeof MigrationsScalarFieldEnum)[keyof typeof MigrationsScalarFieldEnum]


  export const TosApprovalScalarFieldEnum: {
    id: 'id',
    address: 'address',
    signature: 'signature',
    message: 'message',
    chain_id: 'chain_id',
    doc_version: 'doc_version',
    sign_date: 'sign_date'
  };

  export type TosApprovalScalarFieldEnum = (typeof TosApprovalScalarFieldEnum)[keyof typeof TosApprovalScalarFieldEnum]


  export const VaultScalarFieldEnum: {
    vault_id: 'vault_id',
    type: 'type',
    owner_address: 'owner_address',
    chain_id: 'chain_id',
    protocol: 'protocol'
  };

  export type VaultScalarFieldEnum = (typeof VaultScalarFieldEnum)[keyof typeof VaultScalarFieldEnum]


  export const UserScalarFieldEnum: {
    address: 'address',
    timestamp: 'timestamp',
    user_that_referred_address: 'user_that_referred_address',
    accepted: 'accepted'
  };

  export type UserScalarFieldEnum = (typeof UserScalarFieldEnum)[keyof typeof UserScalarFieldEnum]


  export const WeeklyClaimScalarFieldEnum: {
    id: 'id',
    timestamp: 'timestamp',
    week_number: 'week_number',
    user_address: 'user_address',
    proof: 'proof',
    amount: 'amount'
  };

  export type WeeklyClaimScalarFieldEnum = (typeof WeeklyClaimScalarFieldEnum)[keyof typeof WeeklyClaimScalarFieldEnum]


  export const MerkleTreeScalarFieldEnum: {
    week_number: 'week_number',
    start_block: 'start_block',
    end_block: 'end_block',
    timestamp: 'timestamp',
    tree_root: 'tree_root',
    snapshot: 'snapshot'
  };

  export type MerkleTreeScalarFieldEnum = (typeof MerkleTreeScalarFieldEnum)[keyof typeof MerkleTreeScalarFieldEnum]


  export const WalletRiskScalarFieldEnum: {
    address: 'address',
    last_check: 'last_check',
    is_risky: 'is_risky'
  };

  export type WalletRiskScalarFieldEnum = (typeof WalletRiskScalarFieldEnum)[keyof typeof WalletRiskScalarFieldEnum]


  export const CollateralTypeScalarFieldEnum: {
    collateral_name: 'collateral_name',
    token: 'token',
    next_price: 'next_price',
    current_price: 'current_price',
    liquidation_ratio: 'liquidation_ratio',
    liquidation_penalty: 'liquidation_penalty',
    rate: 'rate',
    market_price: 'market_price'
  };

  export type CollateralTypeScalarFieldEnum = (typeof CollateralTypeScalarFieldEnum)[keyof typeof CollateralTypeScalarFieldEnum]


  export const DiscoverScalarFieldEnum: {
    protocol_id: 'protocol_id',
    position_id: 'position_id',
    collateral_type: 'collateral_type',
    vault_debt: 'vault_debt',
    vault_normalized_debt: 'vault_normalized_debt',
    vault_collateral: 'vault_collateral',
    yield_30d: 'yield_30d',
    status: 'status',
    last_action: 'last_action',
    pnl_all: 'pnl_all',
    pnl_1d: 'pnl_1d',
    pnl_7d: 'pnl_7d',
    pnl_30d: 'pnl_30d',
    pnl_365d: 'pnl_365d',
    pnl_ytd: 'pnl_ytd',
    net_profit_all: 'net_profit_all',
    net_profit_1d: 'net_profit_1d',
    net_profit_7d: 'net_profit_7d',
    net_profit_30d: 'net_profit_30d',
    net_profit_365d: 'net_profit_365d',
    net_profit_ytd: 'net_profit_ytd',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type DiscoverScalarFieldEnum = (typeof DiscoverScalarFieldEnum)[keyof typeof DiscoverScalarFieldEnum]


  export const HighestRiskPositionsScalarFieldEnum: {
    protocol_id: 'protocol_id',
    position_id: 'position_id',
    collateral_type: 'collateral_type',
    token: 'token',
    collateral_ratio: 'collateral_ratio',
    collateral_value: 'collateral_value',
    liquidation_proximity: 'liquidation_proximity',
    liquidation_price: 'liquidation_price',
    liquidation_value: 'liquidation_value',
    next_price: 'next_price',
    status: 'status',
    type: 'type'
  };

  export type HighestRiskPositionsScalarFieldEnum = (typeof HighestRiskPositionsScalarFieldEnum)[keyof typeof HighestRiskPositionsScalarFieldEnum]


  export const HighestMultiplyPnlScalarFieldEnum: {
    protocol_id: 'protocol_id',
    position_id: 'position_id',
    collateral_type: 'collateral_type',
    token: 'token',
    collateral_value: 'collateral_value',
    vault_multiple: 'vault_multiple',
    pnl_all: 'pnl_all',
    pnl_1d: 'pnl_1d',
    pnl_7d: 'pnl_7d',
    pnl_30d: 'pnl_30d',
    pnl_365d: 'pnl_365d',
    pnl_ytd: 'pnl_ytd',
    net_profit_all: 'net_profit_all',
    net_profit_1d: 'net_profit_1d',
    net_profit_7d: 'net_profit_7d',
    net_profit_30d: 'net_profit_30d',
    net_profit_365d: 'net_profit_365d',
    net_profit_ytd: 'net_profit_ytd',
    last_action: 'last_action',
    type: 'type'
  };

  export type HighestMultiplyPnlScalarFieldEnum = (typeof HighestMultiplyPnlScalarFieldEnum)[keyof typeof HighestMultiplyPnlScalarFieldEnum]


  export const MostYieldEarnedScalarFieldEnum: {
    protocol_id: 'protocol_id',
    position_id: 'position_id',
    collateral_type: 'collateral_type',
    token: 'token',
    collateral_value: 'collateral_value',
    net_value: 'net_value',
    pnl_all: 'pnl_all',
    pnl_1d: 'pnl_1d',
    pnl_7d: 'pnl_7d',
    pnl_30d: 'pnl_30d',
    pnl_365d: 'pnl_365d',
    pnl_ytd: 'pnl_ytd',
    yield_30d: 'yield_30d',
    last_action: 'last_action',
    type: 'type'
  };

  export type MostYieldEarnedScalarFieldEnum = (typeof MostYieldEarnedScalarFieldEnum)[keyof typeof MostYieldEarnedScalarFieldEnum]


  export const LargestDebtScalarFieldEnum: {
    protocol_id: 'protocol_id',
    position_id: 'position_id',
    collateral_type: 'collateral_type',
    token: 'token',
    collateral_value: 'collateral_value',
    liquidation_proximity: 'liquidation_proximity',
    vault_debt: 'vault_debt',
    coll_ratio: 'coll_ratio',
    last_action: 'last_action',
    type: 'type'
  };

  export type LargestDebtScalarFieldEnum = (typeof LargestDebtScalarFieldEnum)[keyof typeof LargestDebtScalarFieldEnum]


  export const UsersWhoFollowVaultsScalarFieldEnum: {
    user_address: 'user_address',
    vault_id: 'vault_id',
    vault_chain_id: 'vault_chain_id',
    protocol: 'protocol'
  };

  export type UsersWhoFollowVaultsScalarFieldEnum = (typeof UsersWhoFollowVaultsScalarFieldEnum)[keyof typeof UsersWhoFollowVaultsScalarFieldEnum]


  export const ProductHubItemsScalarFieldEnum: {
    id: 'id',
    label: 'label',
    network: 'network',
    primaryToken: 'primaryToken',
    primaryTokenGroup: 'primaryTokenGroup',
    product: 'product',
    protocol: 'protocol',
    secondaryToken: 'secondaryToken',
    secondaryTokenGroup: 'secondaryTokenGroup',
    weeklyNetApy: 'weeklyNetApy',
    depositToken: 'depositToken',
    earnStrategy: 'earnStrategy',
    fee: 'fee',
    liquidity: 'liquidity',
    managementType: 'managementType',
    maxLtv: 'maxLtv',
    maxMultiply: 'maxMultiply',
    multiplyStrategy: 'multiplyStrategy',
    multiplyStrategyType: 'multiplyStrategyType',
    reverseTokens: 'reverseTokens',
    updatedAt: 'updatedAt'
  };

  export type ProductHubItemsScalarFieldEnum = (typeof ProductHubItemsScalarFieldEnum)[keyof typeof ProductHubItemsScalarFieldEnum]


  export const AjnaRewardsWeeklyClaimScalarFieldEnum: {
    id: 'id',
    timestamp: 'timestamp',
    chain_id: 'chain_id',
    user_address: 'user_address',
    amount: 'amount',
    week_number: 'week_number',
    proof: 'proof'
  };

  export type AjnaRewardsWeeklyClaimScalarFieldEnum = (typeof AjnaRewardsWeeklyClaimScalarFieldEnum)[keyof typeof AjnaRewardsWeeklyClaimScalarFieldEnum]


  export const AjnaRewardsDailyClaimScalarFieldEnum: {
    id: 'id',
    timestamp: 'timestamp',
    chain_id: 'chain_id',
    user_address: 'user_address',
    amount: 'amount',
    week_number: 'week_number',
    day_number: 'day_number'
  };

  export type AjnaRewardsDailyClaimScalarFieldEnum = (typeof AjnaRewardsDailyClaimScalarFieldEnum)[keyof typeof AjnaRewardsDailyClaimScalarFieldEnum]


  export const AjnaRewardsMerkleTreeScalarFieldEnum: {
    id: 'id',
    timestamp: 'timestamp',
    chain_id: 'chain_id',
    week_number: 'week_number',
    tree_root: 'tree_root',
    tx_processed: 'tx_processed'
  };

  export type AjnaRewardsMerkleTreeScalarFieldEnum = (typeof AjnaRewardsMerkleTreeScalarFieldEnum)[keyof typeof AjnaRewardsMerkleTreeScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const JsonNullValueInput: {
    JsonNull: typeof JsonNull
  };

  export type JsonNullValueInput = (typeof JsonNullValueInput)[keyof typeof JsonNullValueInput]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  export const JsonNullValueFilter: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull,
    AnyNull: typeof AnyNull
  };

  export type JsonNullValueFilter = (typeof JsonNullValueFilter)[keyof typeof JsonNullValueFilter]


  /**
   * Deep Input Types
   */


  export type migrationsWhereInput = {
    AND?: Enumerable<migrationsWhereInput>
    OR?: Enumerable<migrationsWhereInput>
    NOT?: Enumerable<migrationsWhereInput>
    id?: IntFilter | number
    name?: StringFilter | string
    hash?: StringFilter | string
    executed_at?: DateTimeNullableFilter | Date | string | null
  }

  export type migrationsOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    hash?: SortOrder
    executed_at?: SortOrderInput | SortOrder
  }

  export type migrationsWhereUniqueInput = {
    id?: number
    name?: string
  }

  export type migrationsOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    hash?: SortOrder
    executed_at?: SortOrderInput | SortOrder
    _count?: migrationsCountOrderByAggregateInput
    _avg?: migrationsAvgOrderByAggregateInput
    _max?: migrationsMaxOrderByAggregateInput
    _min?: migrationsMinOrderByAggregateInput
    _sum?: migrationsSumOrderByAggregateInput
  }

  export type migrationsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<migrationsScalarWhereWithAggregatesInput>
    OR?: Enumerable<migrationsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<migrationsScalarWhereWithAggregatesInput>
    id?: IntWithAggregatesFilter | number
    name?: StringWithAggregatesFilter | string
    hash?: StringWithAggregatesFilter | string
    executed_at?: DateTimeNullableWithAggregatesFilter | Date | string | null
  }

  export type TosApprovalWhereInput = {
    AND?: Enumerable<TosApprovalWhereInput>
    OR?: Enumerable<TosApprovalWhereInput>
    NOT?: Enumerable<TosApprovalWhereInput>
    id?: IntFilter | number
    address?: StringFilter | string
    signature?: StringFilter | string
    message?: StringFilter | string
    chain_id?: IntFilter | number
    doc_version?: StringFilter | string
    sign_date?: DateTimeFilter | Date | string
  }

  export type TosApprovalOrderByWithRelationInput = {
    id?: SortOrder
    address?: SortOrder
    signature?: SortOrder
    message?: SortOrder
    chain_id?: SortOrder
    doc_version?: SortOrder
    sign_date?: SortOrder
  }

  export type TosApprovalWhereUniqueInput = {
    id?: number
    tos_approval_unique_signature?: TosApprovalTos_approval_unique_signatureCompoundUniqueInput
    address_chain_id_doc_version?: TosApprovalAddressChain_idDoc_versionCompoundUniqueInput
  }

  export type TosApprovalOrderByWithAggregationInput = {
    id?: SortOrder
    address?: SortOrder
    signature?: SortOrder
    message?: SortOrder
    chain_id?: SortOrder
    doc_version?: SortOrder
    sign_date?: SortOrder
    _count?: TosApprovalCountOrderByAggregateInput
    _avg?: TosApprovalAvgOrderByAggregateInput
    _max?: TosApprovalMaxOrderByAggregateInput
    _min?: TosApprovalMinOrderByAggregateInput
    _sum?: TosApprovalSumOrderByAggregateInput
  }

  export type TosApprovalScalarWhereWithAggregatesInput = {
    AND?: Enumerable<TosApprovalScalarWhereWithAggregatesInput>
    OR?: Enumerable<TosApprovalScalarWhereWithAggregatesInput>
    NOT?: Enumerable<TosApprovalScalarWhereWithAggregatesInput>
    id?: IntWithAggregatesFilter | number
    address?: StringWithAggregatesFilter | string
    signature?: StringWithAggregatesFilter | string
    message?: StringWithAggregatesFilter | string
    chain_id?: IntWithAggregatesFilter | number
    doc_version?: StringWithAggregatesFilter | string
    sign_date?: DateTimeWithAggregatesFilter | Date | string
  }

  export type VaultWhereInput = {
    AND?: Enumerable<VaultWhereInput>
    OR?: Enumerable<VaultWhereInput>
    NOT?: Enumerable<VaultWhereInput>
    vault_id?: IntFilter | number
    type?: EnumVaultTypeFilter | VaultType
    owner_address?: StringFilter | string
    chain_id?: IntNullableFilter | number | null
    protocol?: StringFilter | string
  }

  export type VaultOrderByWithRelationInput = {
    vault_id?: SortOrder
    type?: SortOrder
    owner_address?: SortOrder
    chain_id?: SortOrderInput | SortOrder
    protocol?: SortOrder
  }

  export type VaultWhereUniqueInput = {
    vault_id?: number
    vault_vault_id_chain_id_unique_constraint?: VaultVault_vault_id_chain_id_unique_constraintCompoundUniqueInput
  }

  export type VaultOrderByWithAggregationInput = {
    vault_id?: SortOrder
    type?: SortOrder
    owner_address?: SortOrder
    chain_id?: SortOrderInput | SortOrder
    protocol?: SortOrder
    _count?: VaultCountOrderByAggregateInput
    _avg?: VaultAvgOrderByAggregateInput
    _max?: VaultMaxOrderByAggregateInput
    _min?: VaultMinOrderByAggregateInput
    _sum?: VaultSumOrderByAggregateInput
  }

  export type VaultScalarWhereWithAggregatesInput = {
    AND?: Enumerable<VaultScalarWhereWithAggregatesInput>
    OR?: Enumerable<VaultScalarWhereWithAggregatesInput>
    NOT?: Enumerable<VaultScalarWhereWithAggregatesInput>
    vault_id?: IntWithAggregatesFilter | number
    type?: EnumVaultTypeWithAggregatesFilter | VaultType
    owner_address?: StringWithAggregatesFilter | string
    chain_id?: IntNullableWithAggregatesFilter | number | null
    protocol?: StringWithAggregatesFilter | string
  }

  export type UserWhereInput = {
    AND?: Enumerable<UserWhereInput>
    OR?: Enumerable<UserWhereInput>
    NOT?: Enumerable<UserWhereInput>
    address?: StringFilter | string
    timestamp?: DateTimeFilter | Date | string
    user_that_referred_address?: StringNullableFilter | string | null
    accepted?: BoolFilter | boolean
    user_that_referred?: XOR<UserRelationFilter, UserWhereInput> | null
    referred_users?: UserListRelationFilter
    weekly_claims?: WeeklyClaimListRelationFilter
  }

  export type UserOrderByWithRelationInput = {
    address?: SortOrder
    timestamp?: SortOrder
    user_that_referred_address?: SortOrderInput | SortOrder
    accepted?: SortOrder
    user_that_referred?: UserOrderByWithRelationInput
    referred_users?: UserOrderByRelationAggregateInput
    weekly_claims?: WeeklyClaimOrderByRelationAggregateInput
  }

  export type UserWhereUniqueInput = {
    address?: string
  }

  export type UserOrderByWithAggregationInput = {
    address?: SortOrder
    timestamp?: SortOrder
    user_that_referred_address?: SortOrderInput | SortOrder
    accepted?: SortOrder
    _count?: UserCountOrderByAggregateInput
    _max?: UserMaxOrderByAggregateInput
    _min?: UserMinOrderByAggregateInput
  }

  export type UserScalarWhereWithAggregatesInput = {
    AND?: Enumerable<UserScalarWhereWithAggregatesInput>
    OR?: Enumerable<UserScalarWhereWithAggregatesInput>
    NOT?: Enumerable<UserScalarWhereWithAggregatesInput>
    address?: StringWithAggregatesFilter | string
    timestamp?: DateTimeWithAggregatesFilter | Date | string
    user_that_referred_address?: StringNullableWithAggregatesFilter | string | null
    accepted?: BoolWithAggregatesFilter | boolean
  }

  export type WeeklyClaimWhereInput = {
    AND?: Enumerable<WeeklyClaimWhereInput>
    OR?: Enumerable<WeeklyClaimWhereInput>
    NOT?: Enumerable<WeeklyClaimWhereInput>
    id?: IntFilter | number
    timestamp?: DateTimeNullableFilter | Date | string | null
    week_number?: IntFilter | number
    user_address?: StringFilter | string
    proof?: StringNullableListFilter
    amount?: StringFilter | string
    claimant?: XOR<UserRelationFilter, UserWhereInput>
  }

  export type WeeklyClaimOrderByWithRelationInput = {
    id?: SortOrder
    timestamp?: SortOrderInput | SortOrder
    week_number?: SortOrder
    user_address?: SortOrder
    proof?: SortOrder
    amount?: SortOrder
    claimant?: UserOrderByWithRelationInput
  }

  export type WeeklyClaimWhereUniqueInput = {
    id?: number
    week_number_userAddress_unique_id?: WeeklyClaimWeek_number_userAddress_unique_idCompoundUniqueInput
  }

  export type WeeklyClaimOrderByWithAggregationInput = {
    id?: SortOrder
    timestamp?: SortOrderInput | SortOrder
    week_number?: SortOrder
    user_address?: SortOrder
    proof?: SortOrder
    amount?: SortOrder
    _count?: WeeklyClaimCountOrderByAggregateInput
    _avg?: WeeklyClaimAvgOrderByAggregateInput
    _max?: WeeklyClaimMaxOrderByAggregateInput
    _min?: WeeklyClaimMinOrderByAggregateInput
    _sum?: WeeklyClaimSumOrderByAggregateInput
  }

  export type WeeklyClaimScalarWhereWithAggregatesInput = {
    AND?: Enumerable<WeeklyClaimScalarWhereWithAggregatesInput>
    OR?: Enumerable<WeeklyClaimScalarWhereWithAggregatesInput>
    NOT?: Enumerable<WeeklyClaimScalarWhereWithAggregatesInput>
    id?: IntWithAggregatesFilter | number
    timestamp?: DateTimeNullableWithAggregatesFilter | Date | string | null
    week_number?: IntWithAggregatesFilter | number
    user_address?: StringWithAggregatesFilter | string
    proof?: StringNullableListFilter
    amount?: StringWithAggregatesFilter | string
  }

  export type MerkleTreeWhereInput = {
    AND?: Enumerable<MerkleTreeWhereInput>
    OR?: Enumerable<MerkleTreeWhereInput>
    NOT?: Enumerable<MerkleTreeWhereInput>
    week_number?: IntFilter | number
    start_block?: IntNullableFilter | number | null
    end_block?: IntNullableFilter | number | null
    timestamp?: DateTimeNullableFilter | Date | string | null
    tree_root?: StringFilter | string
    snapshot?: StringNullableFilter | string | null
  }

  export type MerkleTreeOrderByWithRelationInput = {
    week_number?: SortOrder
    start_block?: SortOrderInput | SortOrder
    end_block?: SortOrderInput | SortOrder
    timestamp?: SortOrderInput | SortOrder
    tree_root?: SortOrder
    snapshot?: SortOrderInput | SortOrder
  }

  export type MerkleTreeWhereUniqueInput = {
    week_number?: number
  }

  export type MerkleTreeOrderByWithAggregationInput = {
    week_number?: SortOrder
    start_block?: SortOrderInput | SortOrder
    end_block?: SortOrderInput | SortOrder
    timestamp?: SortOrderInput | SortOrder
    tree_root?: SortOrder
    snapshot?: SortOrderInput | SortOrder
    _count?: MerkleTreeCountOrderByAggregateInput
    _avg?: MerkleTreeAvgOrderByAggregateInput
    _max?: MerkleTreeMaxOrderByAggregateInput
    _min?: MerkleTreeMinOrderByAggregateInput
    _sum?: MerkleTreeSumOrderByAggregateInput
  }

  export type MerkleTreeScalarWhereWithAggregatesInput = {
    AND?: Enumerable<MerkleTreeScalarWhereWithAggregatesInput>
    OR?: Enumerable<MerkleTreeScalarWhereWithAggregatesInput>
    NOT?: Enumerable<MerkleTreeScalarWhereWithAggregatesInput>
    week_number?: IntWithAggregatesFilter | number
    start_block?: IntNullableWithAggregatesFilter | number | null
    end_block?: IntNullableWithAggregatesFilter | number | null
    timestamp?: DateTimeNullableWithAggregatesFilter | Date | string | null
    tree_root?: StringWithAggregatesFilter | string
    snapshot?: StringNullableWithAggregatesFilter | string | null
  }

  export type WalletRiskWhereInput = {
    AND?: Enumerable<WalletRiskWhereInput>
    OR?: Enumerable<WalletRiskWhereInput>
    NOT?: Enumerable<WalletRiskWhereInput>
    address?: StringFilter | string
    last_check?: DateTimeFilter | Date | string
    is_risky?: BoolFilter | boolean
  }

  export type WalletRiskOrderByWithRelationInput = {
    address?: SortOrder
    last_check?: SortOrder
    is_risky?: SortOrder
  }

  export type WalletRiskWhereUniqueInput = {
    address?: string
  }

  export type WalletRiskOrderByWithAggregationInput = {
    address?: SortOrder
    last_check?: SortOrder
    is_risky?: SortOrder
    _count?: WalletRiskCountOrderByAggregateInput
    _max?: WalletRiskMaxOrderByAggregateInput
    _min?: WalletRiskMinOrderByAggregateInput
  }

  export type WalletRiskScalarWhereWithAggregatesInput = {
    AND?: Enumerable<WalletRiskScalarWhereWithAggregatesInput>
    OR?: Enumerable<WalletRiskScalarWhereWithAggregatesInput>
    NOT?: Enumerable<WalletRiskScalarWhereWithAggregatesInput>
    address?: StringWithAggregatesFilter | string
    last_check?: DateTimeWithAggregatesFilter | Date | string
    is_risky?: BoolWithAggregatesFilter | boolean
  }

  export type CollateralTypeWhereInput = {
    AND?: Enumerable<CollateralTypeWhereInput>
    OR?: Enumerable<CollateralTypeWhereInput>
    NOT?: Enumerable<CollateralTypeWhereInput>
    collateral_name?: StringFilter | string
    token?: StringFilter | string
    next_price?: DecimalFilter | Decimal | DecimalJsLike | number | string
    current_price?: DecimalFilter | Decimal | DecimalJsLike | number | string
    liquidation_ratio?: DecimalFilter | Decimal | DecimalJsLike | number | string
    liquidation_penalty?: DecimalFilter | Decimal | DecimalJsLike | number | string
    rate?: DecimalNullableFilter | Decimal | DecimalJsLike | number | string | null
    market_price?: DecimalNullableFilter | Decimal | DecimalJsLike | number | string | null
  }

  export type CollateralTypeOrderByWithRelationInput = {
    collateral_name?: SortOrder
    token?: SortOrder
    next_price?: SortOrder
    current_price?: SortOrder
    liquidation_ratio?: SortOrder
    liquidation_penalty?: SortOrder
    rate?: SortOrderInput | SortOrder
    market_price?: SortOrderInput | SortOrder
  }

  export type CollateralTypeWhereUniqueInput = {
    collateral_name?: string
  }

  export type CollateralTypeOrderByWithAggregationInput = {
    collateral_name?: SortOrder
    token?: SortOrder
    next_price?: SortOrder
    current_price?: SortOrder
    liquidation_ratio?: SortOrder
    liquidation_penalty?: SortOrder
    rate?: SortOrderInput | SortOrder
    market_price?: SortOrderInput | SortOrder
    _count?: CollateralTypeCountOrderByAggregateInput
    _avg?: CollateralTypeAvgOrderByAggregateInput
    _max?: CollateralTypeMaxOrderByAggregateInput
    _min?: CollateralTypeMinOrderByAggregateInput
    _sum?: CollateralTypeSumOrderByAggregateInput
  }

  export type CollateralTypeScalarWhereWithAggregatesInput = {
    AND?: Enumerable<CollateralTypeScalarWhereWithAggregatesInput>
    OR?: Enumerable<CollateralTypeScalarWhereWithAggregatesInput>
    NOT?: Enumerable<CollateralTypeScalarWhereWithAggregatesInput>
    collateral_name?: StringWithAggregatesFilter | string
    token?: StringWithAggregatesFilter | string
    next_price?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    current_price?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    liquidation_ratio?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    liquidation_penalty?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    rate?: DecimalNullableWithAggregatesFilter | Decimal | DecimalJsLike | number | string | null
    market_price?: DecimalNullableWithAggregatesFilter | Decimal | DecimalJsLike | number | string | null
  }

  export type DiscoverWhereInput = {
    AND?: Enumerable<DiscoverWhereInput>
    OR?: Enumerable<DiscoverWhereInput>
    NOT?: Enumerable<DiscoverWhereInput>
    protocol_id?: StringFilter | string
    position_id?: StringFilter | string
    collateral_type?: StringFilter | string
    vault_debt?: DecimalFilter | Decimal | DecimalJsLike | number | string
    vault_normalized_debt?: DecimalNullableFilter | Decimal | DecimalJsLike | number | string | null
    vault_collateral?: DecimalFilter | Decimal | DecimalJsLike | number | string
    yield_30d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    status?: JsonFilter
    last_action?: JsonFilter
    pnl_all?: DecimalFilter | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalFilter | Decimal | DecimalJsLike | number | string
    net_profit_all?: DecimalFilter | Decimal | DecimalJsLike | number | string
    net_profit_1d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    net_profit_7d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    net_profit_30d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    net_profit_365d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    net_profit_ytd?: DecimalFilter | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeFilter | Date | string
    updatedAt?: DateTimeFilter | Date | string
  }

  export type DiscoverOrderByWithRelationInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    vault_debt?: SortOrder
    vault_normalized_debt?: SortOrderInput | SortOrder
    vault_collateral?: SortOrder
    yield_30d?: SortOrder
    status?: SortOrder
    last_action?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    net_profit_all?: SortOrder
    net_profit_1d?: SortOrder
    net_profit_7d?: SortOrder
    net_profit_30d?: SortOrder
    net_profit_365d?: SortOrder
    net_profit_ytd?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type DiscoverWhereUniqueInput = {
    protocol_id_position_id?: DiscoverProtocol_idPosition_idCompoundUniqueInput
  }

  export type DiscoverOrderByWithAggregationInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    vault_debt?: SortOrder
    vault_normalized_debt?: SortOrderInput | SortOrder
    vault_collateral?: SortOrder
    yield_30d?: SortOrder
    status?: SortOrder
    last_action?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    net_profit_all?: SortOrder
    net_profit_1d?: SortOrder
    net_profit_7d?: SortOrder
    net_profit_30d?: SortOrder
    net_profit_365d?: SortOrder
    net_profit_ytd?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: DiscoverCountOrderByAggregateInput
    _avg?: DiscoverAvgOrderByAggregateInput
    _max?: DiscoverMaxOrderByAggregateInput
    _min?: DiscoverMinOrderByAggregateInput
    _sum?: DiscoverSumOrderByAggregateInput
  }

  export type DiscoverScalarWhereWithAggregatesInput = {
    AND?: Enumerable<DiscoverScalarWhereWithAggregatesInput>
    OR?: Enumerable<DiscoverScalarWhereWithAggregatesInput>
    NOT?: Enumerable<DiscoverScalarWhereWithAggregatesInput>
    protocol_id?: StringWithAggregatesFilter | string
    position_id?: StringWithAggregatesFilter | string
    collateral_type?: StringWithAggregatesFilter | string
    vault_debt?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    vault_normalized_debt?: DecimalNullableWithAggregatesFilter | Decimal | DecimalJsLike | number | string | null
    vault_collateral?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    yield_30d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    status?: JsonWithAggregatesFilter
    last_action?: JsonWithAggregatesFilter
    pnl_all?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    net_profit_all?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    net_profit_1d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    net_profit_7d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    net_profit_30d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    net_profit_365d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    net_profit_ytd?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeWithAggregatesFilter | Date | string
    updatedAt?: DateTimeWithAggregatesFilter | Date | string
  }

  export type HighestRiskPositionsWhereInput = {
    AND?: Enumerable<HighestRiskPositionsWhereInput>
    OR?: Enumerable<HighestRiskPositionsWhereInput>
    NOT?: Enumerable<HighestRiskPositionsWhereInput>
    protocol_id?: StringFilter | string
    position_id?: StringFilter | string
    collateral_type?: StringFilter | string
    token?: StringFilter | string
    collateral_ratio?: DecimalFilter | Decimal | DecimalJsLike | number | string
    collateral_value?: DecimalFilter | Decimal | DecimalJsLike | number | string
    liquidation_proximity?: DecimalFilter | Decimal | DecimalJsLike | number | string
    liquidation_price?: DecimalFilter | Decimal | DecimalJsLike | number | string
    liquidation_value?: DecimalFilter | Decimal | DecimalJsLike | number | string
    next_price?: DecimalFilter | Decimal | DecimalJsLike | number | string
    status?: JsonFilter
    type?: EnumVaultTypeNullableFilter | VaultType | null
  }

  export type HighestRiskPositionsOrderByWithRelationInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_ratio?: SortOrder
    collateral_value?: SortOrder
    liquidation_proximity?: SortOrder
    liquidation_price?: SortOrder
    liquidation_value?: SortOrder
    next_price?: SortOrder
    status?: SortOrder
    type?: SortOrderInput | SortOrder
  }

  export type HighestRiskPositionsWhereUniqueInput = {
    protocol_id_position_id?: HighestRiskPositionsProtocol_id_position_idCompoundUniqueInput
  }

  export type HighestRiskPositionsOrderByWithAggregationInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_ratio?: SortOrder
    collateral_value?: SortOrder
    liquidation_proximity?: SortOrder
    liquidation_price?: SortOrder
    liquidation_value?: SortOrder
    next_price?: SortOrder
    status?: SortOrder
    type?: SortOrderInput | SortOrder
    _count?: HighestRiskPositionsCountOrderByAggregateInput
    _avg?: HighestRiskPositionsAvgOrderByAggregateInput
    _max?: HighestRiskPositionsMaxOrderByAggregateInput
    _min?: HighestRiskPositionsMinOrderByAggregateInput
    _sum?: HighestRiskPositionsSumOrderByAggregateInput
  }

  export type HighestRiskPositionsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<HighestRiskPositionsScalarWhereWithAggregatesInput>
    OR?: Enumerable<HighestRiskPositionsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<HighestRiskPositionsScalarWhereWithAggregatesInput>
    protocol_id?: StringWithAggregatesFilter | string
    position_id?: StringWithAggregatesFilter | string
    collateral_type?: StringWithAggregatesFilter | string
    token?: StringWithAggregatesFilter | string
    collateral_ratio?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    collateral_value?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    liquidation_proximity?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    liquidation_price?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    liquidation_value?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    next_price?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    status?: JsonWithAggregatesFilter
    type?: EnumVaultTypeNullableWithAggregatesFilter | VaultType | null
  }

  export type HighestMultiplyPnlWhereInput = {
    AND?: Enumerable<HighestMultiplyPnlWhereInput>
    OR?: Enumerable<HighestMultiplyPnlWhereInput>
    NOT?: Enumerable<HighestMultiplyPnlWhereInput>
    protocol_id?: StringFilter | string
    position_id?: StringFilter | string
    collateral_type?: StringFilter | string
    token?: StringFilter | string
    collateral_value?: DecimalFilter | Decimal | DecimalJsLike | number | string
    vault_multiple?: DecimalFilter | Decimal | DecimalJsLike | number | string
    pnl_all?: DecimalFilter | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalFilter | Decimal | DecimalJsLike | number | string
    net_profit_all?: DecimalFilter | Decimal | DecimalJsLike | number | string
    net_profit_1d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    net_profit_7d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    net_profit_30d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    net_profit_365d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    net_profit_ytd?: DecimalFilter | Decimal | DecimalJsLike | number | string
    last_action?: JsonFilter
    type?: EnumVaultTypeNullableFilter | VaultType | null
  }

  export type HighestMultiplyPnlOrderByWithRelationInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_value?: SortOrder
    vault_multiple?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    net_profit_all?: SortOrder
    net_profit_1d?: SortOrder
    net_profit_7d?: SortOrder
    net_profit_30d?: SortOrder
    net_profit_365d?: SortOrder
    net_profit_ytd?: SortOrder
    last_action?: SortOrder
    type?: SortOrderInput | SortOrder
  }

  export type HighestMultiplyPnlWhereUniqueInput = {
    protocol_id_position_id?: HighestMultiplyPnlProtocol_id_position_idCompoundUniqueInput
  }

  export type HighestMultiplyPnlOrderByWithAggregationInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_value?: SortOrder
    vault_multiple?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    net_profit_all?: SortOrder
    net_profit_1d?: SortOrder
    net_profit_7d?: SortOrder
    net_profit_30d?: SortOrder
    net_profit_365d?: SortOrder
    net_profit_ytd?: SortOrder
    last_action?: SortOrder
    type?: SortOrderInput | SortOrder
    _count?: HighestMultiplyPnlCountOrderByAggregateInput
    _avg?: HighestMultiplyPnlAvgOrderByAggregateInput
    _max?: HighestMultiplyPnlMaxOrderByAggregateInput
    _min?: HighestMultiplyPnlMinOrderByAggregateInput
    _sum?: HighestMultiplyPnlSumOrderByAggregateInput
  }

  export type HighestMultiplyPnlScalarWhereWithAggregatesInput = {
    AND?: Enumerable<HighestMultiplyPnlScalarWhereWithAggregatesInput>
    OR?: Enumerable<HighestMultiplyPnlScalarWhereWithAggregatesInput>
    NOT?: Enumerable<HighestMultiplyPnlScalarWhereWithAggregatesInput>
    protocol_id?: StringWithAggregatesFilter | string
    position_id?: StringWithAggregatesFilter | string
    collateral_type?: StringWithAggregatesFilter | string
    token?: StringWithAggregatesFilter | string
    collateral_value?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    vault_multiple?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    pnl_all?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    net_profit_all?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    net_profit_1d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    net_profit_7d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    net_profit_30d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    net_profit_365d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    net_profit_ytd?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    last_action?: JsonWithAggregatesFilter
    type?: EnumVaultTypeNullableWithAggregatesFilter | VaultType | null
  }

  export type MostYieldEarnedWhereInput = {
    AND?: Enumerable<MostYieldEarnedWhereInput>
    OR?: Enumerable<MostYieldEarnedWhereInput>
    NOT?: Enumerable<MostYieldEarnedWhereInput>
    protocol_id?: StringFilter | string
    position_id?: StringFilter | string
    collateral_type?: StringFilter | string
    token?: StringFilter | string
    collateral_value?: DecimalFilter | Decimal | DecimalJsLike | number | string
    net_value?: DecimalFilter | Decimal | DecimalJsLike | number | string
    pnl_all?: DecimalFilter | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalFilter | Decimal | DecimalJsLike | number | string
    yield_30d?: DecimalFilter | Decimal | DecimalJsLike | number | string
    last_action?: JsonFilter
    type?: EnumVaultTypeNullableFilter | VaultType | null
  }

  export type MostYieldEarnedOrderByWithRelationInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_value?: SortOrder
    net_value?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    yield_30d?: SortOrder
    last_action?: SortOrder
    type?: SortOrderInput | SortOrder
  }

  export type MostYieldEarnedWhereUniqueInput = {
    protocol_id_position_id?: MostYieldEarnedProtocol_id_position_idCompoundUniqueInput
  }

  export type MostYieldEarnedOrderByWithAggregationInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_value?: SortOrder
    net_value?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    yield_30d?: SortOrder
    last_action?: SortOrder
    type?: SortOrderInput | SortOrder
    _count?: MostYieldEarnedCountOrderByAggregateInput
    _avg?: MostYieldEarnedAvgOrderByAggregateInput
    _max?: MostYieldEarnedMaxOrderByAggregateInput
    _min?: MostYieldEarnedMinOrderByAggregateInput
    _sum?: MostYieldEarnedSumOrderByAggregateInput
  }

  export type MostYieldEarnedScalarWhereWithAggregatesInput = {
    AND?: Enumerable<MostYieldEarnedScalarWhereWithAggregatesInput>
    OR?: Enumerable<MostYieldEarnedScalarWhereWithAggregatesInput>
    NOT?: Enumerable<MostYieldEarnedScalarWhereWithAggregatesInput>
    protocol_id?: StringWithAggregatesFilter | string
    position_id?: StringWithAggregatesFilter | string
    collateral_type?: StringWithAggregatesFilter | string
    token?: StringWithAggregatesFilter | string
    collateral_value?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    net_value?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    pnl_all?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    yield_30d?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    last_action?: JsonWithAggregatesFilter
    type?: EnumVaultTypeNullableWithAggregatesFilter | VaultType | null
  }

  export type LargestDebtWhereInput = {
    AND?: Enumerable<LargestDebtWhereInput>
    OR?: Enumerable<LargestDebtWhereInput>
    NOT?: Enumerable<LargestDebtWhereInput>
    protocol_id?: StringFilter | string
    position_id?: StringFilter | string
    collateral_type?: StringFilter | string
    token?: StringFilter | string
    collateral_value?: DecimalFilter | Decimal | DecimalJsLike | number | string
    liquidation_proximity?: DecimalFilter | Decimal | DecimalJsLike | number | string
    vault_debt?: DecimalFilter | Decimal | DecimalJsLike | number | string
    coll_ratio?: DecimalFilter | Decimal | DecimalJsLike | number | string
    last_action?: JsonFilter
    type?: EnumVaultTypeNullableFilter | VaultType | null
  }

  export type LargestDebtOrderByWithRelationInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_value?: SortOrder
    liquidation_proximity?: SortOrder
    vault_debt?: SortOrder
    coll_ratio?: SortOrder
    last_action?: SortOrder
    type?: SortOrderInput | SortOrder
  }

  export type LargestDebtWhereUniqueInput = {
    protocol_id_position_id?: LargestDebtProtocol_id_position_idCompoundUniqueInput
  }

  export type LargestDebtOrderByWithAggregationInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_value?: SortOrder
    liquidation_proximity?: SortOrder
    vault_debt?: SortOrder
    coll_ratio?: SortOrder
    last_action?: SortOrder
    type?: SortOrderInput | SortOrder
    _count?: LargestDebtCountOrderByAggregateInput
    _avg?: LargestDebtAvgOrderByAggregateInput
    _max?: LargestDebtMaxOrderByAggregateInput
    _min?: LargestDebtMinOrderByAggregateInput
    _sum?: LargestDebtSumOrderByAggregateInput
  }

  export type LargestDebtScalarWhereWithAggregatesInput = {
    AND?: Enumerable<LargestDebtScalarWhereWithAggregatesInput>
    OR?: Enumerable<LargestDebtScalarWhereWithAggregatesInput>
    NOT?: Enumerable<LargestDebtScalarWhereWithAggregatesInput>
    protocol_id?: StringWithAggregatesFilter | string
    position_id?: StringWithAggregatesFilter | string
    collateral_type?: StringWithAggregatesFilter | string
    token?: StringWithAggregatesFilter | string
    collateral_value?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    liquidation_proximity?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    vault_debt?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    coll_ratio?: DecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    last_action?: JsonWithAggregatesFilter
    type?: EnumVaultTypeNullableWithAggregatesFilter | VaultType | null
  }

  export type UsersWhoFollowVaultsWhereInput = {
    AND?: Enumerable<UsersWhoFollowVaultsWhereInput>
    OR?: Enumerable<UsersWhoFollowVaultsWhereInput>
    NOT?: Enumerable<UsersWhoFollowVaultsWhereInput>
    user_address?: StringFilter | string
    vault_id?: IntFilter | number
    vault_chain_id?: IntFilter | number
    protocol?: EnumProtocolFilter | Protocol
  }

  export type UsersWhoFollowVaultsOrderByWithRelationInput = {
    user_address?: SortOrder
    vault_id?: SortOrder
    vault_chain_id?: SortOrder
    protocol?: SortOrder
  }

  export type UsersWhoFollowVaultsWhereUniqueInput = {
    user_address_vault_id_vault_chain_id_protocol?: UsersWhoFollowVaultsUser_addressVault_idVault_chain_idProtocolCompoundUniqueInput
  }

  export type UsersWhoFollowVaultsOrderByWithAggregationInput = {
    user_address?: SortOrder
    vault_id?: SortOrder
    vault_chain_id?: SortOrder
    protocol?: SortOrder
    _count?: UsersWhoFollowVaultsCountOrderByAggregateInput
    _avg?: UsersWhoFollowVaultsAvgOrderByAggregateInput
    _max?: UsersWhoFollowVaultsMaxOrderByAggregateInput
    _min?: UsersWhoFollowVaultsMinOrderByAggregateInput
    _sum?: UsersWhoFollowVaultsSumOrderByAggregateInput
  }

  export type UsersWhoFollowVaultsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<UsersWhoFollowVaultsScalarWhereWithAggregatesInput>
    OR?: Enumerable<UsersWhoFollowVaultsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<UsersWhoFollowVaultsScalarWhereWithAggregatesInput>
    user_address?: StringWithAggregatesFilter | string
    vault_id?: IntWithAggregatesFilter | number
    vault_chain_id?: IntWithAggregatesFilter | number
    protocol?: EnumProtocolWithAggregatesFilter | Protocol
  }

  export type ProductHubItemsWhereInput = {
    AND?: Enumerable<ProductHubItemsWhereInput>
    OR?: Enumerable<ProductHubItemsWhereInput>
    NOT?: Enumerable<ProductHubItemsWhereInput>
    id?: StringFilter | string
    label?: StringFilter | string
    network?: EnumNetworkNamesFilter | NetworkNames
    primaryToken?: StringFilter | string
    primaryTokenGroup?: StringNullableFilter | string | null
    product?: EnumProductNullableListFilter
    protocol?: EnumProtocolFilter | Protocol
    secondaryToken?: StringFilter | string
    secondaryTokenGroup?: StringNullableFilter | string | null
    weeklyNetApy?: StringNullableFilter | string | null
    depositToken?: StringNullableFilter | string | null
    earnStrategy?: StringNullableFilter | string | null
    fee?: StringNullableFilter | string | null
    liquidity?: StringNullableFilter | string | null
    managementType?: EnumProductHubManagementSimpleNullableFilter | ProductHubManagementSimple | null
    maxLtv?: StringNullableFilter | string | null
    maxMultiply?: StringNullableFilter | string | null
    multiplyStrategy?: StringNullableFilter | string | null
    multiplyStrategyType?: EnumProductHubStrategyNullableFilter | ProductHubStrategy | null
    reverseTokens?: BoolNullableFilter | boolean | null
    updatedAt?: DateTimeFilter | Date | string
  }

  export type ProductHubItemsOrderByWithRelationInput = {
    id?: SortOrder
    label?: SortOrder
    network?: SortOrder
    primaryToken?: SortOrder
    primaryTokenGroup?: SortOrderInput | SortOrder
    product?: SortOrder
    protocol?: SortOrder
    secondaryToken?: SortOrder
    secondaryTokenGroup?: SortOrderInput | SortOrder
    weeklyNetApy?: SortOrderInput | SortOrder
    depositToken?: SortOrderInput | SortOrder
    earnStrategy?: SortOrderInput | SortOrder
    fee?: SortOrderInput | SortOrder
    liquidity?: SortOrderInput | SortOrder
    managementType?: SortOrderInput | SortOrder
    maxLtv?: SortOrderInput | SortOrder
    maxMultiply?: SortOrderInput | SortOrder
    multiplyStrategy?: SortOrderInput | SortOrder
    multiplyStrategyType?: SortOrderInput | SortOrder
    reverseTokens?: SortOrderInput | SortOrder
    updatedAt?: SortOrder
  }

  export type ProductHubItemsWhereUniqueInput = {
    id?: string
    product_hub_item_id?: ProductHubItemsProduct_hub_item_idCompoundUniqueInput
  }

  export type ProductHubItemsOrderByWithAggregationInput = {
    id?: SortOrder
    label?: SortOrder
    network?: SortOrder
    primaryToken?: SortOrder
    primaryTokenGroup?: SortOrderInput | SortOrder
    product?: SortOrder
    protocol?: SortOrder
    secondaryToken?: SortOrder
    secondaryTokenGroup?: SortOrderInput | SortOrder
    weeklyNetApy?: SortOrderInput | SortOrder
    depositToken?: SortOrderInput | SortOrder
    earnStrategy?: SortOrderInput | SortOrder
    fee?: SortOrderInput | SortOrder
    liquidity?: SortOrderInput | SortOrder
    managementType?: SortOrderInput | SortOrder
    maxLtv?: SortOrderInput | SortOrder
    maxMultiply?: SortOrderInput | SortOrder
    multiplyStrategy?: SortOrderInput | SortOrder
    multiplyStrategyType?: SortOrderInput | SortOrder
    reverseTokens?: SortOrderInput | SortOrder
    updatedAt?: SortOrder
    _count?: ProductHubItemsCountOrderByAggregateInput
    _max?: ProductHubItemsMaxOrderByAggregateInput
    _min?: ProductHubItemsMinOrderByAggregateInput
  }

  export type ProductHubItemsScalarWhereWithAggregatesInput = {
    AND?: Enumerable<ProductHubItemsScalarWhereWithAggregatesInput>
    OR?: Enumerable<ProductHubItemsScalarWhereWithAggregatesInput>
    NOT?: Enumerable<ProductHubItemsScalarWhereWithAggregatesInput>
    id?: StringWithAggregatesFilter | string
    label?: StringWithAggregatesFilter | string
    network?: EnumNetworkNamesWithAggregatesFilter | NetworkNames
    primaryToken?: StringWithAggregatesFilter | string
    primaryTokenGroup?: StringNullableWithAggregatesFilter | string | null
    product?: EnumProductNullableListFilter
    protocol?: EnumProtocolWithAggregatesFilter | Protocol
    secondaryToken?: StringWithAggregatesFilter | string
    secondaryTokenGroup?: StringNullableWithAggregatesFilter | string | null
    weeklyNetApy?: StringNullableWithAggregatesFilter | string | null
    depositToken?: StringNullableWithAggregatesFilter | string | null
    earnStrategy?: StringNullableWithAggregatesFilter | string | null
    fee?: StringNullableWithAggregatesFilter | string | null
    liquidity?: StringNullableWithAggregatesFilter | string | null
    managementType?: EnumProductHubManagementSimpleNullableWithAggregatesFilter | ProductHubManagementSimple | null
    maxLtv?: StringNullableWithAggregatesFilter | string | null
    maxMultiply?: StringNullableWithAggregatesFilter | string | null
    multiplyStrategy?: StringNullableWithAggregatesFilter | string | null
    multiplyStrategyType?: EnumProductHubStrategyNullableWithAggregatesFilter | ProductHubStrategy | null
    reverseTokens?: BoolNullableWithAggregatesFilter | boolean | null
    updatedAt?: DateTimeWithAggregatesFilter | Date | string
  }

  export type AjnaRewardsWeeklyClaimWhereInput = {
    AND?: Enumerable<AjnaRewardsWeeklyClaimWhereInput>
    OR?: Enumerable<AjnaRewardsWeeklyClaimWhereInput>
    NOT?: Enumerable<AjnaRewardsWeeklyClaimWhereInput>
    id?: IntFilter | number
    timestamp?: DateTimeFilter | Date | string
    chain_id?: IntFilter | number
    user_address?: StringFilter | string
    amount?: StringFilter | string
    week_number?: IntFilter | number
    proof?: StringNullableListFilter
  }

  export type AjnaRewardsWeeklyClaimOrderByWithRelationInput = {
    id?: SortOrder
    timestamp?: SortOrder
    chain_id?: SortOrder
    user_address?: SortOrder
    amount?: SortOrder
    week_number?: SortOrder
    proof?: SortOrder
  }

  export type AjnaRewardsWeeklyClaimWhereUniqueInput = {
    id?: number
    week_number_userAddress_chain_id_unique_id?: AjnaRewardsWeeklyClaimWeek_number_userAddress_chain_id_unique_idCompoundUniqueInput
  }

  export type AjnaRewardsWeeklyClaimOrderByWithAggregationInput = {
    id?: SortOrder
    timestamp?: SortOrder
    chain_id?: SortOrder
    user_address?: SortOrder
    amount?: SortOrder
    week_number?: SortOrder
    proof?: SortOrder
    _count?: AjnaRewardsWeeklyClaimCountOrderByAggregateInput
    _avg?: AjnaRewardsWeeklyClaimAvgOrderByAggregateInput
    _max?: AjnaRewardsWeeklyClaimMaxOrderByAggregateInput
    _min?: AjnaRewardsWeeklyClaimMinOrderByAggregateInput
    _sum?: AjnaRewardsWeeklyClaimSumOrderByAggregateInput
  }

  export type AjnaRewardsWeeklyClaimScalarWhereWithAggregatesInput = {
    AND?: Enumerable<AjnaRewardsWeeklyClaimScalarWhereWithAggregatesInput>
    OR?: Enumerable<AjnaRewardsWeeklyClaimScalarWhereWithAggregatesInput>
    NOT?: Enumerable<AjnaRewardsWeeklyClaimScalarWhereWithAggregatesInput>
    id?: IntWithAggregatesFilter | number
    timestamp?: DateTimeWithAggregatesFilter | Date | string
    chain_id?: IntWithAggregatesFilter | number
    user_address?: StringWithAggregatesFilter | string
    amount?: StringWithAggregatesFilter | string
    week_number?: IntWithAggregatesFilter | number
    proof?: StringNullableListFilter
  }

  export type AjnaRewardsDailyClaimWhereInput = {
    AND?: Enumerable<AjnaRewardsDailyClaimWhereInput>
    OR?: Enumerable<AjnaRewardsDailyClaimWhereInput>
    NOT?: Enumerable<AjnaRewardsDailyClaimWhereInput>
    id?: IntFilter | number
    timestamp?: DateTimeFilter | Date | string
    chain_id?: IntFilter | number
    user_address?: StringFilter | string
    amount?: StringFilter | string
    week_number?: IntFilter | number
    day_number?: IntFilter | number
  }

  export type AjnaRewardsDailyClaimOrderByWithRelationInput = {
    id?: SortOrder
    timestamp?: SortOrder
    chain_id?: SortOrder
    user_address?: SortOrder
    amount?: SortOrder
    week_number?: SortOrder
    day_number?: SortOrder
  }

  export type AjnaRewardsDailyClaimWhereUniqueInput = {
    id?: number
    day_number_userAddress_chain_id_unique_id?: AjnaRewardsDailyClaimDay_number_userAddress_chain_id_unique_idCompoundUniqueInput
  }

  export type AjnaRewardsDailyClaimOrderByWithAggregationInput = {
    id?: SortOrder
    timestamp?: SortOrder
    chain_id?: SortOrder
    user_address?: SortOrder
    amount?: SortOrder
    week_number?: SortOrder
    day_number?: SortOrder
    _count?: AjnaRewardsDailyClaimCountOrderByAggregateInput
    _avg?: AjnaRewardsDailyClaimAvgOrderByAggregateInput
    _max?: AjnaRewardsDailyClaimMaxOrderByAggregateInput
    _min?: AjnaRewardsDailyClaimMinOrderByAggregateInput
    _sum?: AjnaRewardsDailyClaimSumOrderByAggregateInput
  }

  export type AjnaRewardsDailyClaimScalarWhereWithAggregatesInput = {
    AND?: Enumerable<AjnaRewardsDailyClaimScalarWhereWithAggregatesInput>
    OR?: Enumerable<AjnaRewardsDailyClaimScalarWhereWithAggregatesInput>
    NOT?: Enumerable<AjnaRewardsDailyClaimScalarWhereWithAggregatesInput>
    id?: IntWithAggregatesFilter | number
    timestamp?: DateTimeWithAggregatesFilter | Date | string
    chain_id?: IntWithAggregatesFilter | number
    user_address?: StringWithAggregatesFilter | string
    amount?: StringWithAggregatesFilter | string
    week_number?: IntWithAggregatesFilter | number
    day_number?: IntWithAggregatesFilter | number
  }

  export type AjnaRewardsMerkleTreeWhereInput = {
    AND?: Enumerable<AjnaRewardsMerkleTreeWhereInput>
    OR?: Enumerable<AjnaRewardsMerkleTreeWhereInput>
    NOT?: Enumerable<AjnaRewardsMerkleTreeWhereInput>
    id?: IntFilter | number
    timestamp?: DateTimeFilter | Date | string
    chain_id?: IntFilter | number
    week_number?: IntFilter | number
    tree_root?: StringFilter | string
    tx_processed?: BoolFilter | boolean
  }

  export type AjnaRewardsMerkleTreeOrderByWithRelationInput = {
    id?: SortOrder
    timestamp?: SortOrder
    chain_id?: SortOrder
    week_number?: SortOrder
    tree_root?: SortOrder
    tx_processed?: SortOrder
  }

  export type AjnaRewardsMerkleTreeWhereUniqueInput = {
    id?: number
    week_number_chain_id_unique_id?: AjnaRewardsMerkleTreeWeek_number_chain_id_unique_idCompoundUniqueInput
  }

  export type AjnaRewardsMerkleTreeOrderByWithAggregationInput = {
    id?: SortOrder
    timestamp?: SortOrder
    chain_id?: SortOrder
    week_number?: SortOrder
    tree_root?: SortOrder
    tx_processed?: SortOrder
    _count?: AjnaRewardsMerkleTreeCountOrderByAggregateInput
    _avg?: AjnaRewardsMerkleTreeAvgOrderByAggregateInput
    _max?: AjnaRewardsMerkleTreeMaxOrderByAggregateInput
    _min?: AjnaRewardsMerkleTreeMinOrderByAggregateInput
    _sum?: AjnaRewardsMerkleTreeSumOrderByAggregateInput
  }

  export type AjnaRewardsMerkleTreeScalarWhereWithAggregatesInput = {
    AND?: Enumerable<AjnaRewardsMerkleTreeScalarWhereWithAggregatesInput>
    OR?: Enumerable<AjnaRewardsMerkleTreeScalarWhereWithAggregatesInput>
    NOT?: Enumerable<AjnaRewardsMerkleTreeScalarWhereWithAggregatesInput>
    id?: IntWithAggregatesFilter | number
    timestamp?: DateTimeWithAggregatesFilter | Date | string
    chain_id?: IntWithAggregatesFilter | number
    week_number?: IntWithAggregatesFilter | number
    tree_root?: StringWithAggregatesFilter | string
    tx_processed?: BoolWithAggregatesFilter | boolean
  }

  export type migrationsCreateInput = {
    id: number
    name: string
    hash: string
    executed_at?: Date | string | null
  }

  export type migrationsUncheckedCreateInput = {
    id: number
    name: string
    hash: string
    executed_at?: Date | string | null
  }

  export type migrationsUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    hash?: StringFieldUpdateOperationsInput | string
    executed_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type migrationsUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    hash?: StringFieldUpdateOperationsInput | string
    executed_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type migrationsCreateManyInput = {
    id: number
    name: string
    hash: string
    executed_at?: Date | string | null
  }

  export type migrationsUpdateManyMutationInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    hash?: StringFieldUpdateOperationsInput | string
    executed_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type migrationsUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    hash?: StringFieldUpdateOperationsInput | string
    executed_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type TosApprovalCreateInput = {
    address: string
    signature: string
    message: string
    chain_id: number
    doc_version: string
    sign_date: Date | string
  }

  export type TosApprovalUncheckedCreateInput = {
    id?: number
    address: string
    signature: string
    message: string
    chain_id: number
    doc_version: string
    sign_date: Date | string
  }

  export type TosApprovalUpdateInput = {
    address?: StringFieldUpdateOperationsInput | string
    signature?: StringFieldUpdateOperationsInput | string
    message?: StringFieldUpdateOperationsInput | string
    chain_id?: IntFieldUpdateOperationsInput | number
    doc_version?: StringFieldUpdateOperationsInput | string
    sign_date?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TosApprovalUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    address?: StringFieldUpdateOperationsInput | string
    signature?: StringFieldUpdateOperationsInput | string
    message?: StringFieldUpdateOperationsInput | string
    chain_id?: IntFieldUpdateOperationsInput | number
    doc_version?: StringFieldUpdateOperationsInput | string
    sign_date?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TosApprovalCreateManyInput = {
    id?: number
    address: string
    signature: string
    message: string
    chain_id: number
    doc_version: string
    sign_date: Date | string
  }

  export type TosApprovalUpdateManyMutationInput = {
    address?: StringFieldUpdateOperationsInput | string
    signature?: StringFieldUpdateOperationsInput | string
    message?: StringFieldUpdateOperationsInput | string
    chain_id?: IntFieldUpdateOperationsInput | number
    doc_version?: StringFieldUpdateOperationsInput | string
    sign_date?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TosApprovalUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    address?: StringFieldUpdateOperationsInput | string
    signature?: StringFieldUpdateOperationsInput | string
    message?: StringFieldUpdateOperationsInput | string
    chain_id?: IntFieldUpdateOperationsInput | number
    doc_version?: StringFieldUpdateOperationsInput | string
    sign_date?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VaultCreateInput = {
    vault_id: number
    type: VaultType
    owner_address: string
    chain_id?: number | null
    protocol: string
  }

  export type VaultUncheckedCreateInput = {
    vault_id: number
    type: VaultType
    owner_address: string
    chain_id?: number | null
    protocol: string
  }

  export type VaultUpdateInput = {
    vault_id?: IntFieldUpdateOperationsInput | number
    type?: EnumVaultTypeFieldUpdateOperationsInput | VaultType
    owner_address?: StringFieldUpdateOperationsInput | string
    chain_id?: NullableIntFieldUpdateOperationsInput | number | null
    protocol?: StringFieldUpdateOperationsInput | string
  }

  export type VaultUncheckedUpdateInput = {
    vault_id?: IntFieldUpdateOperationsInput | number
    type?: EnumVaultTypeFieldUpdateOperationsInput | VaultType
    owner_address?: StringFieldUpdateOperationsInput | string
    chain_id?: NullableIntFieldUpdateOperationsInput | number | null
    protocol?: StringFieldUpdateOperationsInput | string
  }

  export type VaultCreateManyInput = {
    vault_id: number
    type: VaultType
    owner_address: string
    chain_id?: number | null
    protocol: string
  }

  export type VaultUpdateManyMutationInput = {
    vault_id?: IntFieldUpdateOperationsInput | number
    type?: EnumVaultTypeFieldUpdateOperationsInput | VaultType
    owner_address?: StringFieldUpdateOperationsInput | string
    chain_id?: NullableIntFieldUpdateOperationsInput | number | null
    protocol?: StringFieldUpdateOperationsInput | string
  }

  export type VaultUncheckedUpdateManyInput = {
    vault_id?: IntFieldUpdateOperationsInput | number
    type?: EnumVaultTypeFieldUpdateOperationsInput | VaultType
    owner_address?: StringFieldUpdateOperationsInput | string
    chain_id?: NullableIntFieldUpdateOperationsInput | number | null
    protocol?: StringFieldUpdateOperationsInput | string
  }

  export type UserCreateInput = {
    address: string
    timestamp?: Date | string
    accepted: boolean
    user_that_referred?: UserCreateNestedOneWithoutReferred_usersInput
    referred_users?: UserCreateNestedManyWithoutUser_that_referredInput
    weekly_claims?: WeeklyClaimCreateNestedManyWithoutClaimantInput
  }

  export type UserUncheckedCreateInput = {
    address: string
    timestamp?: Date | string
    user_that_referred_address?: string | null
    accepted: boolean
    referred_users?: UserUncheckedCreateNestedManyWithoutUser_that_referredInput
    weekly_claims?: WeeklyClaimUncheckedCreateNestedManyWithoutClaimantInput
  }

  export type UserUpdateInput = {
    address?: StringFieldUpdateOperationsInput | string
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    accepted?: BoolFieldUpdateOperationsInput | boolean
    user_that_referred?: UserUpdateOneWithoutReferred_usersNestedInput
    referred_users?: UserUpdateManyWithoutUser_that_referredNestedInput
    weekly_claims?: WeeklyClaimUpdateManyWithoutClaimantNestedInput
  }

  export type UserUncheckedUpdateInput = {
    address?: StringFieldUpdateOperationsInput | string
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    user_that_referred_address?: NullableStringFieldUpdateOperationsInput | string | null
    accepted?: BoolFieldUpdateOperationsInput | boolean
    referred_users?: UserUncheckedUpdateManyWithoutUser_that_referredNestedInput
    weekly_claims?: WeeklyClaimUncheckedUpdateManyWithoutClaimantNestedInput
  }

  export type UserCreateManyInput = {
    address: string
    timestamp?: Date | string
    user_that_referred_address?: string | null
    accepted: boolean
  }

  export type UserUpdateManyMutationInput = {
    address?: StringFieldUpdateOperationsInput | string
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    accepted?: BoolFieldUpdateOperationsInput | boolean
  }

  export type UserUncheckedUpdateManyInput = {
    address?: StringFieldUpdateOperationsInput | string
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    user_that_referred_address?: NullableStringFieldUpdateOperationsInput | string | null
    accepted?: BoolFieldUpdateOperationsInput | boolean
  }

  export type WeeklyClaimCreateInput = {
    timestamp?: Date | string | null
    week_number: number
    proof?: WeeklyClaimCreateproofInput | Enumerable<string>
    amount: string
    claimant: UserCreateNestedOneWithoutWeekly_claimsInput
  }

  export type WeeklyClaimUncheckedCreateInput = {
    id?: number
    timestamp?: Date | string | null
    week_number: number
    user_address: string
    proof?: WeeklyClaimCreateproofInput | Enumerable<string>
    amount: string
  }

  export type WeeklyClaimUpdateInput = {
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    week_number?: IntFieldUpdateOperationsInput | number
    proof?: WeeklyClaimUpdateproofInput | Enumerable<string>
    amount?: StringFieldUpdateOperationsInput | string
    claimant?: UserUpdateOneRequiredWithoutWeekly_claimsNestedInput
  }

  export type WeeklyClaimUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    week_number?: IntFieldUpdateOperationsInput | number
    user_address?: StringFieldUpdateOperationsInput | string
    proof?: WeeklyClaimUpdateproofInput | Enumerable<string>
    amount?: StringFieldUpdateOperationsInput | string
  }

  export type WeeklyClaimCreateManyInput = {
    id?: number
    timestamp?: Date | string | null
    week_number: number
    user_address: string
    proof?: WeeklyClaimCreateproofInput | Enumerable<string>
    amount: string
  }

  export type WeeklyClaimUpdateManyMutationInput = {
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    week_number?: IntFieldUpdateOperationsInput | number
    proof?: WeeklyClaimUpdateproofInput | Enumerable<string>
    amount?: StringFieldUpdateOperationsInput | string
  }

  export type WeeklyClaimUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    week_number?: IntFieldUpdateOperationsInput | number
    user_address?: StringFieldUpdateOperationsInput | string
    proof?: WeeklyClaimUpdateproofInput | Enumerable<string>
    amount?: StringFieldUpdateOperationsInput | string
  }

  export type MerkleTreeCreateInput = {
    week_number: number
    start_block?: number | null
    end_block?: number | null
    timestamp?: Date | string | null
    tree_root: string
    snapshot?: string | null
  }

  export type MerkleTreeUncheckedCreateInput = {
    week_number: number
    start_block?: number | null
    end_block?: number | null
    timestamp?: Date | string | null
    tree_root: string
    snapshot?: string | null
  }

  export type MerkleTreeUpdateInput = {
    week_number?: IntFieldUpdateOperationsInput | number
    start_block?: NullableIntFieldUpdateOperationsInput | number | null
    end_block?: NullableIntFieldUpdateOperationsInput | number | null
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    tree_root?: StringFieldUpdateOperationsInput | string
    snapshot?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type MerkleTreeUncheckedUpdateInput = {
    week_number?: IntFieldUpdateOperationsInput | number
    start_block?: NullableIntFieldUpdateOperationsInput | number | null
    end_block?: NullableIntFieldUpdateOperationsInput | number | null
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    tree_root?: StringFieldUpdateOperationsInput | string
    snapshot?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type MerkleTreeCreateManyInput = {
    week_number: number
    start_block?: number | null
    end_block?: number | null
    timestamp?: Date | string | null
    tree_root: string
    snapshot?: string | null
  }

  export type MerkleTreeUpdateManyMutationInput = {
    week_number?: IntFieldUpdateOperationsInput | number
    start_block?: NullableIntFieldUpdateOperationsInput | number | null
    end_block?: NullableIntFieldUpdateOperationsInput | number | null
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    tree_root?: StringFieldUpdateOperationsInput | string
    snapshot?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type MerkleTreeUncheckedUpdateManyInput = {
    week_number?: IntFieldUpdateOperationsInput | number
    start_block?: NullableIntFieldUpdateOperationsInput | number | null
    end_block?: NullableIntFieldUpdateOperationsInput | number | null
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    tree_root?: StringFieldUpdateOperationsInput | string
    snapshot?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type WalletRiskCreateInput = {
    address: string
    last_check: Date | string
    is_risky: boolean
  }

  export type WalletRiskUncheckedCreateInput = {
    address: string
    last_check: Date | string
    is_risky: boolean
  }

  export type WalletRiskUpdateInput = {
    address?: StringFieldUpdateOperationsInput | string
    last_check?: DateTimeFieldUpdateOperationsInput | Date | string
    is_risky?: BoolFieldUpdateOperationsInput | boolean
  }

  export type WalletRiskUncheckedUpdateInput = {
    address?: StringFieldUpdateOperationsInput | string
    last_check?: DateTimeFieldUpdateOperationsInput | Date | string
    is_risky?: BoolFieldUpdateOperationsInput | boolean
  }

  export type WalletRiskCreateManyInput = {
    address: string
    last_check: Date | string
    is_risky: boolean
  }

  export type WalletRiskUpdateManyMutationInput = {
    address?: StringFieldUpdateOperationsInput | string
    last_check?: DateTimeFieldUpdateOperationsInput | Date | string
    is_risky?: BoolFieldUpdateOperationsInput | boolean
  }

  export type WalletRiskUncheckedUpdateManyInput = {
    address?: StringFieldUpdateOperationsInput | string
    last_check?: DateTimeFieldUpdateOperationsInput | Date | string
    is_risky?: BoolFieldUpdateOperationsInput | boolean
  }

  export type CollateralTypeCreateInput = {
    collateral_name: string
    token: string
    next_price: Decimal | DecimalJsLike | number | string
    current_price: Decimal | DecimalJsLike | number | string
    liquidation_ratio: Decimal | DecimalJsLike | number | string
    liquidation_penalty: Decimal | DecimalJsLike | number | string
    rate?: Decimal | DecimalJsLike | number | string | null
    market_price?: Decimal | DecimalJsLike | number | string | null
  }

  export type CollateralTypeUncheckedCreateInput = {
    collateral_name: string
    token: string
    next_price: Decimal | DecimalJsLike | number | string
    current_price: Decimal | DecimalJsLike | number | string
    liquidation_ratio: Decimal | DecimalJsLike | number | string
    liquidation_penalty: Decimal | DecimalJsLike | number | string
    rate?: Decimal | DecimalJsLike | number | string | null
    market_price?: Decimal | DecimalJsLike | number | string | null
  }

  export type CollateralTypeUpdateInput = {
    collateral_name?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    next_price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    current_price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_ratio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_penalty?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    rate?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    market_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type CollateralTypeUncheckedUpdateInput = {
    collateral_name?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    next_price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    current_price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_ratio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_penalty?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    rate?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    market_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type CollateralTypeCreateManyInput = {
    collateral_name: string
    token: string
    next_price: Decimal | DecimalJsLike | number | string
    current_price: Decimal | DecimalJsLike | number | string
    liquidation_ratio: Decimal | DecimalJsLike | number | string
    liquidation_penalty: Decimal | DecimalJsLike | number | string
    rate?: Decimal | DecimalJsLike | number | string | null
    market_price?: Decimal | DecimalJsLike | number | string | null
  }

  export type CollateralTypeUpdateManyMutationInput = {
    collateral_name?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    next_price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    current_price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_ratio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_penalty?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    rate?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    market_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type CollateralTypeUncheckedUpdateManyInput = {
    collateral_name?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    next_price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    current_price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_ratio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_penalty?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    rate?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    market_price?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
  }

  export type DiscoverCreateInput = {
    protocol_id: string
    position_id: string
    collateral_type: string
    vault_debt: Decimal | DecimalJsLike | number | string
    vault_normalized_debt?: Decimal | DecimalJsLike | number | string | null
    vault_collateral: Decimal | DecimalJsLike | number | string
    yield_30d: Decimal | DecimalJsLike | number | string
    status: JsonNullValueInput | InputJsonValue
    last_action: JsonNullValueInput | InputJsonValue
    pnl_all: Decimal | DecimalJsLike | number | string
    pnl_1d: Decimal | DecimalJsLike | number | string
    pnl_7d: Decimal | DecimalJsLike | number | string
    pnl_30d: Decimal | DecimalJsLike | number | string
    pnl_365d: Decimal | DecimalJsLike | number | string
    pnl_ytd: Decimal | DecimalJsLike | number | string
    net_profit_all: Decimal | DecimalJsLike | number | string
    net_profit_1d: Decimal | DecimalJsLike | number | string
    net_profit_7d: Decimal | DecimalJsLike | number | string
    net_profit_30d: Decimal | DecimalJsLike | number | string
    net_profit_365d: Decimal | DecimalJsLike | number | string
    net_profit_ytd: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string
    updatedAt: Date | string
  }

  export type DiscoverUncheckedCreateInput = {
    protocol_id: string
    position_id: string
    collateral_type: string
    vault_debt: Decimal | DecimalJsLike | number | string
    vault_normalized_debt?: Decimal | DecimalJsLike | number | string | null
    vault_collateral: Decimal | DecimalJsLike | number | string
    yield_30d: Decimal | DecimalJsLike | number | string
    status: JsonNullValueInput | InputJsonValue
    last_action: JsonNullValueInput | InputJsonValue
    pnl_all: Decimal | DecimalJsLike | number | string
    pnl_1d: Decimal | DecimalJsLike | number | string
    pnl_7d: Decimal | DecimalJsLike | number | string
    pnl_30d: Decimal | DecimalJsLike | number | string
    pnl_365d: Decimal | DecimalJsLike | number | string
    pnl_ytd: Decimal | DecimalJsLike | number | string
    net_profit_all: Decimal | DecimalJsLike | number | string
    net_profit_1d: Decimal | DecimalJsLike | number | string
    net_profit_7d: Decimal | DecimalJsLike | number | string
    net_profit_30d: Decimal | DecimalJsLike | number | string
    net_profit_365d: Decimal | DecimalJsLike | number | string
    net_profit_ytd: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string
    updatedAt: Date | string
  }

  export type DiscoverUpdateInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    vault_debt?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    vault_normalized_debt?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    vault_collateral?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    yield_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    status?: JsonNullValueInput | InputJsonValue
    last_action?: JsonNullValueInput | InputJsonValue
    pnl_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type DiscoverUncheckedUpdateInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    vault_debt?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    vault_normalized_debt?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    vault_collateral?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    yield_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    status?: JsonNullValueInput | InputJsonValue
    last_action?: JsonNullValueInput | InputJsonValue
    pnl_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type DiscoverCreateManyInput = {
    protocol_id: string
    position_id: string
    collateral_type: string
    vault_debt: Decimal | DecimalJsLike | number | string
    vault_normalized_debt?: Decimal | DecimalJsLike | number | string | null
    vault_collateral: Decimal | DecimalJsLike | number | string
    yield_30d: Decimal | DecimalJsLike | number | string
    status: JsonNullValueInput | InputJsonValue
    last_action: JsonNullValueInput | InputJsonValue
    pnl_all: Decimal | DecimalJsLike | number | string
    pnl_1d: Decimal | DecimalJsLike | number | string
    pnl_7d: Decimal | DecimalJsLike | number | string
    pnl_30d: Decimal | DecimalJsLike | number | string
    pnl_365d: Decimal | DecimalJsLike | number | string
    pnl_ytd: Decimal | DecimalJsLike | number | string
    net_profit_all: Decimal | DecimalJsLike | number | string
    net_profit_1d: Decimal | DecimalJsLike | number | string
    net_profit_7d: Decimal | DecimalJsLike | number | string
    net_profit_30d: Decimal | DecimalJsLike | number | string
    net_profit_365d: Decimal | DecimalJsLike | number | string
    net_profit_ytd: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string
    updatedAt: Date | string
  }

  export type DiscoverUpdateManyMutationInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    vault_debt?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    vault_normalized_debt?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    vault_collateral?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    yield_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    status?: JsonNullValueInput | InputJsonValue
    last_action?: JsonNullValueInput | InputJsonValue
    pnl_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type DiscoverUncheckedUpdateManyInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    vault_debt?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    vault_normalized_debt?: NullableDecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string | null
    vault_collateral?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    yield_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    status?: JsonNullValueInput | InputJsonValue
    last_action?: JsonNullValueInput | InputJsonValue
    pnl_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type HighestRiskPositionsCreateInput = {
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_ratio: Decimal | DecimalJsLike | number | string
    collateral_value: Decimal | DecimalJsLike | number | string
    liquidation_proximity: Decimal | DecimalJsLike | number | string
    liquidation_price: Decimal | DecimalJsLike | number | string
    liquidation_value: Decimal | DecimalJsLike | number | string
    next_price: Decimal | DecimalJsLike | number | string
    status: JsonNullValueInput | InputJsonValue
    type?: VaultType | null
  }

  export type HighestRiskPositionsUncheckedCreateInput = {
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_ratio: Decimal | DecimalJsLike | number | string
    collateral_value: Decimal | DecimalJsLike | number | string
    liquidation_proximity: Decimal | DecimalJsLike | number | string
    liquidation_price: Decimal | DecimalJsLike | number | string
    liquidation_value: Decimal | DecimalJsLike | number | string
    next_price: Decimal | DecimalJsLike | number | string
    status: JsonNullValueInput | InputJsonValue
    type?: VaultType | null
  }

  export type HighestRiskPositionsUpdateInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    collateral_ratio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    collateral_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_proximity?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    next_price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    status?: JsonNullValueInput | InputJsonValue
    type?: NullableEnumVaultTypeFieldUpdateOperationsInput | VaultType | null
  }

  export type HighestRiskPositionsUncheckedUpdateInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    collateral_ratio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    collateral_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_proximity?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    next_price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    status?: JsonNullValueInput | InputJsonValue
    type?: NullableEnumVaultTypeFieldUpdateOperationsInput | VaultType | null
  }

  export type HighestRiskPositionsCreateManyInput = {
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_ratio: Decimal | DecimalJsLike | number | string
    collateral_value: Decimal | DecimalJsLike | number | string
    liquidation_proximity: Decimal | DecimalJsLike | number | string
    liquidation_price: Decimal | DecimalJsLike | number | string
    liquidation_value: Decimal | DecimalJsLike | number | string
    next_price: Decimal | DecimalJsLike | number | string
    status: JsonNullValueInput | InputJsonValue
    type?: VaultType | null
  }

  export type HighestRiskPositionsUpdateManyMutationInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    collateral_ratio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    collateral_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_proximity?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    next_price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    status?: JsonNullValueInput | InputJsonValue
    type?: NullableEnumVaultTypeFieldUpdateOperationsInput | VaultType | null
  }

  export type HighestRiskPositionsUncheckedUpdateManyInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    collateral_ratio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    collateral_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_proximity?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    next_price?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    status?: JsonNullValueInput | InputJsonValue
    type?: NullableEnumVaultTypeFieldUpdateOperationsInput | VaultType | null
  }

  export type HighestMultiplyPnlCreateInput = {
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_value: Decimal | DecimalJsLike | number | string
    vault_multiple: Decimal | DecimalJsLike | number | string
    pnl_all: Decimal | DecimalJsLike | number | string
    pnl_1d: Decimal | DecimalJsLike | number | string
    pnl_7d: Decimal | DecimalJsLike | number | string
    pnl_30d: Decimal | DecimalJsLike | number | string
    pnl_365d: Decimal | DecimalJsLike | number | string
    pnl_ytd: Decimal | DecimalJsLike | number | string
    net_profit_all: Decimal | DecimalJsLike | number | string
    net_profit_1d: Decimal | DecimalJsLike | number | string
    net_profit_7d: Decimal | DecimalJsLike | number | string
    net_profit_30d: Decimal | DecimalJsLike | number | string
    net_profit_365d: Decimal | DecimalJsLike | number | string
    net_profit_ytd: Decimal | DecimalJsLike | number | string
    last_action: JsonNullValueInput | InputJsonValue
    type?: VaultType | null
  }

  export type HighestMultiplyPnlUncheckedCreateInput = {
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_value: Decimal | DecimalJsLike | number | string
    vault_multiple: Decimal | DecimalJsLike | number | string
    pnl_all: Decimal | DecimalJsLike | number | string
    pnl_1d: Decimal | DecimalJsLike | number | string
    pnl_7d: Decimal | DecimalJsLike | number | string
    pnl_30d: Decimal | DecimalJsLike | number | string
    pnl_365d: Decimal | DecimalJsLike | number | string
    pnl_ytd: Decimal | DecimalJsLike | number | string
    net_profit_all: Decimal | DecimalJsLike | number | string
    net_profit_1d: Decimal | DecimalJsLike | number | string
    net_profit_7d: Decimal | DecimalJsLike | number | string
    net_profit_30d: Decimal | DecimalJsLike | number | string
    net_profit_365d: Decimal | DecimalJsLike | number | string
    net_profit_ytd: Decimal | DecimalJsLike | number | string
    last_action: JsonNullValueInput | InputJsonValue
    type?: VaultType | null
  }

  export type HighestMultiplyPnlUpdateInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    collateral_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    vault_multiple?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    last_action?: JsonNullValueInput | InputJsonValue
    type?: NullableEnumVaultTypeFieldUpdateOperationsInput | VaultType | null
  }

  export type HighestMultiplyPnlUncheckedUpdateInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    collateral_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    vault_multiple?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    last_action?: JsonNullValueInput | InputJsonValue
    type?: NullableEnumVaultTypeFieldUpdateOperationsInput | VaultType | null
  }

  export type HighestMultiplyPnlCreateManyInput = {
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_value: Decimal | DecimalJsLike | number | string
    vault_multiple: Decimal | DecimalJsLike | number | string
    pnl_all: Decimal | DecimalJsLike | number | string
    pnl_1d: Decimal | DecimalJsLike | number | string
    pnl_7d: Decimal | DecimalJsLike | number | string
    pnl_30d: Decimal | DecimalJsLike | number | string
    pnl_365d: Decimal | DecimalJsLike | number | string
    pnl_ytd: Decimal | DecimalJsLike | number | string
    net_profit_all: Decimal | DecimalJsLike | number | string
    net_profit_1d: Decimal | DecimalJsLike | number | string
    net_profit_7d: Decimal | DecimalJsLike | number | string
    net_profit_30d: Decimal | DecimalJsLike | number | string
    net_profit_365d: Decimal | DecimalJsLike | number | string
    net_profit_ytd: Decimal | DecimalJsLike | number | string
    last_action: JsonNullValueInput | InputJsonValue
    type?: VaultType | null
  }

  export type HighestMultiplyPnlUpdateManyMutationInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    collateral_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    vault_multiple?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    last_action?: JsonNullValueInput | InputJsonValue
    type?: NullableEnumVaultTypeFieldUpdateOperationsInput | VaultType | null
  }

  export type HighestMultiplyPnlUncheckedUpdateManyInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    collateral_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    vault_multiple?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_profit_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    last_action?: JsonNullValueInput | InputJsonValue
    type?: NullableEnumVaultTypeFieldUpdateOperationsInput | VaultType | null
  }

  export type MostYieldEarnedCreateInput = {
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_value: Decimal | DecimalJsLike | number | string
    net_value: Decimal | DecimalJsLike | number | string
    pnl_all: Decimal | DecimalJsLike | number | string
    pnl_1d: Decimal | DecimalJsLike | number | string
    pnl_7d: Decimal | DecimalJsLike | number | string
    pnl_30d: Decimal | DecimalJsLike | number | string
    pnl_365d: Decimal | DecimalJsLike | number | string
    pnl_ytd: Decimal | DecimalJsLike | number | string
    yield_30d: Decimal | DecimalJsLike | number | string
    last_action: JsonNullValueInput | InputJsonValue
    type?: VaultType | null
  }

  export type MostYieldEarnedUncheckedCreateInput = {
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_value: Decimal | DecimalJsLike | number | string
    net_value: Decimal | DecimalJsLike | number | string
    pnl_all: Decimal | DecimalJsLike | number | string
    pnl_1d: Decimal | DecimalJsLike | number | string
    pnl_7d: Decimal | DecimalJsLike | number | string
    pnl_30d: Decimal | DecimalJsLike | number | string
    pnl_365d: Decimal | DecimalJsLike | number | string
    pnl_ytd: Decimal | DecimalJsLike | number | string
    yield_30d: Decimal | DecimalJsLike | number | string
    last_action: JsonNullValueInput | InputJsonValue
    type?: VaultType | null
  }

  export type MostYieldEarnedUpdateInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    collateral_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    yield_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    last_action?: JsonNullValueInput | InputJsonValue
    type?: NullableEnumVaultTypeFieldUpdateOperationsInput | VaultType | null
  }

  export type MostYieldEarnedUncheckedUpdateInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    collateral_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    yield_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    last_action?: JsonNullValueInput | InputJsonValue
    type?: NullableEnumVaultTypeFieldUpdateOperationsInput | VaultType | null
  }

  export type MostYieldEarnedCreateManyInput = {
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_value: Decimal | DecimalJsLike | number | string
    net_value: Decimal | DecimalJsLike | number | string
    pnl_all: Decimal | DecimalJsLike | number | string
    pnl_1d: Decimal | DecimalJsLike | number | string
    pnl_7d: Decimal | DecimalJsLike | number | string
    pnl_30d: Decimal | DecimalJsLike | number | string
    pnl_365d: Decimal | DecimalJsLike | number | string
    pnl_ytd: Decimal | DecimalJsLike | number | string
    yield_30d: Decimal | DecimalJsLike | number | string
    last_action: JsonNullValueInput | InputJsonValue
    type?: VaultType | null
  }

  export type MostYieldEarnedUpdateManyMutationInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    collateral_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    yield_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    last_action?: JsonNullValueInput | InputJsonValue
    type?: NullableEnumVaultTypeFieldUpdateOperationsInput | VaultType | null
  }

  export type MostYieldEarnedUncheckedUpdateManyInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    collateral_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    net_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_all?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_1d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_7d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_365d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    pnl_ytd?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    yield_30d?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    last_action?: JsonNullValueInput | InputJsonValue
    type?: NullableEnumVaultTypeFieldUpdateOperationsInput | VaultType | null
  }

  export type LargestDebtCreateInput = {
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_value: Decimal | DecimalJsLike | number | string
    liquidation_proximity: Decimal | DecimalJsLike | number | string
    vault_debt: Decimal | DecimalJsLike | number | string
    coll_ratio: Decimal | DecimalJsLike | number | string
    last_action: JsonNullValueInput | InputJsonValue
    type?: VaultType | null
  }

  export type LargestDebtUncheckedCreateInput = {
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_value: Decimal | DecimalJsLike | number | string
    liquidation_proximity: Decimal | DecimalJsLike | number | string
    vault_debt: Decimal | DecimalJsLike | number | string
    coll_ratio: Decimal | DecimalJsLike | number | string
    last_action: JsonNullValueInput | InputJsonValue
    type?: VaultType | null
  }

  export type LargestDebtUpdateInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    collateral_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_proximity?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    vault_debt?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    coll_ratio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    last_action?: JsonNullValueInput | InputJsonValue
    type?: NullableEnumVaultTypeFieldUpdateOperationsInput | VaultType | null
  }

  export type LargestDebtUncheckedUpdateInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    collateral_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_proximity?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    vault_debt?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    coll_ratio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    last_action?: JsonNullValueInput | InputJsonValue
    type?: NullableEnumVaultTypeFieldUpdateOperationsInput | VaultType | null
  }

  export type LargestDebtCreateManyInput = {
    protocol_id: string
    position_id: string
    collateral_type: string
    token: string
    collateral_value: Decimal | DecimalJsLike | number | string
    liquidation_proximity: Decimal | DecimalJsLike | number | string
    vault_debt: Decimal | DecimalJsLike | number | string
    coll_ratio: Decimal | DecimalJsLike | number | string
    last_action: JsonNullValueInput | InputJsonValue
    type?: VaultType | null
  }

  export type LargestDebtUpdateManyMutationInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    collateral_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_proximity?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    vault_debt?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    coll_ratio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    last_action?: JsonNullValueInput | InputJsonValue
    type?: NullableEnumVaultTypeFieldUpdateOperationsInput | VaultType | null
  }

  export type LargestDebtUncheckedUpdateManyInput = {
    protocol_id?: StringFieldUpdateOperationsInput | string
    position_id?: StringFieldUpdateOperationsInput | string
    collateral_type?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    collateral_value?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    liquidation_proximity?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    vault_debt?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    coll_ratio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    last_action?: JsonNullValueInput | InputJsonValue
    type?: NullableEnumVaultTypeFieldUpdateOperationsInput | VaultType | null
  }

  export type UsersWhoFollowVaultsCreateInput = {
    user_address: string
    vault_id: number
    vault_chain_id: number
    protocol: Protocol
  }

  export type UsersWhoFollowVaultsUncheckedCreateInput = {
    user_address: string
    vault_id: number
    vault_chain_id: number
    protocol: Protocol
  }

  export type UsersWhoFollowVaultsUpdateInput = {
    user_address?: StringFieldUpdateOperationsInput | string
    vault_id?: IntFieldUpdateOperationsInput | number
    vault_chain_id?: IntFieldUpdateOperationsInput | number
    protocol?: EnumProtocolFieldUpdateOperationsInput | Protocol
  }

  export type UsersWhoFollowVaultsUncheckedUpdateInput = {
    user_address?: StringFieldUpdateOperationsInput | string
    vault_id?: IntFieldUpdateOperationsInput | number
    vault_chain_id?: IntFieldUpdateOperationsInput | number
    protocol?: EnumProtocolFieldUpdateOperationsInput | Protocol
  }

  export type UsersWhoFollowVaultsCreateManyInput = {
    user_address: string
    vault_id: number
    vault_chain_id: number
    protocol: Protocol
  }

  export type UsersWhoFollowVaultsUpdateManyMutationInput = {
    user_address?: StringFieldUpdateOperationsInput | string
    vault_id?: IntFieldUpdateOperationsInput | number
    vault_chain_id?: IntFieldUpdateOperationsInput | number
    protocol?: EnumProtocolFieldUpdateOperationsInput | Protocol
  }

  export type UsersWhoFollowVaultsUncheckedUpdateManyInput = {
    user_address?: StringFieldUpdateOperationsInput | string
    vault_id?: IntFieldUpdateOperationsInput | number
    vault_chain_id?: IntFieldUpdateOperationsInput | number
    protocol?: EnumProtocolFieldUpdateOperationsInput | Protocol
  }

  export type ProductHubItemsCreateInput = {
    id?: string
    label: string
    network: NetworkNames
    primaryToken: string
    primaryTokenGroup?: string | null
    product?: ProductHubItemsCreateproductInput | Enumerable<Product>
    protocol: Protocol
    secondaryToken: string
    secondaryTokenGroup?: string | null
    weeklyNetApy?: string | null
    depositToken?: string | null
    earnStrategy?: string | null
    fee?: string | null
    liquidity?: string | null
    managementType?: ProductHubManagementSimple | null
    maxLtv?: string | null
    maxMultiply?: string | null
    multiplyStrategy?: string | null
    multiplyStrategyType?: ProductHubStrategy | null
    reverseTokens?: boolean | null
    updatedAt?: Date | string
  }

  export type ProductHubItemsUncheckedCreateInput = {
    id?: string
    label: string
    network: NetworkNames
    primaryToken: string
    primaryTokenGroup?: string | null
    product?: ProductHubItemsCreateproductInput | Enumerable<Product>
    protocol: Protocol
    secondaryToken: string
    secondaryTokenGroup?: string | null
    weeklyNetApy?: string | null
    depositToken?: string | null
    earnStrategy?: string | null
    fee?: string | null
    liquidity?: string | null
    managementType?: ProductHubManagementSimple | null
    maxLtv?: string | null
    maxMultiply?: string | null
    multiplyStrategy?: string | null
    multiplyStrategyType?: ProductHubStrategy | null
    reverseTokens?: boolean | null
    updatedAt?: Date | string
  }

  export type ProductHubItemsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    label?: StringFieldUpdateOperationsInput | string
    network?: EnumNetworkNamesFieldUpdateOperationsInput | NetworkNames
    primaryToken?: StringFieldUpdateOperationsInput | string
    primaryTokenGroup?: NullableStringFieldUpdateOperationsInput | string | null
    product?: ProductHubItemsUpdateproductInput | Enumerable<Product>
    protocol?: EnumProtocolFieldUpdateOperationsInput | Protocol
    secondaryToken?: StringFieldUpdateOperationsInput | string
    secondaryTokenGroup?: NullableStringFieldUpdateOperationsInput | string | null
    weeklyNetApy?: NullableStringFieldUpdateOperationsInput | string | null
    depositToken?: NullableStringFieldUpdateOperationsInput | string | null
    earnStrategy?: NullableStringFieldUpdateOperationsInput | string | null
    fee?: NullableStringFieldUpdateOperationsInput | string | null
    liquidity?: NullableStringFieldUpdateOperationsInput | string | null
    managementType?: NullableEnumProductHubManagementSimpleFieldUpdateOperationsInput | ProductHubManagementSimple | null
    maxLtv?: NullableStringFieldUpdateOperationsInput | string | null
    maxMultiply?: NullableStringFieldUpdateOperationsInput | string | null
    multiplyStrategy?: NullableStringFieldUpdateOperationsInput | string | null
    multiplyStrategyType?: NullableEnumProductHubStrategyFieldUpdateOperationsInput | ProductHubStrategy | null
    reverseTokens?: NullableBoolFieldUpdateOperationsInput | boolean | null
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ProductHubItemsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    label?: StringFieldUpdateOperationsInput | string
    network?: EnumNetworkNamesFieldUpdateOperationsInput | NetworkNames
    primaryToken?: StringFieldUpdateOperationsInput | string
    primaryTokenGroup?: NullableStringFieldUpdateOperationsInput | string | null
    product?: ProductHubItemsUpdateproductInput | Enumerable<Product>
    protocol?: EnumProtocolFieldUpdateOperationsInput | Protocol
    secondaryToken?: StringFieldUpdateOperationsInput | string
    secondaryTokenGroup?: NullableStringFieldUpdateOperationsInput | string | null
    weeklyNetApy?: NullableStringFieldUpdateOperationsInput | string | null
    depositToken?: NullableStringFieldUpdateOperationsInput | string | null
    earnStrategy?: NullableStringFieldUpdateOperationsInput | string | null
    fee?: NullableStringFieldUpdateOperationsInput | string | null
    liquidity?: NullableStringFieldUpdateOperationsInput | string | null
    managementType?: NullableEnumProductHubManagementSimpleFieldUpdateOperationsInput | ProductHubManagementSimple | null
    maxLtv?: NullableStringFieldUpdateOperationsInput | string | null
    maxMultiply?: NullableStringFieldUpdateOperationsInput | string | null
    multiplyStrategy?: NullableStringFieldUpdateOperationsInput | string | null
    multiplyStrategyType?: NullableEnumProductHubStrategyFieldUpdateOperationsInput | ProductHubStrategy | null
    reverseTokens?: NullableBoolFieldUpdateOperationsInput | boolean | null
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ProductHubItemsCreateManyInput = {
    id?: string
    label: string
    network: NetworkNames
    primaryToken: string
    primaryTokenGroup?: string | null
    product?: ProductHubItemsCreateproductInput | Enumerable<Product>
    protocol: Protocol
    secondaryToken: string
    secondaryTokenGroup?: string | null
    weeklyNetApy?: string | null
    depositToken?: string | null
    earnStrategy?: string | null
    fee?: string | null
    liquidity?: string | null
    managementType?: ProductHubManagementSimple | null
    maxLtv?: string | null
    maxMultiply?: string | null
    multiplyStrategy?: string | null
    multiplyStrategyType?: ProductHubStrategy | null
    reverseTokens?: boolean | null
    updatedAt?: Date | string
  }

  export type ProductHubItemsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    label?: StringFieldUpdateOperationsInput | string
    network?: EnumNetworkNamesFieldUpdateOperationsInput | NetworkNames
    primaryToken?: StringFieldUpdateOperationsInput | string
    primaryTokenGroup?: NullableStringFieldUpdateOperationsInput | string | null
    product?: ProductHubItemsUpdateproductInput | Enumerable<Product>
    protocol?: EnumProtocolFieldUpdateOperationsInput | Protocol
    secondaryToken?: StringFieldUpdateOperationsInput | string
    secondaryTokenGroup?: NullableStringFieldUpdateOperationsInput | string | null
    weeklyNetApy?: NullableStringFieldUpdateOperationsInput | string | null
    depositToken?: NullableStringFieldUpdateOperationsInput | string | null
    earnStrategy?: NullableStringFieldUpdateOperationsInput | string | null
    fee?: NullableStringFieldUpdateOperationsInput | string | null
    liquidity?: NullableStringFieldUpdateOperationsInput | string | null
    managementType?: NullableEnumProductHubManagementSimpleFieldUpdateOperationsInput | ProductHubManagementSimple | null
    maxLtv?: NullableStringFieldUpdateOperationsInput | string | null
    maxMultiply?: NullableStringFieldUpdateOperationsInput | string | null
    multiplyStrategy?: NullableStringFieldUpdateOperationsInput | string | null
    multiplyStrategyType?: NullableEnumProductHubStrategyFieldUpdateOperationsInput | ProductHubStrategy | null
    reverseTokens?: NullableBoolFieldUpdateOperationsInput | boolean | null
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ProductHubItemsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    label?: StringFieldUpdateOperationsInput | string
    network?: EnumNetworkNamesFieldUpdateOperationsInput | NetworkNames
    primaryToken?: StringFieldUpdateOperationsInput | string
    primaryTokenGroup?: NullableStringFieldUpdateOperationsInput | string | null
    product?: ProductHubItemsUpdateproductInput | Enumerable<Product>
    protocol?: EnumProtocolFieldUpdateOperationsInput | Protocol
    secondaryToken?: StringFieldUpdateOperationsInput | string
    secondaryTokenGroup?: NullableStringFieldUpdateOperationsInput | string | null
    weeklyNetApy?: NullableStringFieldUpdateOperationsInput | string | null
    depositToken?: NullableStringFieldUpdateOperationsInput | string | null
    earnStrategy?: NullableStringFieldUpdateOperationsInput | string | null
    fee?: NullableStringFieldUpdateOperationsInput | string | null
    liquidity?: NullableStringFieldUpdateOperationsInput | string | null
    managementType?: NullableEnumProductHubManagementSimpleFieldUpdateOperationsInput | ProductHubManagementSimple | null
    maxLtv?: NullableStringFieldUpdateOperationsInput | string | null
    maxMultiply?: NullableStringFieldUpdateOperationsInput | string | null
    multiplyStrategy?: NullableStringFieldUpdateOperationsInput | string | null
    multiplyStrategyType?: NullableEnumProductHubStrategyFieldUpdateOperationsInput | ProductHubStrategy | null
    reverseTokens?: NullableBoolFieldUpdateOperationsInput | boolean | null
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AjnaRewardsWeeklyClaimCreateInput = {
    timestamp?: Date | string
    chain_id: number
    user_address: string
    amount: string
    week_number: number
    proof?: AjnaRewardsWeeklyClaimCreateproofInput | Enumerable<string>
  }

  export type AjnaRewardsWeeklyClaimUncheckedCreateInput = {
    id?: number
    timestamp?: Date | string
    chain_id: number
    user_address: string
    amount: string
    week_number: number
    proof?: AjnaRewardsWeeklyClaimCreateproofInput | Enumerable<string>
  }

  export type AjnaRewardsWeeklyClaimUpdateInput = {
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    chain_id?: IntFieldUpdateOperationsInput | number
    user_address?: StringFieldUpdateOperationsInput | string
    amount?: StringFieldUpdateOperationsInput | string
    week_number?: IntFieldUpdateOperationsInput | number
    proof?: AjnaRewardsWeeklyClaimUpdateproofInput | Enumerable<string>
  }

  export type AjnaRewardsWeeklyClaimUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    chain_id?: IntFieldUpdateOperationsInput | number
    user_address?: StringFieldUpdateOperationsInput | string
    amount?: StringFieldUpdateOperationsInput | string
    week_number?: IntFieldUpdateOperationsInput | number
    proof?: AjnaRewardsWeeklyClaimUpdateproofInput | Enumerable<string>
  }

  export type AjnaRewardsWeeklyClaimCreateManyInput = {
    id?: number
    timestamp?: Date | string
    chain_id: number
    user_address: string
    amount: string
    week_number: number
    proof?: AjnaRewardsWeeklyClaimCreateproofInput | Enumerable<string>
  }

  export type AjnaRewardsWeeklyClaimUpdateManyMutationInput = {
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    chain_id?: IntFieldUpdateOperationsInput | number
    user_address?: StringFieldUpdateOperationsInput | string
    amount?: StringFieldUpdateOperationsInput | string
    week_number?: IntFieldUpdateOperationsInput | number
    proof?: AjnaRewardsWeeklyClaimUpdateproofInput | Enumerable<string>
  }

  export type AjnaRewardsWeeklyClaimUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    chain_id?: IntFieldUpdateOperationsInput | number
    user_address?: StringFieldUpdateOperationsInput | string
    amount?: StringFieldUpdateOperationsInput | string
    week_number?: IntFieldUpdateOperationsInput | number
    proof?: AjnaRewardsWeeklyClaimUpdateproofInput | Enumerable<string>
  }

  export type AjnaRewardsDailyClaimCreateInput = {
    timestamp?: Date | string
    chain_id: number
    user_address: string
    amount: string
    week_number: number
    day_number: number
  }

  export type AjnaRewardsDailyClaimUncheckedCreateInput = {
    id?: number
    timestamp?: Date | string
    chain_id: number
    user_address: string
    amount: string
    week_number: number
    day_number: number
  }

  export type AjnaRewardsDailyClaimUpdateInput = {
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    chain_id?: IntFieldUpdateOperationsInput | number
    user_address?: StringFieldUpdateOperationsInput | string
    amount?: StringFieldUpdateOperationsInput | string
    week_number?: IntFieldUpdateOperationsInput | number
    day_number?: IntFieldUpdateOperationsInput | number
  }

  export type AjnaRewardsDailyClaimUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    chain_id?: IntFieldUpdateOperationsInput | number
    user_address?: StringFieldUpdateOperationsInput | string
    amount?: StringFieldUpdateOperationsInput | string
    week_number?: IntFieldUpdateOperationsInput | number
    day_number?: IntFieldUpdateOperationsInput | number
  }

  export type AjnaRewardsDailyClaimCreateManyInput = {
    id?: number
    timestamp?: Date | string
    chain_id: number
    user_address: string
    amount: string
    week_number: number
    day_number: number
  }

  export type AjnaRewardsDailyClaimUpdateManyMutationInput = {
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    chain_id?: IntFieldUpdateOperationsInput | number
    user_address?: StringFieldUpdateOperationsInput | string
    amount?: StringFieldUpdateOperationsInput | string
    week_number?: IntFieldUpdateOperationsInput | number
    day_number?: IntFieldUpdateOperationsInput | number
  }

  export type AjnaRewardsDailyClaimUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    chain_id?: IntFieldUpdateOperationsInput | number
    user_address?: StringFieldUpdateOperationsInput | string
    amount?: StringFieldUpdateOperationsInput | string
    week_number?: IntFieldUpdateOperationsInput | number
    day_number?: IntFieldUpdateOperationsInput | number
  }

  export type AjnaRewardsMerkleTreeCreateInput = {
    timestamp?: Date | string
    chain_id: number
    week_number: number
    tree_root: string
    tx_processed?: boolean
  }

  export type AjnaRewardsMerkleTreeUncheckedCreateInput = {
    id?: number
    timestamp?: Date | string
    chain_id: number
    week_number: number
    tree_root: string
    tx_processed?: boolean
  }

  export type AjnaRewardsMerkleTreeUpdateInput = {
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    chain_id?: IntFieldUpdateOperationsInput | number
    week_number?: IntFieldUpdateOperationsInput | number
    tree_root?: StringFieldUpdateOperationsInput | string
    tx_processed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type AjnaRewardsMerkleTreeUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    chain_id?: IntFieldUpdateOperationsInput | number
    week_number?: IntFieldUpdateOperationsInput | number
    tree_root?: StringFieldUpdateOperationsInput | string
    tx_processed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type AjnaRewardsMerkleTreeCreateManyInput = {
    id?: number
    timestamp?: Date | string
    chain_id: number
    week_number: number
    tree_root: string
    tx_processed?: boolean
  }

  export type AjnaRewardsMerkleTreeUpdateManyMutationInput = {
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    chain_id?: IntFieldUpdateOperationsInput | number
    week_number?: IntFieldUpdateOperationsInput | number
    tree_root?: StringFieldUpdateOperationsInput | string
    tx_processed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type AjnaRewardsMerkleTreeUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    chain_id?: IntFieldUpdateOperationsInput | number
    week_number?: IntFieldUpdateOperationsInput | number
    tree_root?: StringFieldUpdateOperationsInput | string
    tx_processed?: BoolFieldUpdateOperationsInput | boolean
  }

  export type IntFilter = {
    equals?: number
    in?: Enumerable<number> | number
    notIn?: Enumerable<number> | number
    lt?: number
    lte?: number
    gt?: number
    gte?: number
    not?: NestedIntFilter | number
  }

  export type StringFilter = {
    equals?: string
    in?: Enumerable<string> | string
    notIn?: Enumerable<string> | string
    lt?: string
    lte?: string
    gt?: string
    gte?: string
    contains?: string
    startsWith?: string
    endsWith?: string
    mode?: QueryMode
    not?: NestedStringFilter | string
  }

  export type DateTimeNullableFilter = {
    equals?: Date | string | null
    in?: Enumerable<Date> | Enumerable<string> | Date | string | null
    notIn?: Enumerable<Date> | Enumerable<string> | Date | string | null
    lt?: Date | string
    lte?: Date | string
    gt?: Date | string
    gte?: Date | string
    not?: NestedDateTimeNullableFilter | Date | string | null
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type migrationsCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    hash?: SortOrder
    executed_at?: SortOrder
  }

  export type migrationsAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type migrationsMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    hash?: SortOrder
    executed_at?: SortOrder
  }

  export type migrationsMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    hash?: SortOrder
    executed_at?: SortOrder
  }

  export type migrationsSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type IntWithAggregatesFilter = {
    equals?: number
    in?: Enumerable<number> | number
    notIn?: Enumerable<number> | number
    lt?: number
    lte?: number
    gt?: number
    gte?: number
    not?: NestedIntWithAggregatesFilter | number
    _count?: NestedIntFilter
    _avg?: NestedFloatFilter
    _sum?: NestedIntFilter
    _min?: NestedIntFilter
    _max?: NestedIntFilter
  }

  export type StringWithAggregatesFilter = {
    equals?: string
    in?: Enumerable<string> | string
    notIn?: Enumerable<string> | string
    lt?: string
    lte?: string
    gt?: string
    gte?: string
    contains?: string
    startsWith?: string
    endsWith?: string
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter | string
    _count?: NestedIntFilter
    _min?: NestedStringFilter
    _max?: NestedStringFilter
  }

  export type DateTimeNullableWithAggregatesFilter = {
    equals?: Date | string | null
    in?: Enumerable<Date> | Enumerable<string> | Date | string | null
    notIn?: Enumerable<Date> | Enumerable<string> | Date | string | null
    lt?: Date | string
    lte?: Date | string
    gt?: Date | string
    gte?: Date | string
    not?: NestedDateTimeNullableWithAggregatesFilter | Date | string | null
    _count?: NestedIntNullableFilter
    _min?: NestedDateTimeNullableFilter
    _max?: NestedDateTimeNullableFilter
  }

  export type DateTimeFilter = {
    equals?: Date | string
    in?: Enumerable<Date> | Enumerable<string> | Date | string
    notIn?: Enumerable<Date> | Enumerable<string> | Date | string
    lt?: Date | string
    lte?: Date | string
    gt?: Date | string
    gte?: Date | string
    not?: NestedDateTimeFilter | Date | string
  }

  export type TosApprovalTos_approval_unique_signatureCompoundUniqueInput = {
    address: string
    doc_version: string
  }

  export type TosApprovalAddressChain_idDoc_versionCompoundUniqueInput = {
    address: string
    chain_id: number
    doc_version: string
  }

  export type TosApprovalCountOrderByAggregateInput = {
    id?: SortOrder
    address?: SortOrder
    signature?: SortOrder
    message?: SortOrder
    chain_id?: SortOrder
    doc_version?: SortOrder
    sign_date?: SortOrder
  }

  export type TosApprovalAvgOrderByAggregateInput = {
    id?: SortOrder
    chain_id?: SortOrder
  }

  export type TosApprovalMaxOrderByAggregateInput = {
    id?: SortOrder
    address?: SortOrder
    signature?: SortOrder
    message?: SortOrder
    chain_id?: SortOrder
    doc_version?: SortOrder
    sign_date?: SortOrder
  }

  export type TosApprovalMinOrderByAggregateInput = {
    id?: SortOrder
    address?: SortOrder
    signature?: SortOrder
    message?: SortOrder
    chain_id?: SortOrder
    doc_version?: SortOrder
    sign_date?: SortOrder
  }

  export type TosApprovalSumOrderByAggregateInput = {
    id?: SortOrder
    chain_id?: SortOrder
  }

  export type DateTimeWithAggregatesFilter = {
    equals?: Date | string
    in?: Enumerable<Date> | Enumerable<string> | Date | string
    notIn?: Enumerable<Date> | Enumerable<string> | Date | string
    lt?: Date | string
    lte?: Date | string
    gt?: Date | string
    gte?: Date | string
    not?: NestedDateTimeWithAggregatesFilter | Date | string
    _count?: NestedIntFilter
    _min?: NestedDateTimeFilter
    _max?: NestedDateTimeFilter
  }

  export type EnumVaultTypeFilter = {
    equals?: VaultType
    in?: Enumerable<VaultType>
    notIn?: Enumerable<VaultType>
    not?: NestedEnumVaultTypeFilter | VaultType
  }

  export type IntNullableFilter = {
    equals?: number | null
    in?: Enumerable<number> | number | null
    notIn?: Enumerable<number> | number | null
    lt?: number
    lte?: number
    gt?: number
    gte?: number
    not?: NestedIntNullableFilter | number | null
  }

  export type VaultVault_vault_id_chain_id_unique_constraintCompoundUniqueInput = {
    vault_id: number
    chain_id: number
    protocol: string
  }

  export type VaultCountOrderByAggregateInput = {
    vault_id?: SortOrder
    type?: SortOrder
    owner_address?: SortOrder
    chain_id?: SortOrder
    protocol?: SortOrder
  }

  export type VaultAvgOrderByAggregateInput = {
    vault_id?: SortOrder
    chain_id?: SortOrder
  }

  export type VaultMaxOrderByAggregateInput = {
    vault_id?: SortOrder
    type?: SortOrder
    owner_address?: SortOrder
    chain_id?: SortOrder
    protocol?: SortOrder
  }

  export type VaultMinOrderByAggregateInput = {
    vault_id?: SortOrder
    type?: SortOrder
    owner_address?: SortOrder
    chain_id?: SortOrder
    protocol?: SortOrder
  }

  export type VaultSumOrderByAggregateInput = {
    vault_id?: SortOrder
    chain_id?: SortOrder
  }

  export type EnumVaultTypeWithAggregatesFilter = {
    equals?: VaultType
    in?: Enumerable<VaultType>
    notIn?: Enumerable<VaultType>
    not?: NestedEnumVaultTypeWithAggregatesFilter | VaultType
    _count?: NestedIntFilter
    _min?: NestedEnumVaultTypeFilter
    _max?: NestedEnumVaultTypeFilter
  }

  export type IntNullableWithAggregatesFilter = {
    equals?: number | null
    in?: Enumerable<number> | number | null
    notIn?: Enumerable<number> | number | null
    lt?: number
    lte?: number
    gt?: number
    gte?: number
    not?: NestedIntNullableWithAggregatesFilter | number | null
    _count?: NestedIntNullableFilter
    _avg?: NestedFloatNullableFilter
    _sum?: NestedIntNullableFilter
    _min?: NestedIntNullableFilter
    _max?: NestedIntNullableFilter
  }

  export type StringNullableFilter = {
    equals?: string | null
    in?: Enumerable<string> | string | null
    notIn?: Enumerable<string> | string | null
    lt?: string
    lte?: string
    gt?: string
    gte?: string
    contains?: string
    startsWith?: string
    endsWith?: string
    mode?: QueryMode
    not?: NestedStringNullableFilter | string | null
  }

  export type BoolFilter = {
    equals?: boolean
    not?: NestedBoolFilter | boolean
  }

  export type UserRelationFilter = {
    is?: UserWhereInput | null
    isNot?: UserWhereInput | null
  }

  export type UserListRelationFilter = {
    every?: UserWhereInput
    some?: UserWhereInput
    none?: UserWhereInput
  }

  export type WeeklyClaimListRelationFilter = {
    every?: WeeklyClaimWhereInput
    some?: WeeklyClaimWhereInput
    none?: WeeklyClaimWhereInput
  }

  export type UserOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type WeeklyClaimOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserCountOrderByAggregateInput = {
    address?: SortOrder
    timestamp?: SortOrder
    user_that_referred_address?: SortOrder
    accepted?: SortOrder
  }

  export type UserMaxOrderByAggregateInput = {
    address?: SortOrder
    timestamp?: SortOrder
    user_that_referred_address?: SortOrder
    accepted?: SortOrder
  }

  export type UserMinOrderByAggregateInput = {
    address?: SortOrder
    timestamp?: SortOrder
    user_that_referred_address?: SortOrder
    accepted?: SortOrder
  }

  export type StringNullableWithAggregatesFilter = {
    equals?: string | null
    in?: Enumerable<string> | string | null
    notIn?: Enumerable<string> | string | null
    lt?: string
    lte?: string
    gt?: string
    gte?: string
    contains?: string
    startsWith?: string
    endsWith?: string
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter | string | null
    _count?: NestedIntNullableFilter
    _min?: NestedStringNullableFilter
    _max?: NestedStringNullableFilter
  }

  export type BoolWithAggregatesFilter = {
    equals?: boolean
    not?: NestedBoolWithAggregatesFilter | boolean
    _count?: NestedIntFilter
    _min?: NestedBoolFilter
    _max?: NestedBoolFilter
  }

  export type StringNullableListFilter = {
    equals?: Enumerable<string> | null
    has?: string | null
    hasEvery?: Enumerable<string>
    hasSome?: Enumerable<string>
    isEmpty?: boolean
  }

  export type WeeklyClaimWeek_number_userAddress_unique_idCompoundUniqueInput = {
    week_number: number
    user_address: string
  }

  export type WeeklyClaimCountOrderByAggregateInput = {
    id?: SortOrder
    timestamp?: SortOrder
    week_number?: SortOrder
    user_address?: SortOrder
    proof?: SortOrder
    amount?: SortOrder
  }

  export type WeeklyClaimAvgOrderByAggregateInput = {
    id?: SortOrder
    week_number?: SortOrder
  }

  export type WeeklyClaimMaxOrderByAggregateInput = {
    id?: SortOrder
    timestamp?: SortOrder
    week_number?: SortOrder
    user_address?: SortOrder
    amount?: SortOrder
  }

  export type WeeklyClaimMinOrderByAggregateInput = {
    id?: SortOrder
    timestamp?: SortOrder
    week_number?: SortOrder
    user_address?: SortOrder
    amount?: SortOrder
  }

  export type WeeklyClaimSumOrderByAggregateInput = {
    id?: SortOrder
    week_number?: SortOrder
  }

  export type MerkleTreeCountOrderByAggregateInput = {
    week_number?: SortOrder
    start_block?: SortOrder
    end_block?: SortOrder
    timestamp?: SortOrder
    tree_root?: SortOrder
    snapshot?: SortOrder
  }

  export type MerkleTreeAvgOrderByAggregateInput = {
    week_number?: SortOrder
    start_block?: SortOrder
    end_block?: SortOrder
  }

  export type MerkleTreeMaxOrderByAggregateInput = {
    week_number?: SortOrder
    start_block?: SortOrder
    end_block?: SortOrder
    timestamp?: SortOrder
    tree_root?: SortOrder
    snapshot?: SortOrder
  }

  export type MerkleTreeMinOrderByAggregateInput = {
    week_number?: SortOrder
    start_block?: SortOrder
    end_block?: SortOrder
    timestamp?: SortOrder
    tree_root?: SortOrder
    snapshot?: SortOrder
  }

  export type MerkleTreeSumOrderByAggregateInput = {
    week_number?: SortOrder
    start_block?: SortOrder
    end_block?: SortOrder
  }

  export type WalletRiskCountOrderByAggregateInput = {
    address?: SortOrder
    last_check?: SortOrder
    is_risky?: SortOrder
  }

  export type WalletRiskMaxOrderByAggregateInput = {
    address?: SortOrder
    last_check?: SortOrder
    is_risky?: SortOrder
  }

  export type WalletRiskMinOrderByAggregateInput = {
    address?: SortOrder
    last_check?: SortOrder
    is_risky?: SortOrder
  }

  export type DecimalFilter = {
    equals?: Decimal | DecimalJsLike | number | string
    in?: Enumerable<Decimal> | Enumerable<DecimalJsLike> | Enumerable<number> | Enumerable<string> | Decimal | DecimalJsLike | number | string
    notIn?: Enumerable<Decimal> | Enumerable<DecimalJsLike> | Enumerable<number> | Enumerable<string> | Decimal | DecimalJsLike | number | string
    lt?: Decimal | DecimalJsLike | number | string
    lte?: Decimal | DecimalJsLike | number | string
    gt?: Decimal | DecimalJsLike | number | string
    gte?: Decimal | DecimalJsLike | number | string
    not?: NestedDecimalFilter | Decimal | DecimalJsLike | number | string
  }

  export type DecimalNullableFilter = {
    equals?: Decimal | DecimalJsLike | number | string | null
    in?: Enumerable<Decimal> | Enumerable<DecimalJsLike> | Enumerable<number> | Enumerable<string> | Decimal | DecimalJsLike | number | string | null
    notIn?: Enumerable<Decimal> | Enumerable<DecimalJsLike> | Enumerable<number> | Enumerable<string> | Decimal | DecimalJsLike | number | string | null
    lt?: Decimal | DecimalJsLike | number | string
    lte?: Decimal | DecimalJsLike | number | string
    gt?: Decimal | DecimalJsLike | number | string
    gte?: Decimal | DecimalJsLike | number | string
    not?: NestedDecimalNullableFilter | Decimal | DecimalJsLike | number | string | null
  }

  export type CollateralTypeCountOrderByAggregateInput = {
    collateral_name?: SortOrder
    token?: SortOrder
    next_price?: SortOrder
    current_price?: SortOrder
    liquidation_ratio?: SortOrder
    liquidation_penalty?: SortOrder
    rate?: SortOrder
    market_price?: SortOrder
  }

  export type CollateralTypeAvgOrderByAggregateInput = {
    next_price?: SortOrder
    current_price?: SortOrder
    liquidation_ratio?: SortOrder
    liquidation_penalty?: SortOrder
    rate?: SortOrder
    market_price?: SortOrder
  }

  export type CollateralTypeMaxOrderByAggregateInput = {
    collateral_name?: SortOrder
    token?: SortOrder
    next_price?: SortOrder
    current_price?: SortOrder
    liquidation_ratio?: SortOrder
    liquidation_penalty?: SortOrder
    rate?: SortOrder
    market_price?: SortOrder
  }

  export type CollateralTypeMinOrderByAggregateInput = {
    collateral_name?: SortOrder
    token?: SortOrder
    next_price?: SortOrder
    current_price?: SortOrder
    liquidation_ratio?: SortOrder
    liquidation_penalty?: SortOrder
    rate?: SortOrder
    market_price?: SortOrder
  }

  export type CollateralTypeSumOrderByAggregateInput = {
    next_price?: SortOrder
    current_price?: SortOrder
    liquidation_ratio?: SortOrder
    liquidation_penalty?: SortOrder
    rate?: SortOrder
    market_price?: SortOrder
  }

  export type DecimalWithAggregatesFilter = {
    equals?: Decimal | DecimalJsLike | number | string
    in?: Enumerable<Decimal> | Enumerable<DecimalJsLike> | Enumerable<number> | Enumerable<string> | Decimal | DecimalJsLike | number | string
    notIn?: Enumerable<Decimal> | Enumerable<DecimalJsLike> | Enumerable<number> | Enumerable<string> | Decimal | DecimalJsLike | number | string
    lt?: Decimal | DecimalJsLike | number | string
    lte?: Decimal | DecimalJsLike | number | string
    gt?: Decimal | DecimalJsLike | number | string
    gte?: Decimal | DecimalJsLike | number | string
    not?: NestedDecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    _count?: NestedIntFilter
    _avg?: NestedDecimalFilter
    _sum?: NestedDecimalFilter
    _min?: NestedDecimalFilter
    _max?: NestedDecimalFilter
  }

  export type DecimalNullableWithAggregatesFilter = {
    equals?: Decimal | DecimalJsLike | number | string | null
    in?: Enumerable<Decimal> | Enumerable<DecimalJsLike> | Enumerable<number> | Enumerable<string> | Decimal | DecimalJsLike | number | string | null
    notIn?: Enumerable<Decimal> | Enumerable<DecimalJsLike> | Enumerable<number> | Enumerable<string> | Decimal | DecimalJsLike | number | string | null
    lt?: Decimal | DecimalJsLike | number | string
    lte?: Decimal | DecimalJsLike | number | string
    gt?: Decimal | DecimalJsLike | number | string
    gte?: Decimal | DecimalJsLike | number | string
    not?: NestedDecimalNullableWithAggregatesFilter | Decimal | DecimalJsLike | number | string | null
    _count?: NestedIntNullableFilter
    _avg?: NestedDecimalNullableFilter
    _sum?: NestedDecimalNullableFilter
    _min?: NestedDecimalNullableFilter
    _max?: NestedDecimalNullableFilter
  }
  export type JsonFilter = 
    | PatchUndefined<
        Either<Required<JsonFilterBase>, Exclude<keyof Required<JsonFilterBase>, 'path'>>,
        Required<JsonFilterBase>
      >
    | OptionalFlat<Omit<Required<JsonFilterBase>, 'path'>>

  export type JsonFilterBase = {
    equals?: InputJsonValue | JsonNullValueFilter
    path?: string[]
    string_contains?: string
    string_starts_with?: string
    string_ends_with?: string
    array_contains?: InputJsonValue | null
    array_starts_with?: InputJsonValue | null
    array_ends_with?: InputJsonValue | null
    lt?: InputJsonValue
    lte?: InputJsonValue
    gt?: InputJsonValue
    gte?: InputJsonValue
    not?: InputJsonValue | JsonNullValueFilter
  }

  export type DiscoverProtocol_idPosition_idCompoundUniqueInput = {
    protocol_id: string
    position_id: string
  }

  export type DiscoverCountOrderByAggregateInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    vault_debt?: SortOrder
    vault_normalized_debt?: SortOrder
    vault_collateral?: SortOrder
    yield_30d?: SortOrder
    status?: SortOrder
    last_action?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    net_profit_all?: SortOrder
    net_profit_1d?: SortOrder
    net_profit_7d?: SortOrder
    net_profit_30d?: SortOrder
    net_profit_365d?: SortOrder
    net_profit_ytd?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type DiscoverAvgOrderByAggregateInput = {
    vault_debt?: SortOrder
    vault_normalized_debt?: SortOrder
    vault_collateral?: SortOrder
    yield_30d?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    net_profit_all?: SortOrder
    net_profit_1d?: SortOrder
    net_profit_7d?: SortOrder
    net_profit_30d?: SortOrder
    net_profit_365d?: SortOrder
    net_profit_ytd?: SortOrder
  }

  export type DiscoverMaxOrderByAggregateInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    vault_debt?: SortOrder
    vault_normalized_debt?: SortOrder
    vault_collateral?: SortOrder
    yield_30d?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    net_profit_all?: SortOrder
    net_profit_1d?: SortOrder
    net_profit_7d?: SortOrder
    net_profit_30d?: SortOrder
    net_profit_365d?: SortOrder
    net_profit_ytd?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type DiscoverMinOrderByAggregateInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    vault_debt?: SortOrder
    vault_normalized_debt?: SortOrder
    vault_collateral?: SortOrder
    yield_30d?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    net_profit_all?: SortOrder
    net_profit_1d?: SortOrder
    net_profit_7d?: SortOrder
    net_profit_30d?: SortOrder
    net_profit_365d?: SortOrder
    net_profit_ytd?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type DiscoverSumOrderByAggregateInput = {
    vault_debt?: SortOrder
    vault_normalized_debt?: SortOrder
    vault_collateral?: SortOrder
    yield_30d?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    net_profit_all?: SortOrder
    net_profit_1d?: SortOrder
    net_profit_7d?: SortOrder
    net_profit_30d?: SortOrder
    net_profit_365d?: SortOrder
    net_profit_ytd?: SortOrder
  }
  export type JsonWithAggregatesFilter = 
    | PatchUndefined<
        Either<Required<JsonWithAggregatesFilterBase>, Exclude<keyof Required<JsonWithAggregatesFilterBase>, 'path'>>,
        Required<JsonWithAggregatesFilterBase>
      >
    | OptionalFlat<Omit<Required<JsonWithAggregatesFilterBase>, 'path'>>

  export type JsonWithAggregatesFilterBase = {
    equals?: InputJsonValue | JsonNullValueFilter
    path?: string[]
    string_contains?: string
    string_starts_with?: string
    string_ends_with?: string
    array_contains?: InputJsonValue | null
    array_starts_with?: InputJsonValue | null
    array_ends_with?: InputJsonValue | null
    lt?: InputJsonValue
    lte?: InputJsonValue
    gt?: InputJsonValue
    gte?: InputJsonValue
    not?: InputJsonValue | JsonNullValueFilter
    _count?: NestedIntFilter
    _min?: NestedJsonFilter
    _max?: NestedJsonFilter
  }

  export type EnumVaultTypeNullableFilter = {
    equals?: VaultType | null
    in?: Enumerable<VaultType> | null
    notIn?: Enumerable<VaultType> | null
    not?: NestedEnumVaultTypeNullableFilter | VaultType | null
  }

  export type HighestRiskPositionsProtocol_id_position_idCompoundUniqueInput = {
    protocol_id: string
    position_id: string
  }

  export type HighestRiskPositionsCountOrderByAggregateInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_ratio?: SortOrder
    collateral_value?: SortOrder
    liquidation_proximity?: SortOrder
    liquidation_price?: SortOrder
    liquidation_value?: SortOrder
    next_price?: SortOrder
    status?: SortOrder
    type?: SortOrder
  }

  export type HighestRiskPositionsAvgOrderByAggregateInput = {
    collateral_ratio?: SortOrder
    collateral_value?: SortOrder
    liquidation_proximity?: SortOrder
    liquidation_price?: SortOrder
    liquidation_value?: SortOrder
    next_price?: SortOrder
  }

  export type HighestRiskPositionsMaxOrderByAggregateInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_ratio?: SortOrder
    collateral_value?: SortOrder
    liquidation_proximity?: SortOrder
    liquidation_price?: SortOrder
    liquidation_value?: SortOrder
    next_price?: SortOrder
    type?: SortOrder
  }

  export type HighestRiskPositionsMinOrderByAggregateInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_ratio?: SortOrder
    collateral_value?: SortOrder
    liquidation_proximity?: SortOrder
    liquidation_price?: SortOrder
    liquidation_value?: SortOrder
    next_price?: SortOrder
    type?: SortOrder
  }

  export type HighestRiskPositionsSumOrderByAggregateInput = {
    collateral_ratio?: SortOrder
    collateral_value?: SortOrder
    liquidation_proximity?: SortOrder
    liquidation_price?: SortOrder
    liquidation_value?: SortOrder
    next_price?: SortOrder
  }

  export type EnumVaultTypeNullableWithAggregatesFilter = {
    equals?: VaultType | null
    in?: Enumerable<VaultType> | null
    notIn?: Enumerable<VaultType> | null
    not?: NestedEnumVaultTypeNullableWithAggregatesFilter | VaultType | null
    _count?: NestedIntNullableFilter
    _min?: NestedEnumVaultTypeNullableFilter
    _max?: NestedEnumVaultTypeNullableFilter
  }

  export type HighestMultiplyPnlProtocol_id_position_idCompoundUniqueInput = {
    protocol_id: string
    position_id: string
  }

  export type HighestMultiplyPnlCountOrderByAggregateInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_value?: SortOrder
    vault_multiple?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    net_profit_all?: SortOrder
    net_profit_1d?: SortOrder
    net_profit_7d?: SortOrder
    net_profit_30d?: SortOrder
    net_profit_365d?: SortOrder
    net_profit_ytd?: SortOrder
    last_action?: SortOrder
    type?: SortOrder
  }

  export type HighestMultiplyPnlAvgOrderByAggregateInput = {
    collateral_value?: SortOrder
    vault_multiple?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    net_profit_all?: SortOrder
    net_profit_1d?: SortOrder
    net_profit_7d?: SortOrder
    net_profit_30d?: SortOrder
    net_profit_365d?: SortOrder
    net_profit_ytd?: SortOrder
  }

  export type HighestMultiplyPnlMaxOrderByAggregateInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_value?: SortOrder
    vault_multiple?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    net_profit_all?: SortOrder
    net_profit_1d?: SortOrder
    net_profit_7d?: SortOrder
    net_profit_30d?: SortOrder
    net_profit_365d?: SortOrder
    net_profit_ytd?: SortOrder
    type?: SortOrder
  }

  export type HighestMultiplyPnlMinOrderByAggregateInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_value?: SortOrder
    vault_multiple?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    net_profit_all?: SortOrder
    net_profit_1d?: SortOrder
    net_profit_7d?: SortOrder
    net_profit_30d?: SortOrder
    net_profit_365d?: SortOrder
    net_profit_ytd?: SortOrder
    type?: SortOrder
  }

  export type HighestMultiplyPnlSumOrderByAggregateInput = {
    collateral_value?: SortOrder
    vault_multiple?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    net_profit_all?: SortOrder
    net_profit_1d?: SortOrder
    net_profit_7d?: SortOrder
    net_profit_30d?: SortOrder
    net_profit_365d?: SortOrder
    net_profit_ytd?: SortOrder
  }

  export type MostYieldEarnedProtocol_id_position_idCompoundUniqueInput = {
    protocol_id: string
    position_id: string
  }

  export type MostYieldEarnedCountOrderByAggregateInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_value?: SortOrder
    net_value?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    yield_30d?: SortOrder
    last_action?: SortOrder
    type?: SortOrder
  }

  export type MostYieldEarnedAvgOrderByAggregateInput = {
    collateral_value?: SortOrder
    net_value?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    yield_30d?: SortOrder
  }

  export type MostYieldEarnedMaxOrderByAggregateInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_value?: SortOrder
    net_value?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    yield_30d?: SortOrder
    type?: SortOrder
  }

  export type MostYieldEarnedMinOrderByAggregateInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_value?: SortOrder
    net_value?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    yield_30d?: SortOrder
    type?: SortOrder
  }

  export type MostYieldEarnedSumOrderByAggregateInput = {
    collateral_value?: SortOrder
    net_value?: SortOrder
    pnl_all?: SortOrder
    pnl_1d?: SortOrder
    pnl_7d?: SortOrder
    pnl_30d?: SortOrder
    pnl_365d?: SortOrder
    pnl_ytd?: SortOrder
    yield_30d?: SortOrder
  }

  export type LargestDebtProtocol_id_position_idCompoundUniqueInput = {
    protocol_id: string
    position_id: string
  }

  export type LargestDebtCountOrderByAggregateInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_value?: SortOrder
    liquidation_proximity?: SortOrder
    vault_debt?: SortOrder
    coll_ratio?: SortOrder
    last_action?: SortOrder
    type?: SortOrder
  }

  export type LargestDebtAvgOrderByAggregateInput = {
    collateral_value?: SortOrder
    liquidation_proximity?: SortOrder
    vault_debt?: SortOrder
    coll_ratio?: SortOrder
  }

  export type LargestDebtMaxOrderByAggregateInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_value?: SortOrder
    liquidation_proximity?: SortOrder
    vault_debt?: SortOrder
    coll_ratio?: SortOrder
    type?: SortOrder
  }

  export type LargestDebtMinOrderByAggregateInput = {
    protocol_id?: SortOrder
    position_id?: SortOrder
    collateral_type?: SortOrder
    token?: SortOrder
    collateral_value?: SortOrder
    liquidation_proximity?: SortOrder
    vault_debt?: SortOrder
    coll_ratio?: SortOrder
    type?: SortOrder
  }

  export type LargestDebtSumOrderByAggregateInput = {
    collateral_value?: SortOrder
    liquidation_proximity?: SortOrder
    vault_debt?: SortOrder
    coll_ratio?: SortOrder
  }

  export type EnumProtocolFilter = {
    equals?: Protocol
    in?: Enumerable<Protocol>
    notIn?: Enumerable<Protocol>
    not?: NestedEnumProtocolFilter | Protocol
  }

  export type UsersWhoFollowVaultsUser_addressVault_idVault_chain_idProtocolCompoundUniqueInput = {
    user_address: string
    vault_id: number
    vault_chain_id: number
    protocol: Protocol
  }

  export type UsersWhoFollowVaultsCountOrderByAggregateInput = {
    user_address?: SortOrder
    vault_id?: SortOrder
    vault_chain_id?: SortOrder
    protocol?: SortOrder
  }

  export type UsersWhoFollowVaultsAvgOrderByAggregateInput = {
    vault_id?: SortOrder
    vault_chain_id?: SortOrder
  }

  export type UsersWhoFollowVaultsMaxOrderByAggregateInput = {
    user_address?: SortOrder
    vault_id?: SortOrder
    vault_chain_id?: SortOrder
    protocol?: SortOrder
  }

  export type UsersWhoFollowVaultsMinOrderByAggregateInput = {
    user_address?: SortOrder
    vault_id?: SortOrder
    vault_chain_id?: SortOrder
    protocol?: SortOrder
  }

  export type UsersWhoFollowVaultsSumOrderByAggregateInput = {
    vault_id?: SortOrder
    vault_chain_id?: SortOrder
  }

  export type EnumProtocolWithAggregatesFilter = {
    equals?: Protocol
    in?: Enumerable<Protocol>
    notIn?: Enumerable<Protocol>
    not?: NestedEnumProtocolWithAggregatesFilter | Protocol
    _count?: NestedIntFilter
    _min?: NestedEnumProtocolFilter
    _max?: NestedEnumProtocolFilter
  }

  export type EnumNetworkNamesFilter = {
    equals?: NetworkNames
    in?: Enumerable<NetworkNames>
    notIn?: Enumerable<NetworkNames>
    not?: NestedEnumNetworkNamesFilter | NetworkNames
  }

  export type EnumProductNullableListFilter = {
    equals?: Enumerable<Product> | null
    has?: Product | null
    hasEvery?: Enumerable<Product>
    hasSome?: Enumerable<Product>
    isEmpty?: boolean
  }

  export type EnumProductHubManagementSimpleNullableFilter = {
    equals?: ProductHubManagementSimple | null
    in?: Enumerable<ProductHubManagementSimple> | null
    notIn?: Enumerable<ProductHubManagementSimple> | null
    not?: NestedEnumProductHubManagementSimpleNullableFilter | ProductHubManagementSimple | null
  }

  export type EnumProductHubStrategyNullableFilter = {
    equals?: ProductHubStrategy | null
    in?: Enumerable<ProductHubStrategy> | null
    notIn?: Enumerable<ProductHubStrategy> | null
    not?: NestedEnumProductHubStrategyNullableFilter | ProductHubStrategy | null
  }

  export type BoolNullableFilter = {
    equals?: boolean | null
    not?: NestedBoolNullableFilter | boolean | null
  }

  export type ProductHubItemsProduct_hub_item_idCompoundUniqueInput = {
    label: string
    network: NetworkNames
    product: Enumerable<Product>
    protocol: Protocol
    primaryToken: string
    secondaryToken: string
  }

  export type ProductHubItemsCountOrderByAggregateInput = {
    id?: SortOrder
    label?: SortOrder
    network?: SortOrder
    primaryToken?: SortOrder
    primaryTokenGroup?: SortOrder
    product?: SortOrder
    protocol?: SortOrder
    secondaryToken?: SortOrder
    secondaryTokenGroup?: SortOrder
    weeklyNetApy?: SortOrder
    depositToken?: SortOrder
    earnStrategy?: SortOrder
    fee?: SortOrder
    liquidity?: SortOrder
    managementType?: SortOrder
    maxLtv?: SortOrder
    maxMultiply?: SortOrder
    multiplyStrategy?: SortOrder
    multiplyStrategyType?: SortOrder
    reverseTokens?: SortOrder
    updatedAt?: SortOrder
  }

  export type ProductHubItemsMaxOrderByAggregateInput = {
    id?: SortOrder
    label?: SortOrder
    network?: SortOrder
    primaryToken?: SortOrder
    primaryTokenGroup?: SortOrder
    protocol?: SortOrder
    secondaryToken?: SortOrder
    secondaryTokenGroup?: SortOrder
    weeklyNetApy?: SortOrder
    depositToken?: SortOrder
    earnStrategy?: SortOrder
    fee?: SortOrder
    liquidity?: SortOrder
    managementType?: SortOrder
    maxLtv?: SortOrder
    maxMultiply?: SortOrder
    multiplyStrategy?: SortOrder
    multiplyStrategyType?: SortOrder
    reverseTokens?: SortOrder
    updatedAt?: SortOrder
  }

  export type ProductHubItemsMinOrderByAggregateInput = {
    id?: SortOrder
    label?: SortOrder
    network?: SortOrder
    primaryToken?: SortOrder
    primaryTokenGroup?: SortOrder
    protocol?: SortOrder
    secondaryToken?: SortOrder
    secondaryTokenGroup?: SortOrder
    weeklyNetApy?: SortOrder
    depositToken?: SortOrder
    earnStrategy?: SortOrder
    fee?: SortOrder
    liquidity?: SortOrder
    managementType?: SortOrder
    maxLtv?: SortOrder
    maxMultiply?: SortOrder
    multiplyStrategy?: SortOrder
    multiplyStrategyType?: SortOrder
    reverseTokens?: SortOrder
    updatedAt?: SortOrder
  }

  export type EnumNetworkNamesWithAggregatesFilter = {
    equals?: NetworkNames
    in?: Enumerable<NetworkNames>
    notIn?: Enumerable<NetworkNames>
    not?: NestedEnumNetworkNamesWithAggregatesFilter | NetworkNames
    _count?: NestedIntFilter
    _min?: NestedEnumNetworkNamesFilter
    _max?: NestedEnumNetworkNamesFilter
  }

  export type EnumProductHubManagementSimpleNullableWithAggregatesFilter = {
    equals?: ProductHubManagementSimple | null
    in?: Enumerable<ProductHubManagementSimple> | null
    notIn?: Enumerable<ProductHubManagementSimple> | null
    not?: NestedEnumProductHubManagementSimpleNullableWithAggregatesFilter | ProductHubManagementSimple | null
    _count?: NestedIntNullableFilter
    _min?: NestedEnumProductHubManagementSimpleNullableFilter
    _max?: NestedEnumProductHubManagementSimpleNullableFilter
  }

  export type EnumProductHubStrategyNullableWithAggregatesFilter = {
    equals?: ProductHubStrategy | null
    in?: Enumerable<ProductHubStrategy> | null
    notIn?: Enumerable<ProductHubStrategy> | null
    not?: NestedEnumProductHubStrategyNullableWithAggregatesFilter | ProductHubStrategy | null
    _count?: NestedIntNullableFilter
    _min?: NestedEnumProductHubStrategyNullableFilter
    _max?: NestedEnumProductHubStrategyNullableFilter
  }

  export type BoolNullableWithAggregatesFilter = {
    equals?: boolean | null
    not?: NestedBoolNullableWithAggregatesFilter | boolean | null
    _count?: NestedIntNullableFilter
    _min?: NestedBoolNullableFilter
    _max?: NestedBoolNullableFilter
  }

  export type AjnaRewardsWeeklyClaimWeek_number_userAddress_chain_id_unique_idCompoundUniqueInput = {
    week_number: number
    user_address: string
    chain_id: number
  }

  export type AjnaRewardsWeeklyClaimCountOrderByAggregateInput = {
    id?: SortOrder
    timestamp?: SortOrder
    chain_id?: SortOrder
    user_address?: SortOrder
    amount?: SortOrder
    week_number?: SortOrder
    proof?: SortOrder
  }

  export type AjnaRewardsWeeklyClaimAvgOrderByAggregateInput = {
    id?: SortOrder
    chain_id?: SortOrder
    week_number?: SortOrder
  }

  export type AjnaRewardsWeeklyClaimMaxOrderByAggregateInput = {
    id?: SortOrder
    timestamp?: SortOrder
    chain_id?: SortOrder
    user_address?: SortOrder
    amount?: SortOrder
    week_number?: SortOrder
  }

  export type AjnaRewardsWeeklyClaimMinOrderByAggregateInput = {
    id?: SortOrder
    timestamp?: SortOrder
    chain_id?: SortOrder
    user_address?: SortOrder
    amount?: SortOrder
    week_number?: SortOrder
  }

  export type AjnaRewardsWeeklyClaimSumOrderByAggregateInput = {
    id?: SortOrder
    chain_id?: SortOrder
    week_number?: SortOrder
  }

  export type AjnaRewardsDailyClaimDay_number_userAddress_chain_id_unique_idCompoundUniqueInput = {
    day_number: number
    user_address: string
    chain_id: number
  }

  export type AjnaRewardsDailyClaimCountOrderByAggregateInput = {
    id?: SortOrder
    timestamp?: SortOrder
    chain_id?: SortOrder
    user_address?: SortOrder
    amount?: SortOrder
    week_number?: SortOrder
    day_number?: SortOrder
  }

  export type AjnaRewardsDailyClaimAvgOrderByAggregateInput = {
    id?: SortOrder
    chain_id?: SortOrder
    week_number?: SortOrder
    day_number?: SortOrder
  }

  export type AjnaRewardsDailyClaimMaxOrderByAggregateInput = {
    id?: SortOrder
    timestamp?: SortOrder
    chain_id?: SortOrder
    user_address?: SortOrder
    amount?: SortOrder
    week_number?: SortOrder
    day_number?: SortOrder
  }

  export type AjnaRewardsDailyClaimMinOrderByAggregateInput = {
    id?: SortOrder
    timestamp?: SortOrder
    chain_id?: SortOrder
    user_address?: SortOrder
    amount?: SortOrder
    week_number?: SortOrder
    day_number?: SortOrder
  }

  export type AjnaRewardsDailyClaimSumOrderByAggregateInput = {
    id?: SortOrder
    chain_id?: SortOrder
    week_number?: SortOrder
    day_number?: SortOrder
  }

  export type AjnaRewardsMerkleTreeWeek_number_chain_id_unique_idCompoundUniqueInput = {
    week_number: number
    chain_id: number
  }

  export type AjnaRewardsMerkleTreeCountOrderByAggregateInput = {
    id?: SortOrder
    timestamp?: SortOrder
    chain_id?: SortOrder
    week_number?: SortOrder
    tree_root?: SortOrder
    tx_processed?: SortOrder
  }

  export type AjnaRewardsMerkleTreeAvgOrderByAggregateInput = {
    id?: SortOrder
    chain_id?: SortOrder
    week_number?: SortOrder
  }

  export type AjnaRewardsMerkleTreeMaxOrderByAggregateInput = {
    id?: SortOrder
    timestamp?: SortOrder
    chain_id?: SortOrder
    week_number?: SortOrder
    tree_root?: SortOrder
    tx_processed?: SortOrder
  }

  export type AjnaRewardsMerkleTreeMinOrderByAggregateInput = {
    id?: SortOrder
    timestamp?: SortOrder
    chain_id?: SortOrder
    week_number?: SortOrder
    tree_root?: SortOrder
    tx_processed?: SortOrder
  }

  export type AjnaRewardsMerkleTreeSumOrderByAggregateInput = {
    id?: SortOrder
    chain_id?: SortOrder
    week_number?: SortOrder
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type EnumVaultTypeFieldUpdateOperationsInput = {
    set?: VaultType
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type UserCreateNestedOneWithoutReferred_usersInput = {
    create?: XOR<UserCreateWithoutReferred_usersInput, UserUncheckedCreateWithoutReferred_usersInput>
    connectOrCreate?: UserCreateOrConnectWithoutReferred_usersInput
    connect?: UserWhereUniqueInput
  }

  export type UserCreateNestedManyWithoutUser_that_referredInput = {
    create?: XOR<Enumerable<UserCreateWithoutUser_that_referredInput>, Enumerable<UserUncheckedCreateWithoutUser_that_referredInput>>
    connectOrCreate?: Enumerable<UserCreateOrConnectWithoutUser_that_referredInput>
    createMany?: UserCreateManyUser_that_referredInputEnvelope
    connect?: Enumerable<UserWhereUniqueInput>
  }

  export type WeeklyClaimCreateNestedManyWithoutClaimantInput = {
    create?: XOR<Enumerable<WeeklyClaimCreateWithoutClaimantInput>, Enumerable<WeeklyClaimUncheckedCreateWithoutClaimantInput>>
    connectOrCreate?: Enumerable<WeeklyClaimCreateOrConnectWithoutClaimantInput>
    createMany?: WeeklyClaimCreateManyClaimantInputEnvelope
    connect?: Enumerable<WeeklyClaimWhereUniqueInput>
  }

  export type UserUncheckedCreateNestedManyWithoutUser_that_referredInput = {
    create?: XOR<Enumerable<UserCreateWithoutUser_that_referredInput>, Enumerable<UserUncheckedCreateWithoutUser_that_referredInput>>
    connectOrCreate?: Enumerable<UserCreateOrConnectWithoutUser_that_referredInput>
    createMany?: UserCreateManyUser_that_referredInputEnvelope
    connect?: Enumerable<UserWhereUniqueInput>
  }

  export type WeeklyClaimUncheckedCreateNestedManyWithoutClaimantInput = {
    create?: XOR<Enumerable<WeeklyClaimCreateWithoutClaimantInput>, Enumerable<WeeklyClaimUncheckedCreateWithoutClaimantInput>>
    connectOrCreate?: Enumerable<WeeklyClaimCreateOrConnectWithoutClaimantInput>
    createMany?: WeeklyClaimCreateManyClaimantInputEnvelope
    connect?: Enumerable<WeeklyClaimWhereUniqueInput>
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type UserUpdateOneWithoutReferred_usersNestedInput = {
    create?: XOR<UserCreateWithoutReferred_usersInput, UserUncheckedCreateWithoutReferred_usersInput>
    connectOrCreate?: UserCreateOrConnectWithoutReferred_usersInput
    upsert?: UserUpsertWithoutReferred_usersInput
    disconnect?: boolean
    delete?: boolean
    connect?: UserWhereUniqueInput
    update?: XOR<UserUpdateWithoutReferred_usersInput, UserUncheckedUpdateWithoutReferred_usersInput>
  }

  export type UserUpdateManyWithoutUser_that_referredNestedInput = {
    create?: XOR<Enumerable<UserCreateWithoutUser_that_referredInput>, Enumerable<UserUncheckedCreateWithoutUser_that_referredInput>>
    connectOrCreate?: Enumerable<UserCreateOrConnectWithoutUser_that_referredInput>
    upsert?: Enumerable<UserUpsertWithWhereUniqueWithoutUser_that_referredInput>
    createMany?: UserCreateManyUser_that_referredInputEnvelope
    set?: Enumerable<UserWhereUniqueInput>
    disconnect?: Enumerable<UserWhereUniqueInput>
    delete?: Enumerable<UserWhereUniqueInput>
    connect?: Enumerable<UserWhereUniqueInput>
    update?: Enumerable<UserUpdateWithWhereUniqueWithoutUser_that_referredInput>
    updateMany?: Enumerable<UserUpdateManyWithWhereWithoutUser_that_referredInput>
    deleteMany?: Enumerable<UserScalarWhereInput>
  }

  export type WeeklyClaimUpdateManyWithoutClaimantNestedInput = {
    create?: XOR<Enumerable<WeeklyClaimCreateWithoutClaimantInput>, Enumerable<WeeklyClaimUncheckedCreateWithoutClaimantInput>>
    connectOrCreate?: Enumerable<WeeklyClaimCreateOrConnectWithoutClaimantInput>
    upsert?: Enumerable<WeeklyClaimUpsertWithWhereUniqueWithoutClaimantInput>
    createMany?: WeeklyClaimCreateManyClaimantInputEnvelope
    set?: Enumerable<WeeklyClaimWhereUniqueInput>
    disconnect?: Enumerable<WeeklyClaimWhereUniqueInput>
    delete?: Enumerable<WeeklyClaimWhereUniqueInput>
    connect?: Enumerable<WeeklyClaimWhereUniqueInput>
    update?: Enumerable<WeeklyClaimUpdateWithWhereUniqueWithoutClaimantInput>
    updateMany?: Enumerable<WeeklyClaimUpdateManyWithWhereWithoutClaimantInput>
    deleteMany?: Enumerable<WeeklyClaimScalarWhereInput>
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type UserUncheckedUpdateManyWithoutUser_that_referredNestedInput = {
    create?: XOR<Enumerable<UserCreateWithoutUser_that_referredInput>, Enumerable<UserUncheckedCreateWithoutUser_that_referredInput>>
    connectOrCreate?: Enumerable<UserCreateOrConnectWithoutUser_that_referredInput>
    upsert?: Enumerable<UserUpsertWithWhereUniqueWithoutUser_that_referredInput>
    createMany?: UserCreateManyUser_that_referredInputEnvelope
    set?: Enumerable<UserWhereUniqueInput>
    disconnect?: Enumerable<UserWhereUniqueInput>
    delete?: Enumerable<UserWhereUniqueInput>
    connect?: Enumerable<UserWhereUniqueInput>
    update?: Enumerable<UserUpdateWithWhereUniqueWithoutUser_that_referredInput>
    updateMany?: Enumerable<UserUpdateManyWithWhereWithoutUser_that_referredInput>
    deleteMany?: Enumerable<UserScalarWhereInput>
  }

  export type WeeklyClaimUncheckedUpdateManyWithoutClaimantNestedInput = {
    create?: XOR<Enumerable<WeeklyClaimCreateWithoutClaimantInput>, Enumerable<WeeklyClaimUncheckedCreateWithoutClaimantInput>>
    connectOrCreate?: Enumerable<WeeklyClaimCreateOrConnectWithoutClaimantInput>
    upsert?: Enumerable<WeeklyClaimUpsertWithWhereUniqueWithoutClaimantInput>
    createMany?: WeeklyClaimCreateManyClaimantInputEnvelope
    set?: Enumerable<WeeklyClaimWhereUniqueInput>
    disconnect?: Enumerable<WeeklyClaimWhereUniqueInput>
    delete?: Enumerable<WeeklyClaimWhereUniqueInput>
    connect?: Enumerable<WeeklyClaimWhereUniqueInput>
    update?: Enumerable<WeeklyClaimUpdateWithWhereUniqueWithoutClaimantInput>
    updateMany?: Enumerable<WeeklyClaimUpdateManyWithWhereWithoutClaimantInput>
    deleteMany?: Enumerable<WeeklyClaimScalarWhereInput>
  }

  export type WeeklyClaimCreateproofInput = {
    set: Enumerable<string>
  }

  export type UserCreateNestedOneWithoutWeekly_claimsInput = {
    create?: XOR<UserCreateWithoutWeekly_claimsInput, UserUncheckedCreateWithoutWeekly_claimsInput>
    connectOrCreate?: UserCreateOrConnectWithoutWeekly_claimsInput
    connect?: UserWhereUniqueInput
  }

  export type WeeklyClaimUpdateproofInput = {
    set?: Enumerable<string>
    push?: string | Enumerable<string>
  }

  export type UserUpdateOneRequiredWithoutWeekly_claimsNestedInput = {
    create?: XOR<UserCreateWithoutWeekly_claimsInput, UserUncheckedCreateWithoutWeekly_claimsInput>
    connectOrCreate?: UserCreateOrConnectWithoutWeekly_claimsInput
    upsert?: UserUpsertWithoutWeekly_claimsInput
    connect?: UserWhereUniqueInput
    update?: XOR<UserUpdateWithoutWeekly_claimsInput, UserUncheckedUpdateWithoutWeekly_claimsInput>
  }

  export type DecimalFieldUpdateOperationsInput = {
    set?: Decimal | DecimalJsLike | number | string
    increment?: Decimal | DecimalJsLike | number | string
    decrement?: Decimal | DecimalJsLike | number | string
    multiply?: Decimal | DecimalJsLike | number | string
    divide?: Decimal | DecimalJsLike | number | string
  }

  export type NullableDecimalFieldUpdateOperationsInput = {
    set?: Decimal | DecimalJsLike | number | string | null
    increment?: Decimal | DecimalJsLike | number | string
    decrement?: Decimal | DecimalJsLike | number | string
    multiply?: Decimal | DecimalJsLike | number | string
    divide?: Decimal | DecimalJsLike | number | string
  }

  export type NullableEnumVaultTypeFieldUpdateOperationsInput = {
    set?: VaultType | null
  }

  export type EnumProtocolFieldUpdateOperationsInput = {
    set?: Protocol
  }

  export type ProductHubItemsCreateproductInput = {
    set: Enumerable<Product>
  }

  export type EnumNetworkNamesFieldUpdateOperationsInput = {
    set?: NetworkNames
  }

  export type ProductHubItemsUpdateproductInput = {
    set?: Enumerable<Product>
    push?: Enumerable<Product>
  }

  export type NullableEnumProductHubManagementSimpleFieldUpdateOperationsInput = {
    set?: ProductHubManagementSimple | null
  }

  export type NullableEnumProductHubStrategyFieldUpdateOperationsInput = {
    set?: ProductHubStrategy | null
  }

  export type NullableBoolFieldUpdateOperationsInput = {
    set?: boolean | null
  }

  export type AjnaRewardsWeeklyClaimCreateproofInput = {
    set: Enumerable<string>
  }

  export type AjnaRewardsWeeklyClaimUpdateproofInput = {
    set?: Enumerable<string>
    push?: string | Enumerable<string>
  }

  export type NestedIntFilter = {
    equals?: number
    in?: Enumerable<number> | number
    notIn?: Enumerable<number> | number
    lt?: number
    lte?: number
    gt?: number
    gte?: number
    not?: NestedIntFilter | number
  }

  export type NestedStringFilter = {
    equals?: string
    in?: Enumerable<string> | string
    notIn?: Enumerable<string> | string
    lt?: string
    lte?: string
    gt?: string
    gte?: string
    contains?: string
    startsWith?: string
    endsWith?: string
    not?: NestedStringFilter | string
  }

  export type NestedDateTimeNullableFilter = {
    equals?: Date | string | null
    in?: Enumerable<Date> | Enumerable<string> | Date | string | null
    notIn?: Enumerable<Date> | Enumerable<string> | Date | string | null
    lt?: Date | string
    lte?: Date | string
    gt?: Date | string
    gte?: Date | string
    not?: NestedDateTimeNullableFilter | Date | string | null
  }

  export type NestedIntWithAggregatesFilter = {
    equals?: number
    in?: Enumerable<number> | number
    notIn?: Enumerable<number> | number
    lt?: number
    lte?: number
    gt?: number
    gte?: number
    not?: NestedIntWithAggregatesFilter | number
    _count?: NestedIntFilter
    _avg?: NestedFloatFilter
    _sum?: NestedIntFilter
    _min?: NestedIntFilter
    _max?: NestedIntFilter
  }

  export type NestedFloatFilter = {
    equals?: number
    in?: Enumerable<number> | number
    notIn?: Enumerable<number> | number
    lt?: number
    lte?: number
    gt?: number
    gte?: number
    not?: NestedFloatFilter | number
  }

  export type NestedStringWithAggregatesFilter = {
    equals?: string
    in?: Enumerable<string> | string
    notIn?: Enumerable<string> | string
    lt?: string
    lte?: string
    gt?: string
    gte?: string
    contains?: string
    startsWith?: string
    endsWith?: string
    not?: NestedStringWithAggregatesFilter | string
    _count?: NestedIntFilter
    _min?: NestedStringFilter
    _max?: NestedStringFilter
  }

  export type NestedDateTimeNullableWithAggregatesFilter = {
    equals?: Date | string | null
    in?: Enumerable<Date> | Enumerable<string> | Date | string | null
    notIn?: Enumerable<Date> | Enumerable<string> | Date | string | null
    lt?: Date | string
    lte?: Date | string
    gt?: Date | string
    gte?: Date | string
    not?: NestedDateTimeNullableWithAggregatesFilter | Date | string | null
    _count?: NestedIntNullableFilter
    _min?: NestedDateTimeNullableFilter
    _max?: NestedDateTimeNullableFilter
  }

  export type NestedIntNullableFilter = {
    equals?: number | null
    in?: Enumerable<number> | number | null
    notIn?: Enumerable<number> | number | null
    lt?: number
    lte?: number
    gt?: number
    gte?: number
    not?: NestedIntNullableFilter | number | null
  }

  export type NestedDateTimeFilter = {
    equals?: Date | string
    in?: Enumerable<Date> | Enumerable<string> | Date | string
    notIn?: Enumerable<Date> | Enumerable<string> | Date | string
    lt?: Date | string
    lte?: Date | string
    gt?: Date | string
    gte?: Date | string
    not?: NestedDateTimeFilter | Date | string
  }

  export type NestedDateTimeWithAggregatesFilter = {
    equals?: Date | string
    in?: Enumerable<Date> | Enumerable<string> | Date | string
    notIn?: Enumerable<Date> | Enumerable<string> | Date | string
    lt?: Date | string
    lte?: Date | string
    gt?: Date | string
    gte?: Date | string
    not?: NestedDateTimeWithAggregatesFilter | Date | string
    _count?: NestedIntFilter
    _min?: NestedDateTimeFilter
    _max?: NestedDateTimeFilter
  }

  export type NestedEnumVaultTypeFilter = {
    equals?: VaultType
    in?: Enumerable<VaultType>
    notIn?: Enumerable<VaultType>
    not?: NestedEnumVaultTypeFilter | VaultType
  }

  export type NestedEnumVaultTypeWithAggregatesFilter = {
    equals?: VaultType
    in?: Enumerable<VaultType>
    notIn?: Enumerable<VaultType>
    not?: NestedEnumVaultTypeWithAggregatesFilter | VaultType
    _count?: NestedIntFilter
    _min?: NestedEnumVaultTypeFilter
    _max?: NestedEnumVaultTypeFilter
  }

  export type NestedIntNullableWithAggregatesFilter = {
    equals?: number | null
    in?: Enumerable<number> | number | null
    notIn?: Enumerable<number> | number | null
    lt?: number
    lte?: number
    gt?: number
    gte?: number
    not?: NestedIntNullableWithAggregatesFilter | number | null
    _count?: NestedIntNullableFilter
    _avg?: NestedFloatNullableFilter
    _sum?: NestedIntNullableFilter
    _min?: NestedIntNullableFilter
    _max?: NestedIntNullableFilter
  }

  export type NestedFloatNullableFilter = {
    equals?: number | null
    in?: Enumerable<number> | number | null
    notIn?: Enumerable<number> | number | null
    lt?: number
    lte?: number
    gt?: number
    gte?: number
    not?: NestedFloatNullableFilter | number | null
  }

  export type NestedStringNullableFilter = {
    equals?: string | null
    in?: Enumerable<string> | string | null
    notIn?: Enumerable<string> | string | null
    lt?: string
    lte?: string
    gt?: string
    gte?: string
    contains?: string
    startsWith?: string
    endsWith?: string
    not?: NestedStringNullableFilter | string | null
  }

  export type NestedBoolFilter = {
    equals?: boolean
    not?: NestedBoolFilter | boolean
  }

  export type NestedStringNullableWithAggregatesFilter = {
    equals?: string | null
    in?: Enumerable<string> | string | null
    notIn?: Enumerable<string> | string | null
    lt?: string
    lte?: string
    gt?: string
    gte?: string
    contains?: string
    startsWith?: string
    endsWith?: string
    not?: NestedStringNullableWithAggregatesFilter | string | null
    _count?: NestedIntNullableFilter
    _min?: NestedStringNullableFilter
    _max?: NestedStringNullableFilter
  }

  export type NestedBoolWithAggregatesFilter = {
    equals?: boolean
    not?: NestedBoolWithAggregatesFilter | boolean
    _count?: NestedIntFilter
    _min?: NestedBoolFilter
    _max?: NestedBoolFilter
  }

  export type NestedDecimalFilter = {
    equals?: Decimal | DecimalJsLike | number | string
    in?: Enumerable<Decimal> | Enumerable<DecimalJsLike> | Enumerable<number> | Enumerable<string> | Decimal | DecimalJsLike | number | string
    notIn?: Enumerable<Decimal> | Enumerable<DecimalJsLike> | Enumerable<number> | Enumerable<string> | Decimal | DecimalJsLike | number | string
    lt?: Decimal | DecimalJsLike | number | string
    lte?: Decimal | DecimalJsLike | number | string
    gt?: Decimal | DecimalJsLike | number | string
    gte?: Decimal | DecimalJsLike | number | string
    not?: NestedDecimalFilter | Decimal | DecimalJsLike | number | string
  }

  export type NestedDecimalNullableFilter = {
    equals?: Decimal | DecimalJsLike | number | string | null
    in?: Enumerable<Decimal> | Enumerable<DecimalJsLike> | Enumerable<number> | Enumerable<string> | Decimal | DecimalJsLike | number | string | null
    notIn?: Enumerable<Decimal> | Enumerable<DecimalJsLike> | Enumerable<number> | Enumerable<string> | Decimal | DecimalJsLike | number | string | null
    lt?: Decimal | DecimalJsLike | number | string
    lte?: Decimal | DecimalJsLike | number | string
    gt?: Decimal | DecimalJsLike | number | string
    gte?: Decimal | DecimalJsLike | number | string
    not?: NestedDecimalNullableFilter | Decimal | DecimalJsLike | number | string | null
  }

  export type NestedDecimalWithAggregatesFilter = {
    equals?: Decimal | DecimalJsLike | number | string
    in?: Enumerable<Decimal> | Enumerable<DecimalJsLike> | Enumerable<number> | Enumerable<string> | Decimal | DecimalJsLike | number | string
    notIn?: Enumerable<Decimal> | Enumerable<DecimalJsLike> | Enumerable<number> | Enumerable<string> | Decimal | DecimalJsLike | number | string
    lt?: Decimal | DecimalJsLike | number | string
    lte?: Decimal | DecimalJsLike | number | string
    gt?: Decimal | DecimalJsLike | number | string
    gte?: Decimal | DecimalJsLike | number | string
    not?: NestedDecimalWithAggregatesFilter | Decimal | DecimalJsLike | number | string
    _count?: NestedIntFilter
    _avg?: NestedDecimalFilter
    _sum?: NestedDecimalFilter
    _min?: NestedDecimalFilter
    _max?: NestedDecimalFilter
  }

  export type NestedDecimalNullableWithAggregatesFilter = {
    equals?: Decimal | DecimalJsLike | number | string | null
    in?: Enumerable<Decimal> | Enumerable<DecimalJsLike> | Enumerable<number> | Enumerable<string> | Decimal | DecimalJsLike | number | string | null
    notIn?: Enumerable<Decimal> | Enumerable<DecimalJsLike> | Enumerable<number> | Enumerable<string> | Decimal | DecimalJsLike | number | string | null
    lt?: Decimal | DecimalJsLike | number | string
    lte?: Decimal | DecimalJsLike | number | string
    gt?: Decimal | DecimalJsLike | number | string
    gte?: Decimal | DecimalJsLike | number | string
    not?: NestedDecimalNullableWithAggregatesFilter | Decimal | DecimalJsLike | number | string | null
    _count?: NestedIntNullableFilter
    _avg?: NestedDecimalNullableFilter
    _sum?: NestedDecimalNullableFilter
    _min?: NestedDecimalNullableFilter
    _max?: NestedDecimalNullableFilter
  }
  export type NestedJsonFilter = 
    | PatchUndefined<
        Either<Required<NestedJsonFilterBase>, Exclude<keyof Required<NestedJsonFilterBase>, 'path'>>,
        Required<NestedJsonFilterBase>
      >
    | OptionalFlat<Omit<Required<NestedJsonFilterBase>, 'path'>>

  export type NestedJsonFilterBase = {
    equals?: InputJsonValue | JsonNullValueFilter
    path?: string[]
    string_contains?: string
    string_starts_with?: string
    string_ends_with?: string
    array_contains?: InputJsonValue | null
    array_starts_with?: InputJsonValue | null
    array_ends_with?: InputJsonValue | null
    lt?: InputJsonValue
    lte?: InputJsonValue
    gt?: InputJsonValue
    gte?: InputJsonValue
    not?: InputJsonValue | JsonNullValueFilter
  }

  export type NestedEnumVaultTypeNullableFilter = {
    equals?: VaultType | null
    in?: Enumerable<VaultType> | null
    notIn?: Enumerable<VaultType> | null
    not?: NestedEnumVaultTypeNullableFilter | VaultType | null
  }

  export type NestedEnumVaultTypeNullableWithAggregatesFilter = {
    equals?: VaultType | null
    in?: Enumerable<VaultType> | null
    notIn?: Enumerable<VaultType> | null
    not?: NestedEnumVaultTypeNullableWithAggregatesFilter | VaultType | null
    _count?: NestedIntNullableFilter
    _min?: NestedEnumVaultTypeNullableFilter
    _max?: NestedEnumVaultTypeNullableFilter
  }

  export type NestedEnumProtocolFilter = {
    equals?: Protocol
    in?: Enumerable<Protocol>
    notIn?: Enumerable<Protocol>
    not?: NestedEnumProtocolFilter | Protocol
  }

  export type NestedEnumProtocolWithAggregatesFilter = {
    equals?: Protocol
    in?: Enumerable<Protocol>
    notIn?: Enumerable<Protocol>
    not?: NestedEnumProtocolWithAggregatesFilter | Protocol
    _count?: NestedIntFilter
    _min?: NestedEnumProtocolFilter
    _max?: NestedEnumProtocolFilter
  }

  export type NestedEnumNetworkNamesFilter = {
    equals?: NetworkNames
    in?: Enumerable<NetworkNames>
    notIn?: Enumerable<NetworkNames>
    not?: NestedEnumNetworkNamesFilter | NetworkNames
  }

  export type NestedEnumProductHubManagementSimpleNullableFilter = {
    equals?: ProductHubManagementSimple | null
    in?: Enumerable<ProductHubManagementSimple> | null
    notIn?: Enumerable<ProductHubManagementSimple> | null
    not?: NestedEnumProductHubManagementSimpleNullableFilter | ProductHubManagementSimple | null
  }

  export type NestedEnumProductHubStrategyNullableFilter = {
    equals?: ProductHubStrategy | null
    in?: Enumerable<ProductHubStrategy> | null
    notIn?: Enumerable<ProductHubStrategy> | null
    not?: NestedEnumProductHubStrategyNullableFilter | ProductHubStrategy | null
  }

  export type NestedBoolNullableFilter = {
    equals?: boolean | null
    not?: NestedBoolNullableFilter | boolean | null
  }

  export type NestedEnumNetworkNamesWithAggregatesFilter = {
    equals?: NetworkNames
    in?: Enumerable<NetworkNames>
    notIn?: Enumerable<NetworkNames>
    not?: NestedEnumNetworkNamesWithAggregatesFilter | NetworkNames
    _count?: NestedIntFilter
    _min?: NestedEnumNetworkNamesFilter
    _max?: NestedEnumNetworkNamesFilter
  }

  export type NestedEnumProductHubManagementSimpleNullableWithAggregatesFilter = {
    equals?: ProductHubManagementSimple | null
    in?: Enumerable<ProductHubManagementSimple> | null
    notIn?: Enumerable<ProductHubManagementSimple> | null
    not?: NestedEnumProductHubManagementSimpleNullableWithAggregatesFilter | ProductHubManagementSimple | null
    _count?: NestedIntNullableFilter
    _min?: NestedEnumProductHubManagementSimpleNullableFilter
    _max?: NestedEnumProductHubManagementSimpleNullableFilter
  }

  export type NestedEnumProductHubStrategyNullableWithAggregatesFilter = {
    equals?: ProductHubStrategy | null
    in?: Enumerable<ProductHubStrategy> | null
    notIn?: Enumerable<ProductHubStrategy> | null
    not?: NestedEnumProductHubStrategyNullableWithAggregatesFilter | ProductHubStrategy | null
    _count?: NestedIntNullableFilter
    _min?: NestedEnumProductHubStrategyNullableFilter
    _max?: NestedEnumProductHubStrategyNullableFilter
  }

  export type NestedBoolNullableWithAggregatesFilter = {
    equals?: boolean | null
    not?: NestedBoolNullableWithAggregatesFilter | boolean | null
    _count?: NestedIntNullableFilter
    _min?: NestedBoolNullableFilter
    _max?: NestedBoolNullableFilter
  }

  export type UserCreateWithoutReferred_usersInput = {
    address: string
    timestamp?: Date | string
    accepted: boolean
    user_that_referred?: UserCreateNestedOneWithoutReferred_usersInput
    weekly_claims?: WeeklyClaimCreateNestedManyWithoutClaimantInput
  }

  export type UserUncheckedCreateWithoutReferred_usersInput = {
    address: string
    timestamp?: Date | string
    user_that_referred_address?: string | null
    accepted: boolean
    weekly_claims?: WeeklyClaimUncheckedCreateNestedManyWithoutClaimantInput
  }

  export type UserCreateOrConnectWithoutReferred_usersInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutReferred_usersInput, UserUncheckedCreateWithoutReferred_usersInput>
  }

  export type UserCreateWithoutUser_that_referredInput = {
    address: string
    timestamp?: Date | string
    accepted: boolean
    referred_users?: UserCreateNestedManyWithoutUser_that_referredInput
    weekly_claims?: WeeklyClaimCreateNestedManyWithoutClaimantInput
  }

  export type UserUncheckedCreateWithoutUser_that_referredInput = {
    address: string
    timestamp?: Date | string
    accepted: boolean
    referred_users?: UserUncheckedCreateNestedManyWithoutUser_that_referredInput
    weekly_claims?: WeeklyClaimUncheckedCreateNestedManyWithoutClaimantInput
  }

  export type UserCreateOrConnectWithoutUser_that_referredInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutUser_that_referredInput, UserUncheckedCreateWithoutUser_that_referredInput>
  }

  export type UserCreateManyUser_that_referredInputEnvelope = {
    data: Enumerable<UserCreateManyUser_that_referredInput>
    skipDuplicates?: boolean
  }

  export type WeeklyClaimCreateWithoutClaimantInput = {
    timestamp?: Date | string | null
    week_number: number
    proof?: WeeklyClaimCreateproofInput | Enumerable<string>
    amount: string
  }

  export type WeeklyClaimUncheckedCreateWithoutClaimantInput = {
    id?: number
    timestamp?: Date | string | null
    week_number: number
    proof?: WeeklyClaimCreateproofInput | Enumerable<string>
    amount: string
  }

  export type WeeklyClaimCreateOrConnectWithoutClaimantInput = {
    where: WeeklyClaimWhereUniqueInput
    create: XOR<WeeklyClaimCreateWithoutClaimantInput, WeeklyClaimUncheckedCreateWithoutClaimantInput>
  }

  export type WeeklyClaimCreateManyClaimantInputEnvelope = {
    data: Enumerable<WeeklyClaimCreateManyClaimantInput>
    skipDuplicates?: boolean
  }

  export type UserUpsertWithoutReferred_usersInput = {
    update: XOR<UserUpdateWithoutReferred_usersInput, UserUncheckedUpdateWithoutReferred_usersInput>
    create: XOR<UserCreateWithoutReferred_usersInput, UserUncheckedCreateWithoutReferred_usersInput>
  }

  export type UserUpdateWithoutReferred_usersInput = {
    address?: StringFieldUpdateOperationsInput | string
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    accepted?: BoolFieldUpdateOperationsInput | boolean
    user_that_referred?: UserUpdateOneWithoutReferred_usersNestedInput
    weekly_claims?: WeeklyClaimUpdateManyWithoutClaimantNestedInput
  }

  export type UserUncheckedUpdateWithoutReferred_usersInput = {
    address?: StringFieldUpdateOperationsInput | string
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    user_that_referred_address?: NullableStringFieldUpdateOperationsInput | string | null
    accepted?: BoolFieldUpdateOperationsInput | boolean
    weekly_claims?: WeeklyClaimUncheckedUpdateManyWithoutClaimantNestedInput
  }

  export type UserUpsertWithWhereUniqueWithoutUser_that_referredInput = {
    where: UserWhereUniqueInput
    update: XOR<UserUpdateWithoutUser_that_referredInput, UserUncheckedUpdateWithoutUser_that_referredInput>
    create: XOR<UserCreateWithoutUser_that_referredInput, UserUncheckedCreateWithoutUser_that_referredInput>
  }

  export type UserUpdateWithWhereUniqueWithoutUser_that_referredInput = {
    where: UserWhereUniqueInput
    data: XOR<UserUpdateWithoutUser_that_referredInput, UserUncheckedUpdateWithoutUser_that_referredInput>
  }

  export type UserUpdateManyWithWhereWithoutUser_that_referredInput = {
    where: UserScalarWhereInput
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyWithoutReferred_usersInput>
  }

  export type UserScalarWhereInput = {
    AND?: Enumerable<UserScalarWhereInput>
    OR?: Enumerable<UserScalarWhereInput>
    NOT?: Enumerable<UserScalarWhereInput>
    address?: StringFilter | string
    timestamp?: DateTimeFilter | Date | string
    user_that_referred_address?: StringNullableFilter | string | null
    accepted?: BoolFilter | boolean
  }

  export type WeeklyClaimUpsertWithWhereUniqueWithoutClaimantInput = {
    where: WeeklyClaimWhereUniqueInput
    update: XOR<WeeklyClaimUpdateWithoutClaimantInput, WeeklyClaimUncheckedUpdateWithoutClaimantInput>
    create: XOR<WeeklyClaimCreateWithoutClaimantInput, WeeklyClaimUncheckedCreateWithoutClaimantInput>
  }

  export type WeeklyClaimUpdateWithWhereUniqueWithoutClaimantInput = {
    where: WeeklyClaimWhereUniqueInput
    data: XOR<WeeklyClaimUpdateWithoutClaimantInput, WeeklyClaimUncheckedUpdateWithoutClaimantInput>
  }

  export type WeeklyClaimUpdateManyWithWhereWithoutClaimantInput = {
    where: WeeklyClaimScalarWhereInput
    data: XOR<WeeklyClaimUpdateManyMutationInput, WeeklyClaimUncheckedUpdateManyWithoutWeekly_claimsInput>
  }

  export type WeeklyClaimScalarWhereInput = {
    AND?: Enumerable<WeeklyClaimScalarWhereInput>
    OR?: Enumerable<WeeklyClaimScalarWhereInput>
    NOT?: Enumerable<WeeklyClaimScalarWhereInput>
    id?: IntFilter | number
    timestamp?: DateTimeNullableFilter | Date | string | null
    week_number?: IntFilter | number
    user_address?: StringFilter | string
    proof?: StringNullableListFilter
    amount?: StringFilter | string
  }

  export type UserCreateWithoutWeekly_claimsInput = {
    address: string
    timestamp?: Date | string
    accepted: boolean
    user_that_referred?: UserCreateNestedOneWithoutReferred_usersInput
    referred_users?: UserCreateNestedManyWithoutUser_that_referredInput
  }

  export type UserUncheckedCreateWithoutWeekly_claimsInput = {
    address: string
    timestamp?: Date | string
    user_that_referred_address?: string | null
    accepted: boolean
    referred_users?: UserUncheckedCreateNestedManyWithoutUser_that_referredInput
  }

  export type UserCreateOrConnectWithoutWeekly_claimsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutWeekly_claimsInput, UserUncheckedCreateWithoutWeekly_claimsInput>
  }

  export type UserUpsertWithoutWeekly_claimsInput = {
    update: XOR<UserUpdateWithoutWeekly_claimsInput, UserUncheckedUpdateWithoutWeekly_claimsInput>
    create: XOR<UserCreateWithoutWeekly_claimsInput, UserUncheckedCreateWithoutWeekly_claimsInput>
  }

  export type UserUpdateWithoutWeekly_claimsInput = {
    address?: StringFieldUpdateOperationsInput | string
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    accepted?: BoolFieldUpdateOperationsInput | boolean
    user_that_referred?: UserUpdateOneWithoutReferred_usersNestedInput
    referred_users?: UserUpdateManyWithoutUser_that_referredNestedInput
  }

  export type UserUncheckedUpdateWithoutWeekly_claimsInput = {
    address?: StringFieldUpdateOperationsInput | string
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    user_that_referred_address?: NullableStringFieldUpdateOperationsInput | string | null
    accepted?: BoolFieldUpdateOperationsInput | boolean
    referred_users?: UserUncheckedUpdateManyWithoutUser_that_referredNestedInput
  }

  export type UserCreateManyUser_that_referredInput = {
    address: string
    timestamp?: Date | string
    accepted: boolean
  }

  export type WeeklyClaimCreateManyClaimantInput = {
    id?: number
    timestamp?: Date | string | null
    week_number: number
    proof?: WeeklyClaimCreateproofInput | Enumerable<string>
    amount: string
  }

  export type UserUpdateWithoutUser_that_referredInput = {
    address?: StringFieldUpdateOperationsInput | string
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    accepted?: BoolFieldUpdateOperationsInput | boolean
    referred_users?: UserUpdateManyWithoutUser_that_referredNestedInput
    weekly_claims?: WeeklyClaimUpdateManyWithoutClaimantNestedInput
  }

  export type UserUncheckedUpdateWithoutUser_that_referredInput = {
    address?: StringFieldUpdateOperationsInput | string
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    accepted?: BoolFieldUpdateOperationsInput | boolean
    referred_users?: UserUncheckedUpdateManyWithoutUser_that_referredNestedInput
    weekly_claims?: WeeklyClaimUncheckedUpdateManyWithoutClaimantNestedInput
  }

  export type UserUncheckedUpdateManyWithoutReferred_usersInput = {
    address?: StringFieldUpdateOperationsInput | string
    timestamp?: DateTimeFieldUpdateOperationsInput | Date | string
    accepted?: BoolFieldUpdateOperationsInput | boolean
  }

  export type WeeklyClaimUpdateWithoutClaimantInput = {
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    week_number?: IntFieldUpdateOperationsInput | number
    proof?: WeeklyClaimUpdateproofInput | Enumerable<string>
    amount?: StringFieldUpdateOperationsInput | string
  }

  export type WeeklyClaimUncheckedUpdateWithoutClaimantInput = {
    id?: IntFieldUpdateOperationsInput | number
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    week_number?: IntFieldUpdateOperationsInput | number
    proof?: WeeklyClaimUpdateproofInput | Enumerable<string>
    amount?: StringFieldUpdateOperationsInput | string
  }

  export type WeeklyClaimUncheckedUpdateManyWithoutWeekly_claimsInput = {
    id?: IntFieldUpdateOperationsInput | number
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    week_number?: IntFieldUpdateOperationsInput | number
    proof?: WeeklyClaimUpdateproofInput | Enumerable<string>
    amount?: StringFieldUpdateOperationsInput | string
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}